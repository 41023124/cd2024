﻿# NX 2027
# Journal created by Admin on Fri Jun 14 14:50:00 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\yan1\\portable_2024\\portable_2024\\data\\w1705.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder1 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder1.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId6, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder1.UseWorkPartOrigin = False
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 1.0
    matrix1.Xy = 0.0
    matrix1.Xz = 0.0
    matrix1.Yx = -0.0
    matrix1.Yy = 0.0
    matrix1.Yz = 1.0
    matrix1.Zx = 0.0
    matrix1.Zy = -1.0
    matrix1.Zz = 0.0
    plane2 = workPart.Planes.CreateFixedTypePlane(origin2, matrix1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector1 = NXOpen.Vector3d(0.0, -1.0, 0.0)
    direction1 = workPart.Directions.CreateDirection(origin3, vector1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector2 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction2 = workPart.Directions.CreateDirection(origin4, vector2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix2 = NXOpen.Matrix3x3()
    
    matrix2.Xx = 1.0
    matrix2.Xy = 0.0
    matrix2.Xz = 0.0
    matrix2.Yx = -0.0
    matrix2.Yy = 0.0
    matrix2.Yz = 1.0
    matrix2.Zx = 0.0
    matrix2.Zy = -1.0
    matrix2.Zz = 0.0
    plane3 = workPart.Planes.CreateFixedTypePlane(origin5, matrix2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane3, direction2, point2, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder1.CoordinateSystem = cartesianCoordinateSystem1
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    simpleSketchInPlaceBuilder1.HorizontalReference.Value = datumAxis1
    
    point3 = simpleSketchInPlaceBuilder1.SketchOrigin
    
    simpleSketchInPlaceBuilder1.SketchOrigin = point3
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId7, None)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject2 = simpleSketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId9)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder1 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject3 = sketchFindMovableObjectsBuilder1.Commit()
    
    sketchFindMovableObjectsBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId8, None)
    
    theSession.SetUndoMarkName(markId6, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    simpleSketchInPlaceBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId5, None, True)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_000")
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint1 = NXOpen.Point3d(60.907534230749448, 67.397681320911332, 0.0)
    viewCenter1 = NXOpen.Point3d(-60.907534230749448, -67.397681320911332, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(74.886312578790367, 81.75089123184614, 0.0)
    viewCenter2 = NXOpen.Point3d(-74.886312578790367, -81.750891231846239, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(81.126838627022792, 89.707561943342569, 0.0)
    viewCenter3 = NXOpen.Point3d(-81.126838627022792, -89.707561943342569, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(69.893891740204182, 73.014154764320594, 0.0)
    viewCenter4 = NXOpen.Point3d(-69.893891740204182, -73.014154764320594, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(57.912081727597815, 61.406776314608173, 0.0)
    viewCenter5 = NXOpen.Point3d(-57.912081727597815, -61.406776314608003, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(47.128452716251964, 53.918145056729117, 0.0)
    viewCenter6 = NXOpen.Point3d(-47.128452716251964, -53.918145056728982, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId12, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 107.46685097140289)
    endPoint1 = NXOpen.Point3d(6.400283515067712, 0.0, 107.46685097140289)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(6.400283515067712, 0.0, 107.46685097140289)
    endPoint2 = NXOpen.Point3d(6.400283515067712, 0.0, 1.4210854715202004e-14)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(6.400283515067712, 0.0, 1.4210854715202004e-14)
    endPoint3 = NXOpen.Point3d(0.0, 0.0, 1.4210854715202004e-14)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 0.0, 1.4210854715202004e-14)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 107.46685097140289)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    objects1 = [NXOpen.NXObject.Null] * 4 
    objects1[0] = sketchGeometricConstraint1
    objects1[1] = sketchGeometricConstraint2
    objects1[2] = sketchGeometricConstraint3
    objects1[3] = sketchGeometricConstraint4
    errorList1 = theSession.ActiveSketch.DeleteObjects(objects1)
    
    errorList1.Dispose()
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId13, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(0.0, 0.0, 9.0562514011951691)
    endPoint5 = NXOpen.Point3d(101.61573374857835, 0.0, 9.0562514011951691)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(101.61573374857835, 0.0, 9.0562514011951691)
    endPoint6 = NXOpen.Point3d(101.61573374857835, 0.0, 1.1901590823981678e-13)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(101.61573374857835, 0.0, 1.1901590823981678e-13)
    endPoint7 = NXOpen.Point3d(0.0, 0.0, 1.1901590823981678e-13)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(0.0, 0.0, 1.1901590823981678e-13)
    endPoint8 = NXOpen.Point3d(0.0, 0.0, 9.0562514011951691)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line5
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line6
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line6
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line7
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line7
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line8
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line8
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line5
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    objects2 = [NXOpen.NXObject.Null] * 4 
    objects2[0] = sketchGeometricConstraint5
    objects2[1] = sketchGeometricConstraint6
    objects2[2] = sketchGeometricConstraint7
    objects2[3] = sketchGeometricConstraint8
    errorList2 = theSession.ActiveSketch.DeleteObjects(objects2)
    
    errorList2.Dispose()
    sketchFindMovableObjectsBuilder2 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject4 = sketchFindMovableObjectsBuilder2.Commit()
    
    sketchFindMovableObjectsBuilder2.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint7 = NXOpen.Point3d(-42.815001111713698, 88.505636626453054, 0.0)
    viewCenter7 = NXOpen.Point3d(42.815001111713755, -88.505636626452954, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(-43.933303379556889, 109.83325844889256, 0.0)
    viewCenter8 = NXOpen.Point3d(43.933303379557159, -109.83325844889242, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(11.981810012606541, 109.33401636503399, 0.0)
    viewCenter9 = NXOpen.Point3d(-11.98181001260637, -109.33401636503382, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(9.585448010085301, 87.467213092027194, 0.0)
    viewCenter10 = NXOpen.Point3d(-9.5854480100850274, -87.467213092027052, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(7.668358408068241, 69.973770473621755, 0.0)
    viewCenter11 = NXOpen.Point3d(-7.6683584080680225, -69.973770473621641, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(6.1346867264545937, 55.97901637889742, 0.0)
    viewCenter12 = NXOpen.Point3d(-6.1346867264543326, -55.979016378897327, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(-17.99508106426644, 70.957876469323836, 0.0)
    viewCenter13 = NXOpen.Point3d(17.99508106426665, -70.957876469323736, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(-15.050431435568289, 56.766301175459063, 0.0)
    viewCenter14 = NXOpen.Point3d(15.050431435568512, -56.766301175459006, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-14.134318217751071, 45.413040940367267, 0.0)
    viewCenter15 = NXOpen.Point3d(14.134318217751295, -45.413040940367175, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder1 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects1 = [None] * 1 
    dragobjects1[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects1[0].Geometry = line1
    dragobjects1[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects1[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects1)
    
    sketchDragGeometryBuilder1.SplineLinearScale = False
    
    foundrelations1 = sketchDragGeometryBuilder1.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects2 = [None] * 1 
    dragobjects2[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects2[0].Geometry = line1
    dragobjects2[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects2[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects2)
    
    foundrelations2 = sketchDragGeometryBuilder1.FindRelations()
    
    sketchDragGeometryBuilder1.Destroy()
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences1 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences1 = dimensionPreferences1.GetNarrowDimensionPreferences()
    
    option1 = narrowDimensionPreferences1.DimensionDisplayOption
    
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder1 = sketchLinearDimensionBuilder1.Driving
    
    drivingValueBuilder1.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject1 = sketchLinearDimensionBuilder1.FirstAssociativity
    
    selectNXObject2 = sketchLinearDimensionBuilder1.SecondAssociativity
    
    point1_3 = NXOpen.Point3d(0.0, 0.0, 107.46685097140289)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject1.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(6.400283515067712, 0.0, 107.46685097140289)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject2.SetValue(NXOpen.InferSnapType.SnapType.End, line1, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionMeasurementBuilder1 = sketchLinearDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder1.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder1 = sketchLinearDimensionBuilder1.Origin
    
    origin7 = NXOpen.Point3d(3.200141757533856, 0.0, 114.58965700239561)
    originBuilder1.OriginPoint = origin7
    
    originBuilder1.SetInferRelativeToGeometry(True)
    
    nXObject5 = sketchLinearDimensionBuilder1.Commit()
    
    horizontalDimension1 = nXObject5
    horizontalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences1.Dispose()
    dimensionPreferences1.Dispose()
    sketchFindMovableObjectsBuilder3 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject6 = sketchFindMovableObjectsBuilder3.Commit()
    
    sketchFindMovableObjectsBuilder3.Destroy()
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder1 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension1)
    
    selectNXObjectList1 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations3 = sketchEditDimensionValueBuilder1.FindRelations()
    
    sketchHelpedDimensionalConstraint1 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line1] StartVertex] [[Curve Line1] EndVertex]")
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId17, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId17, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId18, None)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.DimValue = 2.0
    
    theSession.ActiveSketch.Scale(0.31248615710248756)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin8 = NXOpen.Point3d(0.99999999999495515, 0.0, 35.80768156037076)
    horizontalDimension1.AnnotationOrigin = origin8
    
    sketchEditDimensionValueBuilder1.RestoreOperation()
    
    sketchEditDimensionValueBuilder1.LoadExtraGeometry()
    
    selectNXObjectList2 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations4 = sketchEditDimensionValueBuilder1.FindRelations()
    
    nXObject7 = sketchEditDimensionValueBuilder1.Commit()
    
    theSession.SetUndoMarkName(markId19, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId19, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId17, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    selectNXObjectList3 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    objects3 = [NXOpen.NXObject.Null] * 1 
    objects3[0] = line6
    selectNXObjectList3.SetArray(objects3)
    
    sketchEditDimensionValueBuilder1.RestoreOperation()
    
    sketchEditDimensionValueBuilder1.LoadExtraGeometry()
    
    selectNXObjectList4 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    theSession.ActiveSketch.Update()
    
    theSession.SetUndoMarkName(markId20, "Edit Dimension Value - Selection")
    
    theSession.SetUndoMarkVisibility(markId20, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId17, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId22, None)
    
    theSession.SetUndoMarkName(markId17, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId21, None)
    
    theSession.SetUndoMarkVisibility(markId17, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId20, None)
    
    theSession.DeleteUndoMark(markId19, None)
    
    theSession.DeleteUndoMark(markId17, None)
    
    sketchFindMovableObjectsBuilder4 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject8 = sketchFindMovableObjectsBuilder4.Commit()
    
    sketchFindMovableObjectsBuilder4.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder2 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects3 = [None] * 1 
    dragobjects3[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects3[0].Geometry = line6
    dragobjects3[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects3[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects3)
    
    sketchDragGeometryBuilder2.SplineLinearScale = False
    
    foundrelations5 = sketchDragGeometryBuilder2.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects4 = [None] * 1 
    dragobjects4[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects4[0].Geometry = line6
    dragobjects4[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects4[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects4)
    
    foundrelations6 = sketchDragGeometryBuilder2.FindRelations()
    
    sketchDragGeometryBuilder2.Destroy()
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences2 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences2 = dimensionPreferences2.GetNarrowDimensionPreferences()
    
    option2 = narrowDimensionPreferences2.DimensionDisplayOption
    
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder2 = sketchLinearDimensionBuilder2.Driving
    
    drivingValueBuilder2.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject3 = sketchLinearDimensionBuilder2.FirstAssociativity
    
    selectNXObject4 = sketchLinearDimensionBuilder2.SecondAssociativity
    
    point1_7 = NXOpen.Point3d(31.753510140252892, 0.0, 2.8299531981134942)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject3.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, NXOpen.View.Null, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(31.753510140252892, 0.0, 3.4638958368304884e-14)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject4.SetValue(NXOpen.InferSnapType.SnapType.End, line6, NXOpen.View.Null, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    dimensionMeasurementBuilder2 = sketchLinearDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder2.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder2 = sketchLinearDimensionBuilder2.Origin
    
    origin10 = NXOpen.Point3d(33.979288424664233, 0.0, 1.4149765990567644)
    originBuilder2.OriginPoint = origin10
    
    originBuilder2.SetInferRelativeToGeometry(True)
    
    nXObject9 = sketchLinearDimensionBuilder2.Commit()
    
    verticalDimension1 = nXObject9
    verticalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences2.Dispose()
    dimensionPreferences2.Dispose()
    sketchFindMovableObjectsBuilder5 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject10 = sketchFindMovableObjectsBuilder5.Commit()
    
    sketchFindMovableObjectsBuilder5.Destroy()
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder2 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension1)
    
    selectNXObjectList5 = sketchEditDimensionValueBuilder2.ExtraGeometries
    
    foundrelations7 = sketchEditDimensionValueBuilder2.FindRelations()
    
    sketchHelpedDimensionalConstraint2 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line6] StartVertex] [[Curve Line6] EndVertex]")
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId26, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId27, None)
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.DimValue = 2.0
    
    nXObject11 = sketchEditDimensionValueBuilder2.Commit()
    
    theSession.SetUndoMarkName(markId28, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId28, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId30, None)
    
    theSession.SetUndoMarkName(markId26, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId29, None)
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId28, None)
    
    theSession.DeleteUndoMark(markId26, None)
    
    sketchFindMovableObjectsBuilder6 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject12 = sketchFindMovableObjectsBuilder6.Commit()
    
    sketchFindMovableObjectsBuilder6.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder3 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects5 = [None] * 1 
    dragobjects5[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects5[0].Geometry = line7
    dragobjects5[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects5[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects5)
    
    sketchDragGeometryBuilder3.SplineLinearScale = False
    
    foundrelations8 = sketchDragGeometryBuilder3.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects6 = [None] * 1 
    dragobjects6[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects6[0].Geometry = line7
    dragobjects6[0].PointType = NXOpen.Sketch.PointType.MidPoint
    dragobjects6[0].PointIndex = -315391968
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects6)
    
    foundrelations9 = sketchDragGeometryBuilder3.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    scaleAboutPoint16 = NXOpen.Point3d(-18.426963009808826, -72.556166851122669, 0.0)
    viewCenter16 = NXOpen.Point3d(18.426963009809079, 72.556166851122782, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-14.741570407847023, -58.379969171985572, 0.0)
    viewCenter17 = NXOpen.Point3d(14.741570407847309, 58.379969171985685, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-11.793256326277584, -45.765875402543635, 0.0)
    viewCenter18 = NXOpen.Point3d(11.79325632627787, 45.765875402543749, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-9.4346050610220491, -36.612700322034897, 0.0)
    viewCenter19 = NXOpen.Point3d(9.4346050610223244, 36.61270032203501, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-7.5476840488176098, -29.29016025762791, 0.0)
    viewCenter20 = NXOpen.Point3d(7.5476840488178878, 29.29016025762802, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    sketchDragGeometryBuilder3.Destroy()
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder4 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects7 = [None] * 1 
    dragobjects7[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects7[0].Geometry = line7
    dragobjects7[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects7[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects7)
    
    sketchDragGeometryBuilder4.SplineLinearScale = False
    
    foundrelations10 = sketchDragGeometryBuilder4.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects8 = [None] * 1 
    dragobjects8[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects8[0].Geometry = line7
    dragobjects8[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects8[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects8)
    
    foundrelations11 = sketchDragGeometryBuilder4.FindRelations()
    
    sketchDragGeometryBuilder4.Destroy()
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences3 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences3 = dimensionPreferences3.GetNarrowDimensionPreferences()
    
    option3 = narrowDimensionPreferences3.DimensionDisplayOption
    
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder3 = sketchLinearDimensionBuilder3.Driving
    
    drivingValueBuilder3.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject5 = sketchLinearDimensionBuilder3.FirstAssociativity
    
    selectNXObject6 = sketchLinearDimensionBuilder3.SecondAssociativity
    
    point1_13 = NXOpen.Point3d(31.753510140252892, 0.0, 3.7190823799922629e-14)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject5.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, NXOpen.View.Null, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    point1_14 = NXOpen.Point3d(0.0, 0.0, 3.7190823799922629e-14)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject6.SetValue(NXOpen.InferSnapType.SnapType.End, line7, NXOpen.View.Null, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    dimensionMeasurementBuilder3 = sketchLinearDimensionBuilder3.Measurement
    
    dimensionMeasurementBuilder3.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder3 = sketchLinearDimensionBuilder3.Origin
    
    origin13 = NXOpen.Point3d(15.876755070126446, 0.0, -2.2257782844113017)
    originBuilder3.OriginPoint = origin13
    
    originBuilder3.SetInferRelativeToGeometry(True)
    
    nXObject13 = sketchLinearDimensionBuilder3.Commit()
    
    horizontalDimension2 = nXObject13
    horizontalDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder3.Destroy()
    
    narrowDimensionPreferences3.Dispose()
    dimensionPreferences3.Dispose()
    sketchFindMovableObjectsBuilder7 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject14 = sketchFindMovableObjectsBuilder7.Commit()
    
    sketchFindMovableObjectsBuilder7.Destroy()
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder3 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension2)
    
    selectNXObjectList6 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations12 = sketchEditDimensionValueBuilder3.FindRelations()
    
    sketchHelpedDimensionalConstraint3 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line7] StartVertex] [[Curve Line7] EndVertex]")
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId35, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId35, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId36, None)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.DimValue = 80.0
    
    nXObject15 = sketchEditDimensionValueBuilder3.Commit()
    
    theSession.SetUndoMarkName(markId37, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId37, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId35, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint21 = NXOpen.Point3d(9.9492198825326152, -18.766287157742251, 0.0)
    viewCenter21 = NXOpen.Point3d(-9.949219882532347, 18.766287157742365, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(7.9593759060261258, -15.013029726193789, 0.0)
    viewCenter22 = NXOpen.Point3d(-7.9593759060258451, 15.013029726193901, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(6.367500724820931, -12.010423780955024, 0.0)
    viewCenter23 = NXOpen.Point3d(-6.3675007248206388, 12.010423780955129, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(5.094000579856778, -9.4326838323551616, 0.0)
    viewCenter24 = NXOpen.Point3d(-5.094000579856484, 9.4326838323552664, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(6.367500724820939, -11.790854790443964, 0.0)
    viewCenter25 = NXOpen.Point3d(-6.3675007248206317, 11.790854790444069, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(7.9593759060261347, -14.738568488054964, 0.0)
    viewCenter26 = NXOpen.Point3d(-7.9593759060258265, 14.738568488055071, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(9.9492198825326277, -18.423210610068722, 0.0)
    viewCenter27 = NXOpen.Point3d(-9.9492198825323115, 18.423210610068825, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId39, None)
    
    theSession.SetUndoMarkName(markId35, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId38, None)
    
    theSession.SetUndoMarkVisibility(markId35, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId37, None)
    
    theSession.DeleteUndoMark(markId35, None)
    
    sketchFindMovableObjectsBuilder8 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject16 = sketchFindMovableObjectsBuilder8.Commit()
    
    sketchFindMovableObjectsBuilder8.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder5 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects9 = [None] * 1 
    dragobjects9[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects9[0].Geometry = line4
    dragobjects9[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects9[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects9)
    
    sketchDragGeometryBuilder5.SplineLinearScale = False
    
    foundrelations13 = sketchDragGeometryBuilder5.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects10 = [None] * 1 
    dragobjects10[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects10[0].Geometry = line4
    dragobjects10[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects10[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects10)
    
    foundrelations14 = sketchDragGeometryBuilder5.FindRelations()
    
    sketchDragGeometryBuilder5.Destroy()
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences4 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences4 = dimensionPreferences4.GetNarrowDimensionPreferences()
    
    option4 = narrowDimensionPreferences4.DimensionDisplayOption
    
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder4 = sketchLinearDimensionBuilder4.Driving
    
    drivingValueBuilder4.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject7 = sketchLinearDimensionBuilder4.FirstAssociativity
    
    selectNXObject8 = sketchLinearDimensionBuilder4.SecondAssociativity
    
    point1_17 = NXOpen.Point3d(0.0, 0.0, 4.4406953790952395e-15)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject7.SetValue(NXOpen.InferSnapType.SnapType.Start, line4, NXOpen.View.Null, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    point1_18 = NXOpen.Point3d(0.0, 0.0, 33.581903275959419)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject8.SetValue(NXOpen.InferSnapType.SnapType.End, line4, NXOpen.View.Null, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    dimensionMeasurementBuilder4 = sketchLinearDimensionBuilder4.Measurement
    
    dimensionMeasurementBuilder4.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder4 = sketchLinearDimensionBuilder4.Origin
    
    origin15 = NXOpen.Point3d(-2.225778284411339, 0.0, 16.790951637979713)
    originBuilder4.OriginPoint = origin15
    
    originBuilder4.SetInferRelativeToGeometry(True)
    
    nXObject17 = sketchLinearDimensionBuilder4.Commit()
    
    verticalDimension2 = nXObject17
    verticalDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder4.Destroy()
    
    narrowDimensionPreferences4.Dispose()
    dimensionPreferences4.Dispose()
    sketchFindMovableObjectsBuilder9 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject18 = sketchFindMovableObjectsBuilder9.Commit()
    
    sketchFindMovableObjectsBuilder9.Destroy()
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder4 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension2)
    
    selectNXObjectList7 = sketchEditDimensionValueBuilder4.ExtraGeometries
    
    foundrelations15 = sketchEditDimensionValueBuilder4.FindRelations()
    
    sketchHelpedDimensionalConstraint4 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line4] StartVertex] [[Curve Line4] EndVertex]")
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId43, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId43, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId44, None)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.DimValue = 40.0
    
    nXObject19 = sketchEditDimensionValueBuilder4.Commit()
    
    theSession.SetUndoMarkName(markId45, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId45, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId43, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.DimValue = 45.0
    
    nXObject20 = sketchEditDimensionValueBuilder4.Commit()
    
    theSession.SetUndoMarkName(markId46, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId46, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId43, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId48, None)
    
    theSession.SetUndoMarkName(markId43, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId47, None)
    
    theSession.SetUndoMarkVisibility(markId43, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId46, None)
    
    theSession.DeleteUndoMark(markId45, None)
    
    theSession.DeleteUndoMark(markId43, None)
    
    sketchFindMovableObjectsBuilder10 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject21 = sketchFindMovableObjectsBuilder10.Commit()
    
    sketchFindMovableObjectsBuilder10.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder1 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder1.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject22 = sketchWorkRegionBuilder1.Commit()
    
    sketchWorkRegionBuilder1.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("8")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId50, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions1 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions1.SetSelectedFromInactive(False)
    
    curves1 = [NXOpen.ICurve.Null] * 8 
    curves1[0] = line1
    curves1[1] = line2
    curves1[2] = line3
    curves1[3] = line4
    curves1[4] = line5
    curves1[5] = line6
    curves1[6] = line7
    curves1[7] = line8
    seedPoint1 = NXOpen.Point3d(1.1471459999942146, 0.0, 20.336361000000018)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch1, curves1, seedPoint1, 0.01, selectionIntentRuleOptions1)
    
    selectionIntentRuleOptions1.Dispose()
    selectionIntentRuleOptions2 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions2.SetSelectedFromInactive(False)
    
    curves2 = [NXOpen.ICurve.Null] * 8 
    curves2[0] = line1
    curves2[1] = line2
    curves2[2] = line3
    curves2[3] = line4
    curves2[4] = line5
    curves2[5] = line6
    curves2[6] = line7
    curves2[7] = line8
    seedPoint2 = NXOpen.Point3d(46.738693999995711, 0.0, 0.8528540000000383)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch1, curves2, seedPoint2, 0.01, selectionIntentRuleOptions2)
    
    selectionIntentRuleOptions2.Dispose()
    selectionIntentRuleOptions3 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions3.SetSelectedFromInactive(False)
    
    curves3 = [NXOpen.ICurve.Null] * 8 
    curves3[0] = line1
    curves3[1] = line2
    curves3[2] = line3
    curves3[3] = line4
    curves3[4] = line5
    curves3[5] = line6
    curves3[6] = line7
    curves3[7] = line8
    seedPoint3 = NXOpen.Point3d(1.1471459999942146, 0.0, 0.85285400000001743)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch1, curves3, seedPoint3, 0.01, selectionIntentRuleOptions3)
    
    selectionIntentRuleOptions3.Dispose()
    section1.AllowSelfIntersection(True)
    
    section1.AllowDegenerateCurves(False)
    
    rules1 = [None] * 3 
    rules1[0] = regionBoundaryRule1
    rules1[1] = regionBoundaryRule2
    rules1[2] = regionBoundaryRule3
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId51, None)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId53, None)
    
    direction3 = workPart.Directions.CreateDirection(sketch1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction3
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies2)
    
    targetBodies3 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies3)
    
    theSession.DeleteUndoMark(markId52, None)
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies4)
    
    targetBodies5 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("110")
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies6)
    
    targetBodies7 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies7)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("115")
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies8)
    
    targetBodies9 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies9)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId54, None)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId55, None)
    
    theSession.SetUndoMarkName(markId50, "Extrude")
    
    expression4 = extrudeBuilder1.Limits.StartExtend.Value
    expression5 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression3)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint28 = NXOpen.Point3d(39.939366708688141, 8.4871154255962704, 0.0)
    viewCenter28 = NXOpen.Point3d(-39.939366708688141, -8.4871154255962704, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(49.924208385860176, 10.608894281995338, 0.0)
    viewCenter29 = NXOpen.Point3d(-49.924208385860176, -10.608894281995338, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(63.965391994383246, 11.700986340435993, 0.0)
    viewCenter30 = NXOpen.Point3d(-63.965391994383246, -11.700986340435993, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(81.906904383052108, 14.626232925544988, 0.0)
    viewCenter31 = NXOpen.Point3d(-81.906904383052108, -14.626232925544988, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(102.38363047881491, 8.5319692065678385, 0.0)
    viewCenter32 = NXOpen.Point3d(-102.38363047881491, -8.5319692065678385, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(81.906904383052108, 6.8255753652542728, 0.0)
    viewCenter33 = NXOpen.Point3d(-81.906904383052108, -6.8255753652542728, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(65.525523506441559, 5.4604602922034191, 0.0)
    viewCenter34 = NXOpen.Point3d(-65.525523506441559, -5.4604602922034191, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(52.420418805153354, 4.3683682337627348, 0.0)
    viewCenter35 = NXOpen.Point3d(-52.420418805153247, -4.3683682337627348, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(41.936335044122679, 3.4946945870101027, 0.0)
    viewCenter36 = NXOpen.Point3d(-41.936335044122508, -3.4946945870102728, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(33.549068035298212, 2.7957556696080821, 0.0)
    viewCenter37 = NXOpen.Point3d(-33.549068035297935, -2.7957556696082184, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(19.809925887509358, 0.95854480100846196, 0.0)
    viewCenter38 = NXOpen.Point3d(-19.809925887509305, -0.95854480100857098, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(14.825492922265044, 0.25561194693550271, 0.0)
    viewCenter39 = NXOpen.Point3d(-14.825492922264957, -0.25561194693567707, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(10.224477877424226, -0.61346867264555538, 0.0)
    viewCenter40 = NXOpen.Point3d(-10.224477877424087, 0.61346867264538107, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(5.5621159653187995, -1.7995081064267484, 0.0)
    viewCenter41 = NXOpen.Point3d(-5.56211596531866, 1.799508106426581, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin16, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression7 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder2 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId58, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder2.UseWorkPartOrigin = False
    
    coordinates3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point4 = workPart.Points.CreatePoint(coordinates3)
    
    origin17 = NXOpen.Point3d(0.0, -35.278350099145854, 44.721649900854139)
    matrix3 = NXOpen.Matrix3x3()
    
    matrix3.Xx = 0.0
    matrix3.Xy = 1.0
    matrix3.Xz = 0.0
    matrix3.Yx = 0.0
    matrix3.Yy = 0.0
    matrix3.Yz = 1.0
    matrix3.Zx = 1.0
    matrix3.Zy = 0.0
    matrix3.Zz = 0.0
    plane5 = workPart.Planes.CreateFixedTypePlane(origin17, matrix3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point5 = workPart.Points.CreatePoint(coordinates4)
    
    origin18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector3 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction4 = workPart.Directions.CreateDirection(origin18, vector3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector4 = NXOpen.Vector3d(0.0, 1.0, 0.0)
    direction5 = workPart.Directions.CreateDirection(origin19, vector4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix4 = NXOpen.Matrix3x3()
    
    matrix4.Xx = 0.0
    matrix4.Xy = 1.0
    matrix4.Xz = 0.0
    matrix4.Yx = 0.0
    matrix4.Yy = 0.0
    matrix4.Yz = 1.0
    matrix4.Zx = 1.0
    matrix4.Zy = 0.0
    matrix4.Zz = 0.0
    plane6 = workPart.Planes.CreateFixedTypePlane(origin20, matrix4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane6, direction5, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder2.CoordinateSystem = cartesianCoordinateSystem2
    
    datumAxis2 = workPart.Datums.FindObject("DATUM_CSYS(0) Y axis")
    simpleSketchInPlaceBuilder2.HorizontalReference.Value = datumAxis2
    
    point6 = simpleSketchInPlaceBuilder2.SketchOrigin
    
    simpleSketchInPlaceBuilder2.SketchOrigin = point6
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId59, None)
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject23 = simpleSketchInPlaceBuilder2.Commit()
    
    sketch2 = nXObject23
    feature3 = sketch2.Feature
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId61)
    
    sketch2.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder11 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject24 = sketchFindMovableObjectsBuilder11.Commit()
    
    sketchFindMovableObjectsBuilder11.Destroy()
    
    theSession.DeleteUndoMark(markId60, None)
    
    theSession.SetUndoMarkName(markId58, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    simpleSketchInPlaceBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression7)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression6)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId57, None, True)
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_001")
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId64, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint9 = NXOpen.Point3d(0.0, 0.0, 44.627801039379847)
    endPoint9 = NXOpen.Point3d(0.0, -2.8792129702815159, 44.627801039379847)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(0.0, -2.8792129702815159, 44.627801039379847)
    endPoint10 = NXOpen.Point3d(0.0, -2.8792129702815159, 0.0)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(0.0, -2.8792129702815159, 0.0)
    endPoint11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint12 = NXOpen.Point3d(0.0, 0.0, 44.627801039379847)
    line12 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line9
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line10
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line10
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line11
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line11
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line12
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line12
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line9
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line9
    geoms5[1] = line10
    geoms5[2] = line11
    geoms5[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line9
    geoms6[1] = line10
    geoms6[2] = line11
    geoms6[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms6)
    
    objects4 = [NXOpen.NXObject.Null] * 4 
    objects4[0] = sketchGeometricConstraint9
    objects4[1] = sketchGeometricConstraint10
    objects4[2] = sketchGeometricConstraint11
    objects4[3] = sketchGeometricConstraint12
    errorList3 = theSession.ActiveSketch.DeleteObjects(objects4)
    
    errorList3.Dispose()
    sketchFindMovableObjectsBuilder12 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject25 = sketchFindMovableObjectsBuilder12.Commit()
    
    sketchFindMovableObjectsBuilder12.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Line...
    # ----------------------------------------------
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId65, "Curve")
    
    sketchFindMovableObjectsBuilder13 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject26 = sketchFindMovableObjectsBuilder13.Commit()
    
    sketchFindMovableObjectsBuilder13.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId67, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint13 = NXOpen.Point3d(0.0, -115.0, 45.0)
    endPoint13 = NXOpen.Point3d(0.0, -111.24231930637688, 45.0)
    line13 = workPart.Curves.CreateLine(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(0.0, -111.24231930637688, 45.0)
    endPoint14 = NXOpen.Point3d(0.0, -111.24231930637688, 0.0)
    line14 = workPart.Curves.CreateLine(startPoint14, endPoint14)
    
    startPoint15 = NXOpen.Point3d(0.0, -111.24231930637688, 0.0)
    endPoint15 = NXOpen.Point3d(0.0, -115.0, 0.0)
    line15 = workPart.Curves.CreateLine(startPoint15, endPoint15)
    
    startPoint16 = NXOpen.Point3d(0.0, -115.0, 0.0)
    endPoint16 = NXOpen.Point3d(0.0, -115.0, 45.0)
    line16 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line13
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_13.Geometry = line14
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_13, conGeom2_13)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line14
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_14.Geometry = line15
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line15
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_15.Geometry = line16
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_15, conGeom2_15)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line16
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_16.Geometry = line13
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_16, conGeom2_16)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line13
    geoms7[1] = line14
    geoms7[2] = line15
    geoms7[3] = line16
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line13
    geoms8[1] = line14
    geoms8[2] = line15
    geoms8[3] = line16
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    objects5 = [NXOpen.NXObject.Null] * 4 
    objects5[0] = sketchGeometricConstraint13
    objects5[1] = sketchGeometricConstraint14
    objects5[2] = sketchGeometricConstraint15
    objects5[3] = sketchGeometricConstraint16
    errorList4 = theSession.ActiveSketch.DeleteObjects(objects5)
    
    errorList4.Dispose()
    sketchFindMovableObjectsBuilder14 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject27 = sketchFindMovableObjectsBuilder14.Commit()
    
    sketchFindMovableObjectsBuilder14.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.DeleteUndoMark(markId69, "Create Rectangle")
    
    sketchFindMovableObjectsBuilder15 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject28 = sketchFindMovableObjectsBuilder15.Commit()
    
    sketchFindMovableObjectsBuilder15.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder6 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects11 = [None] * 1 
    dragobjects11[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects11[0].Geometry = line16
    dragobjects11[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects11[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects11)
    
    sketchDragGeometryBuilder6.SplineLinearScale = False
    
    foundrelations16 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects12 = [None] * 1 
    dragobjects12[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects12[0].Geometry = line16
    dragobjects12[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects12[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects12)
    
    foundrelations17 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    sketchDragGeometryBuilder6.Destroy()
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences5 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences5 = dimensionPreferences5.GetNarrowDimensionPreferences()
    
    option5 = narrowDimensionPreferences5.DimensionDisplayOption
    
    sketchLinearDimensionBuilder5 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder5 = sketchLinearDimensionBuilder5.Driving
    
    drivingValueBuilder5.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder5 = sketchLinearDimensionBuilder5.Measurement
    
    dimensionMeasurementBuilder5.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject9 = sketchLinearDimensionBuilder5.FirstAssociativity
    
    selectNXObject10 = sketchLinearDimensionBuilder5.SecondAssociativity
    
    infiniteLine2 = theSession.ActiveSketch.FindObject("YAxis")
    point1_23 = NXOpen.Point3d(0.0, 0.0, 61.117838960090012)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject9.SetValue(NXOpen.InferSnapType.SnapType.NotSet, infiniteLine2, NXOpen.View.Null, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    point1_24 = NXOpen.Point3d(0.0, -115.0, 45.0)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject10.SetValue(NXOpen.InferSnapType.SnapType.End, line16, NXOpen.View.Null, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    originBuilder5 = sketchLinearDimensionBuilder5.Origin
    
    origin23 = NXOpen.Point3d(0.0, -57.5, 37.298895296842041)
    originBuilder5.OriginPoint = origin23
    
    originBuilder5.SetInferRelativeToGeometry(True)
    
    nXObject29 = sketchLinearDimensionBuilder5.Commit()
    
    perpendicularDimension1 = nXObject29
    perpendicularDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder5.Destroy()
    
    narrowDimensionPreferences5.Dispose()
    dimensionPreferences5.Dispose()
    sketchFindMovableObjectsBuilder16 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject30 = sketchFindMovableObjectsBuilder16.Commit()
    
    sketchFindMovableObjectsBuilder16.Destroy()
    
    theAnnotationsAngularDimensionUtils = NXOpen.Annotations.AngularDimensionUtils.GetAngularDimensionUtils(theSession)
    
    theAnnotationsAngularDimensionUtils.SetAllowSupplementaryAngle(perpendicularDimension1, True)
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Object Origin")
    
    perpendicularDimension1.LeaderOrientation = NXOpen.Annotations.LeaderOrientation.FromLeft
    
    perpendicularDimension1.IsOriginCentered = True
    
    origin24 = perpendicularDimension1.AnnotationOrigin
    
    location1 = NXOpen.Point3d(0.0, -59.678232474949347, 62.688318762062998)
    changed1 = theAnnotationsAngularDimensionUtils.InferQuadrantAngleFromLocation(perpendicularDimension1, location1)
    
    origin25 = NXOpen.Point3d(0.0, -59.678232474949347, 62.688318762062998)
    perpendicularDimension1.AnnotationOrigin = origin25
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId72)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder5 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension1)
    
    selectNXObjectList8 = sketchEditDimensionValueBuilder5.ExtraGeometries
    
    foundrelations18 = sketchEditDimensionValueBuilder5.FindRelations()
    
    sketchHelpedDimensionalConstraint5 = theSession.ActiveSketch.FindObject("PerpendicularDim [YAxis] [[Curve Line16] EndVertex]")
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId74, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId74, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId75, None)
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.Destroy()
    
    theSession.UndoToMark(markId74, None)
    
    theSession.DeleteUndoMark(markId74, None)
    
    theSession.DeleteUndoMark(markId74, None)
    
    sketchFindMovableObjectsBuilder17 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject31 = sketchFindMovableObjectsBuilder17.Commit()
    
    sketchFindMovableObjectsBuilder17.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder7 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects13 = [None] * 1 
    dragobjects13[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects13[0].Geometry = line15
    dragobjects13[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects13[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects13)
    
    sketchDragGeometryBuilder7.SplineLinearScale = False
    
    foundrelations19 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects14 = [None] * 1 
    dragobjects14[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects14[0].Geometry = line15
    dragobjects14[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects14[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects14)
    
    foundrelations20 = sketchDragGeometryBuilder7.FindRelations()
    
    sketchDragGeometryBuilder7.Destroy()
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences6 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences6 = dimensionPreferences6.GetNarrowDimensionPreferences()
    
    option6 = narrowDimensionPreferences6.DimensionDisplayOption
    
    sketchLinearDimensionBuilder6 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder6 = sketchLinearDimensionBuilder6.Driving
    
    drivingValueBuilder6.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject11 = sketchLinearDimensionBuilder6.FirstAssociativity
    
    selectNXObject12 = sketchLinearDimensionBuilder6.SecondAssociativity
    
    point1_27 = NXOpen.Point3d(0.0, -111.24231930637688, 0.0)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject11.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, NXOpen.View.Null, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    point1_28 = NXOpen.Point3d(0.0, -115.0, 0.0)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject12.SetValue(NXOpen.InferSnapType.SnapType.End, line15, NXOpen.View.Null, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    dimensionMeasurementBuilder6 = sketchLinearDimensionBuilder6.Measurement
    
    dimensionMeasurementBuilder6.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder6 = sketchLinearDimensionBuilder6.Origin
    
    origin27 = NXOpen.Point3d(0.0, -113.12115965318844, -8.9035075387409055)
    originBuilder6.OriginPoint = origin27
    
    originBuilder6.SetInferRelativeToGeometry(True)
    
    nXObject32 = sketchLinearDimensionBuilder6.Commit()
    
    horizontalDimension3 = nXObject32
    horizontalDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder6.Destroy()
    
    narrowDimensionPreferences6.Dispose()
    dimensionPreferences6.Dispose()
    sketchFindMovableObjectsBuilder18 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject33 = sketchFindMovableObjectsBuilder18.Commit()
    
    sketchFindMovableObjectsBuilder18.Destroy()
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder6 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension3)
    
    selectNXObjectList9 = sketchEditDimensionValueBuilder6.ExtraGeometries
    
    foundrelations21 = sketchEditDimensionValueBuilder6.FindRelations()
    
    sketchHelpedDimensionalConstraint6 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line15] StartVertex] [[Curve Line15] EndVertex]")
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId80, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId80, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId81, None)
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.DimValue = 2.0
    
    nXObject34 = sketchEditDimensionValueBuilder6.Commit()
    
    theSession.SetUndoMarkName(markId82, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId82, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId80, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId84, None)
    
    theSession.SetUndoMarkName(markId80, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.Destroy()
    
    theSession.DeleteUndoMark(markId83, None)
    
    theSession.SetUndoMarkVisibility(markId80, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId82, None)
    
    theSession.DeleteUndoMark(markId80, None)
    
    sketchFindMovableObjectsBuilder19 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject35 = sketchFindMovableObjectsBuilder19.Commit()
    
    sketchFindMovableObjectsBuilder19.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder8 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects15 = [None] * 1 
    dragobjects15[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects15[0].Geometry = line11
    dragobjects15[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects15[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects15)
    
    sketchDragGeometryBuilder8.SplineLinearScale = False
    
    foundrelations22 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects16 = [None] * 1 
    dragobjects16[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects16[0].Geometry = line11
    dragobjects16[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects16[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects16)
    
    foundrelations23 = sketchDragGeometryBuilder8.FindRelations()
    
    sketchDragGeometryBuilder8.Destroy()
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences7 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences7 = dimensionPreferences7.GetNarrowDimensionPreferences()
    
    option7 = narrowDimensionPreferences7.DimensionDisplayOption
    
    sketchLinearDimensionBuilder7 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder7 = sketchLinearDimensionBuilder7.Driving
    
    drivingValueBuilder7.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject13 = sketchLinearDimensionBuilder7.FirstAssociativity
    
    selectNXObject14 = sketchLinearDimensionBuilder7.SecondAssociativity
    
    point1_31 = NXOpen.Point3d(0.0, -2.8792129702815159, 0.0)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject13.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, NXOpen.View.Null, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    point1_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject14.SetValue(NXOpen.InferSnapType.SnapType.End, line11, NXOpen.View.Null, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    dimensionMeasurementBuilder7 = sketchLinearDimensionBuilder7.Measurement
    
    dimensionMeasurementBuilder7.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder7 = sketchLinearDimensionBuilder7.Origin
    
    origin29 = NXOpen.Point3d(0.0, -1.439606485140758, -8.9035075387409055)
    originBuilder7.OriginPoint = origin29
    
    originBuilder7.SetInferRelativeToGeometry(True)
    
    nXObject36 = sketchLinearDimensionBuilder7.Commit()
    
    horizontalDimension4 = nXObject36
    horizontalDimension4.IsOriginCentered = True
    
    sketchLinearDimensionBuilder7.Destroy()
    
    narrowDimensionPreferences7.Dispose()
    dimensionPreferences7.Dispose()
    sketchFindMovableObjectsBuilder20 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject37 = sketchFindMovableObjectsBuilder20.Commit()
    
    sketchFindMovableObjectsBuilder20.Destroy()
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder7 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension4)
    
    selectNXObjectList10 = sketchEditDimensionValueBuilder7.ExtraGeometries
    
    foundrelations24 = sketchEditDimensionValueBuilder7.FindRelations()
    
    sketchHelpedDimensionalConstraint7 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line11] StartVertex] [[Curve Line11] EndVertex]")
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId88, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId88, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId89, None)
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.DimValue = 2.0
    
    nXObject38 = sketchEditDimensionValueBuilder7.Commit()
    
    theSession.SetUndoMarkName(markId90, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId90, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId88, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId92, None)
    
    theSession.SetUndoMarkName(markId88, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId91, None)
    
    theSession.SetUndoMarkVisibility(markId88, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId90, None)
    
    theSession.DeleteUndoMark(markId88, None)
    
    sketchFindMovableObjectsBuilder21 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject39 = sketchFindMovableObjectsBuilder21.Commit()
    
    sketchFindMovableObjectsBuilder21.Destroy()
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder2 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder2.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject40 = sketchWorkRegionBuilder2.Commit()
    
    sketchWorkRegionBuilder2.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("115")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId94, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions4 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions4.SetSelectedFromInactive(False)
    
    curves4 = [NXOpen.ICurve.Null] * 8 
    curves4[0] = line9
    curves4[1] = line10
    curves4[2] = line11
    curves4[3] = line12
    curves4[4] = line13
    curves4[5] = line14
    curves4[6] = line15
    curves4[7] = line16
    seedPoint4 = NXOpen.Point3d(0.0, -0.85285400000000011, 19.030499313819629)
    regionBoundaryRule4 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch2, curves4, seedPoint4, 0.01, selectionIntentRuleOptions4)
    
    selectionIntentRuleOptions4.Dispose()
    selectionIntentRuleOptions5 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions5.SetSelectedFromInactive(False)
    
    curves5 = [NXOpen.ICurve.Null] * 8 
    curves5[0] = line9
    curves5[1] = line10
    curves5[2] = line11
    curves5[3] = line12
    curves5[4] = line13
    curves5[5] = line14
    curves5[6] = line15
    curves5[7] = line16
    seedPoint5 = NXOpen.Point3d(0.0, -113.85285400000001, 19.189214999999997)
    regionBoundaryRule5 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch2, curves5, seedPoint5, 0.01, selectionIntentRuleOptions5)
    
    selectionIntentRuleOptions5.Dispose()
    section2.AllowSelfIntersection(True)
    
    section2.AllowDegenerateCurves(False)
    
    rules2 = [None] * 2 
    rules2[0] = regionBoundaryRule4
    rules2[1] = regionBoundaryRule5
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section2.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId95, None)
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId97, None)
    
    direction6 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction6
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies12[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies13)
    
    theSession.DeleteUndoMark(markId96, None)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("80")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies15)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies16)
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId98, None)
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId99, None)
    
    theSession.SetUndoMarkName(markId94, "Extrude")
    
    expression9 = extrudeBuilder2.Limits.StartExtend.Value
    expression10 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression8)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.72410999956660016
    rotMatrix1.Xy = 0.68642574940661893
    rotMatrix1.Xz = -0.066965655967962889
    rotMatrix1.Yx = -0.21623279136793375
    rotMatrix1.Yy = 0.31815383271245862
    rotMatrix1.Yz = 0.9230501170941916
    rotMatrix1.Zx = 0.65491074847256048
    rotMatrix1.Zy = -0.65390964917328798
    rotMatrix1.Zz = 0.37880612752854892
    translation1 = NXOpen.Point3d(-34.031505164962617, 7.0560238760645966, -1.4772210497049088)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 1.010837578430662)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.6649254092808109
    rotMatrix2.Xy = 0.74524165851206381
    rotMatrix2.Xz = -0.04989058539381238
    rotMatrix2.Yx = -0.21460495963072543
    rotMatrix2.Yy = 0.25460167093414376
    rotMatrix2.Yz = 0.94293303073942047
    rotMatrix2.Zx = 0.71541520209920095
    rotMatrix2.Zy = -0.61627336432441282
    rotMatrix2.Zz = 0.32922367628957944
    translation2 = NXOpen.Point3d(-28.666395867886351, 2.889295747305507, -0.61770766308337954)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 1.010837578430662)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()