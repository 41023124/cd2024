﻿# NX 2027
# Journal created by Admin on Fri Jun 14 14:26:54 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\yan1\\portable_2024\\portable_2024\\data\\w17.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder1 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder1.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId6, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder1.UseWorkPartOrigin = False
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 1.0
    matrix1.Xy = 0.0
    matrix1.Xz = 0.0
    matrix1.Yx = -0.0
    matrix1.Yy = 0.0
    matrix1.Yz = 1.0
    matrix1.Zx = 0.0
    matrix1.Zy = -1.0
    matrix1.Zz = 0.0
    plane2 = workPart.Planes.CreateFixedTypePlane(origin2, matrix1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector1 = NXOpen.Vector3d(0.0, -1.0, 0.0)
    direction1 = workPart.Directions.CreateDirection(origin3, vector1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector2 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction2 = workPart.Directions.CreateDirection(origin4, vector2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix2 = NXOpen.Matrix3x3()
    
    matrix2.Xx = 1.0
    matrix2.Xy = 0.0
    matrix2.Xz = 0.0
    matrix2.Yx = -0.0
    matrix2.Yy = 0.0
    matrix2.Yz = 1.0
    matrix2.Zx = 0.0
    matrix2.Zy = -1.0
    matrix2.Zz = 0.0
    plane3 = workPart.Planes.CreateFixedTypePlane(origin5, matrix2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane3, direction2, point2, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder1.CoordinateSystem = cartesianCoordinateSystem1
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    simpleSketchInPlaceBuilder1.HorizontalReference.Value = datumAxis1
    
    point3 = simpleSketchInPlaceBuilder1.SketchOrigin
    
    simpleSketchInPlaceBuilder1.SketchOrigin = point3
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId7, None)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject2 = simpleSketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId9)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder1 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject3 = sketchFindMovableObjectsBuilder1.Commit()
    
    sketchFindMovableObjectsBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId8, None)
    
    theSession.SetUndoMarkName(markId6, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    simpleSketchInPlaceBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId5, None, True)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_000")
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId12, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(240.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(240.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(240.0, 0.0, 60.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(240.0, 0.0, 60.0)
    endPoint3 = NXOpen.Point3d(0.0, 0.0, 60.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 0.0, 60.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    objects1 = [NXOpen.NXObject.Null] * 4 
    objects1[0] = sketchGeometricConstraint1
    objects1[1] = sketchGeometricConstraint2
    objects1[2] = sketchGeometricConstraint3
    objects1[3] = sketchGeometricConstraint4
    errorList1 = theSession.ActiveSketch.DeleteObjects(objects1)
    
    errorList1.Dispose()
    sketchFindMovableObjectsBuilder2 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject4 = sketchFindMovableObjectsBuilder2.Commit()
    
    sketchFindMovableObjectsBuilder2.Destroy()
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder1 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects1 = [None] * 1 
    dragobjects1[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects1[0].Geometry = line4
    dragobjects1[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects1[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects1)
    
    sketchDragGeometryBuilder1.SplineLinearScale = False
    
    foundrelations1 = sketchDragGeometryBuilder1.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects2 = [None] * 1 
    dragobjects2[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects2[0].Geometry = line4
    dragobjects2[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects2[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects2)
    
    foundrelations2 = sketchDragGeometryBuilder1.FindRelations()
    
    sketchDragGeometryBuilder1.Destroy()
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences1 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences1 = dimensionPreferences1.GetNarrowDimensionPreferences()
    
    option1 = narrowDimensionPreferences1.DimensionDisplayOption
    
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder1 = sketchLinearDimensionBuilder1.Driving
    
    drivingValueBuilder1.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject1 = sketchLinearDimensionBuilder1.FirstAssociativity
    
    selectNXObject2 = sketchLinearDimensionBuilder1.SecondAssociativity
    
    point1_3 = NXOpen.Point3d(0.0, 0.0, 60.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject1.SetValue(NXOpen.InferSnapType.SnapType.Start, line4, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject2.SetValue(NXOpen.InferSnapType.SnapType.End, line4, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionMeasurementBuilder1 = sketchLinearDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder1.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder1 = sketchLinearDimensionBuilder1.Origin
    
    origin7 = NXOpen.Point3d(-33.964185862506511, 0.0, 30.0)
    originBuilder1.OriginPoint = origin7
    
    originBuilder1.SetInferRelativeToGeometry(True)
    
    nXObject5 = sketchLinearDimensionBuilder1.Commit()
    
    verticalDimension1 = nXObject5
    verticalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences1.Dispose()
    dimensionPreferences1.Dispose()
    sketchFindMovableObjectsBuilder3 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject6 = sketchFindMovableObjectsBuilder3.Commit()
    
    sketchFindMovableObjectsBuilder3.Destroy()
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder1 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension1)
    
    selectNXObjectList1 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations3 = sketchEditDimensionValueBuilder1.FindRelations()
    
    sketchHelpedDimensionalConstraint1 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line4] StartVertex] [[Curve Line4] EndVertex]")
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId16, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId17, None)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.DimValue = 20.0
    
    theSession.ActiveSketch.Scale(0.33333333333333331)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin8 = NXOpen.Point3d(-11.32139528750217, 0.0, 10.0)
    verticalDimension1.AnnotationOrigin = origin8
    
    sketchEditDimensionValueBuilder1.RestoreOperation()
    
    sketchEditDimensionValueBuilder1.LoadExtraGeometry()
    
    selectNXObjectList2 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations4 = sketchEditDimensionValueBuilder1.FindRelations()
    
    nXObject7 = sketchEditDimensionValueBuilder1.Commit()
    
    theSession.SetUndoMarkName(markId18, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId18, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    selectNXObjectList3 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    objects2 = [NXOpen.NXObject.Null] * 1 
    objects2[0] = line3
    selectNXObjectList3.SetArray(objects2)
    
    sketchEditDimensionValueBuilder1.RestoreOperation()
    
    sketchEditDimensionValueBuilder1.LoadExtraGeometry()
    
    selectNXObjectList4 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    theSession.ActiveSketch.Update()
    
    theSession.SetUndoMarkName(markId19, "Edit Dimension Value - Selection")
    
    theSession.SetUndoMarkVisibility(markId19, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint1 = NXOpen.Point3d(65.899955069335533, 41.437092960263989, 0.0)
    viewCenter1 = NXOpen.Point3d(-65.899955069335533, -41.437092960263989, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(52.719964055468431, 33.149674368211201, 0.0)
    viewCenter2 = NXOpen.Point3d(-52.719964055468431, -33.149674368211201, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(42.175971244374637, 26.51973949456896, 0.0)
    viewCenter3 = NXOpen.Point3d(-42.175971244374743, -26.51973949456896, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(33.7407769954998, 21.215791595655169, 0.0)
    viewCenter4 = NXOpen.Point3d(-33.7407769954998, -21.215791595655169, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(26.992621596399839, 16.972633276524135, 0.0)
    viewCenter5 = NXOpen.Point3d(-26.992621596399839, -16.972633276524135, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(22.90283044543018, 3.4354245668145258, 0.0)
    viewCenter6 = NXOpen.Point3d(-22.90283044543018, -3.4354245668145258, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(18.845757623668259, 3.5335795544377984, 0.0)
    viewCenter7 = NXOpen.Point3d(-18.845757623668259, -3.5335795544377984, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId21, None)
    
    theSession.SetUndoMarkName(markId16, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId20, None)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId19, None)
    
    theSession.DeleteUndoMark(markId18, None)
    
    theSession.DeleteUndoMark(markId16, None)
    
    sketchFindMovableObjectsBuilder4 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject8 = sketchFindMovableObjectsBuilder4.Commit()
    
    sketchFindMovableObjectsBuilder4.Destroy()
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder2 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects3 = [None] * 1 
    dragobjects3[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects3[0].Geometry = line3
    dragobjects3[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects3[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects3)
    
    sketchDragGeometryBuilder2.SplineLinearScale = False
    
    foundrelations5 = sketchDragGeometryBuilder2.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects4 = [None] * 1 
    dragobjects4[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects4[0].Geometry = line3
    dragobjects4[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects4[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects4)
    
    foundrelations6 = sketchDragGeometryBuilder2.FindRelations()
    
    sketchDragGeometryBuilder2.Destroy()
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences2 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences2 = dimensionPreferences2.GetNarrowDimensionPreferences()
    
    option2 = narrowDimensionPreferences2.DimensionDisplayOption
    
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder2 = sketchLinearDimensionBuilder2.Driving
    
    drivingValueBuilder2.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject3 = sketchLinearDimensionBuilder2.FirstAssociativity
    
    selectNXObject4 = sketchLinearDimensionBuilder2.SecondAssociativity
    
    point1_7 = NXOpen.Point3d(80.0, 0.0, 20.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject3.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, NXOpen.View.Null, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(0.0, 0.0, 20.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject4.SetValue(NXOpen.InferSnapType.SnapType.End, line3, NXOpen.View.Null, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    dimensionMeasurementBuilder2 = sketchLinearDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder2.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder2 = sketchLinearDimensionBuilder2.Origin
    
    origin10 = NXOpen.Point3d(40.0, 0.0, 31.32139528750217)
    originBuilder2.OriginPoint = origin10
    
    originBuilder2.SetInferRelativeToGeometry(True)
    
    nXObject9 = sketchLinearDimensionBuilder2.Commit()
    
    horizontalDimension1 = nXObject9
    horizontalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences2.Dispose()
    dimensionPreferences2.Dispose()
    sketchFindMovableObjectsBuilder5 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject10 = sketchFindMovableObjectsBuilder5.Commit()
    
    sketchFindMovableObjectsBuilder5.Destroy()
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder2 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension1)
    
    selectNXObjectList5 = sketchEditDimensionValueBuilder2.ExtraGeometries
    
    foundrelations7 = sketchEditDimensionValueBuilder2.FindRelations()
    
    sketchHelpedDimensionalConstraint2 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line3] StartVertex] [[Curve Line3] EndVertex]")
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId25, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId25, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId26, None)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.Destroy()
    
    theSession.UndoToMark(markId25, None)
    
    theSession.DeleteUndoMark(markId25, None)
    
    theSession.DeleteUndoMark(markId25, None)
    
    sketchFindMovableObjectsBuilder6 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject11 = sketchFindMovableObjectsBuilder6.Commit()
    
    sketchFindMovableObjectsBuilder6.Destroy()
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.5715230535206558
    rotMatrix1.Xy = 0.81636208138822397
    rotMatrix1.Xz = -0.083152578828997487
    rotMatrix1.Yx = -0.071092333107502043
    rotMatrix1.Yy = 0.15021178479624997
    rotMatrix1.Yz = 0.98609446803115997
    rotMatrix1.Zx = 0.81750062964364567
    rotMatrix1.Zy = -0.55766421059613613
    rotMatrix1.Zz = 0.14388658294792564
    translation1 = NXOpen.Point3d(-37.045649462704468, -26.661102249809801, -29.551338329556522)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 1.2635469730383266)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder1 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder1.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject12 = sketchWorkRegionBuilder1.Commit()
    
    sketchWorkRegionBuilder1.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId29, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions1 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions1.SetSelectedFromInactive(False)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    curves1[0] = line1
    curves1[1] = line2
    curves1[2] = line3
    curves1[3] = line4
    seedPoint1 = NXOpen.Point3d(45.885840000000002, 0.0, 8.5285399999999996)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch1, curves1, seedPoint1, 0.01, selectionIntentRuleOptions1)
    
    selectionIntentRuleOptions1.Dispose()
    section1.AllowSelfIntersection(True)
    
    section1.AllowDegenerateCurves(False)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId30, None)
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId32, None)
    
    direction3 = workPart.Directions.CreateDirection(sketch1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction3
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies2)
    
    targetBodies3 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies3)
    
    theSession.DeleteUndoMark(markId31, None)
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies4)
    
    targetBodies5 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies6)
    
    targetBodies7 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies7)
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId33, None)
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId34, None)
    
    theSession.SetUndoMarkName(markId29, "Extrude")
    
    expression4 = extrudeBuilder1.Limits.StartExtend.Value
    expression5 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression3)
    
    scaleAboutPoint8 = NXOpen.Point3d(-12.980294180323693, -19.470441270485495, 0.0)
    viewCenter8 = NXOpen.Point3d(12.980294180323693, 19.470441270485495, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(-7.9878733417376644, -16.375140350562187, 0.0)
    viewCenter9 = NXOpen.Point3d(7.9878733417376644, 16.375140350562187, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(-4.4732090713729891, -13.739142147788728, 0.0)
    viewCenter10 = NXOpen.Point3d(4.4732090713730983, 13.739142147788728, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(95.598868153916158, 36.552508411791443, 0.0)
    viewCenter11 = NXOpen.Point3d(-95.598868153915987, -36.552508411791443, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin11, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression7 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder2 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId37, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder2.UseWorkPartOrigin = False
    
    coordinates3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point4 = workPart.Points.CreatePoint(coordinates3)
    
    origin12 = NXOpen.Point3d(66.113163033121168, 0.0, 36.113163033121175)
    matrix3 = NXOpen.Matrix3x3()
    
    matrix3.Xx = 1.0
    matrix3.Xy = 0.0
    matrix3.Xz = 0.0
    matrix3.Yx = -0.0
    matrix3.Yy = 0.0
    matrix3.Yz = 1.0
    matrix3.Zx = 0.0
    matrix3.Zy = -1.0
    matrix3.Zz = 0.0
    plane5 = workPart.Planes.CreateFixedTypePlane(origin12, matrix3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point5 = workPart.Points.CreatePoint(coordinates4)
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector3 = NXOpen.Vector3d(0.0, -1.0, 0.0)
    direction4 = workPart.Directions.CreateDirection(origin13, vector3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector4 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction5 = workPart.Directions.CreateDirection(origin14, vector4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix4 = NXOpen.Matrix3x3()
    
    matrix4.Xx = 1.0
    matrix4.Xy = 0.0
    matrix4.Xz = 0.0
    matrix4.Yx = -0.0
    matrix4.Yy = 0.0
    matrix4.Yz = 1.0
    matrix4.Zx = 0.0
    matrix4.Zy = -1.0
    matrix4.Zz = 0.0
    plane6 = workPart.Planes.CreateFixedTypePlane(origin15, matrix4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane6, direction5, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder2.CoordinateSystem = cartesianCoordinateSystem2
    
    simpleSketchInPlaceBuilder2.HorizontalReference.Value = datumAxis1
    
    point6 = simpleSketchInPlaceBuilder2.SketchOrigin
    
    simpleSketchInPlaceBuilder2.SketchOrigin = point6
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    simpleSketchInPlaceBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression7)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression6)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    theSession.UndoToMark(markId37, None)
    
    theSession.DeleteUndoMark(markId37, None)
    
    theSession.Preferences.Sketch.SectionView = False
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    theSession.UndoToMark(markId35, None)
    
    theSession.DeleteUndoMark(markId35, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin16, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane7
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder3 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId40, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder3.UseWorkPartOrigin = False
    
    coordinates5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point7 = workPart.Points.CreatePoint(coordinates5)
    
    origin17 = NXOpen.Point3d(66.113163033121168, -3.8868369668788247, 0.0)
    matrix5 = NXOpen.Matrix3x3()
    
    matrix5.Xx = 1.0
    matrix5.Xy = 0.0
    matrix5.Xz = 0.0
    matrix5.Yx = 0.0
    matrix5.Yy = 1.0
    matrix5.Yz = 0.0
    matrix5.Zx = 0.0
    matrix5.Zy = 0.0
    matrix5.Zz = 1.0
    plane8 = workPart.Planes.CreateFixedTypePlane(origin17, matrix5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point8 = workPart.Points.CreatePoint(coordinates6)
    
    origin18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction6 = workPart.Directions.CreateDirection(origin18, vector5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector6 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction7 = workPart.Directions.CreateDirection(origin19, vector6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix6 = NXOpen.Matrix3x3()
    
    matrix6.Xx = 1.0
    matrix6.Xy = 0.0
    matrix6.Xz = 0.0
    matrix6.Yx = 0.0
    matrix6.Yy = 1.0
    matrix6.Yz = 0.0
    matrix6.Zx = 0.0
    matrix6.Zy = 0.0
    matrix6.Zz = 1.0
    plane9 = workPart.Planes.CreateFixedTypePlane(origin20, matrix6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane9, direction7, point8, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder3.CoordinateSystem = cartesianCoordinateSystem3
    
    simpleSketchInPlaceBuilder3.HorizontalReference.Value = datumAxis1
    
    point9 = simpleSketchInPlaceBuilder3.SketchOrigin
    
    simpleSketchInPlaceBuilder3.SketchOrigin = point9
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId41, None)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject13 = simpleSketchInPlaceBuilder3.Commit()
    
    sketch2 = nXObject13
    feature3 = sketch2.Feature
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId43)
    
    sketch2.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder7 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject14 = sketchFindMovableObjectsBuilder7.Commit()
    
    sketchFindMovableObjectsBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId42, None)
    
    theSession.SetUndoMarkName(markId40, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    simpleSketchInPlaceBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression9)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression8)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId39, None, True)
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_001")
    
    scaleAboutPoint12 = NXOpen.Point3d(87.112551515654104, -49.690962484281556, 0.0)
    viewCenter12 = NXOpen.Point3d(-87.112551515653962, 49.690962484281492, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(108.89068939456763, -62.624926999223177, 0.0)
    viewCenter13 = NXOpen.Point3d(-108.89068939456746, 62.624926999223085, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(136.11336174320954, -78.281158749028975, 0.0)
    viewCenter14 = NXOpen.Point3d(-136.11336174320942, 78.281158749028862, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(157.36110483223158, -98.650235770459915, 0.0)
    viewCenter15 = NXOpen.Point3d(-157.36110483223132, 98.650235770459773, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(126.52791373312434, -82.115337953063076, 0.0)
    viewCenter16 = NXOpen.Point3d(-126.52791373312412, 82.115337953062863, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(101.22233098649951, -68.759613725677767, 0.0)
    viewCenter17 = NXOpen.Point3d(-101.2223309864993, 68.759613725677539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(80.977864789199586, -55.007690980542215, 0.0)
    viewCenter18 = NXOpen.Point3d(-80.977864789199444, 55.007690980542002, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(53.985243192799778, -34.845020606261734, 0.0)
    viewCenter19 = NXOpen.Point3d(-53.985243192799636, 34.845020606261507, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(43.188194554239807, -27.876016485009412, 0.0)
    viewCenter20 = NXOpen.Point3d(-43.188194554239715, 27.876016485009188, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Line...
    # ----------------------------------------------
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId46, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint5 = NXOpen.Point3d(7.0084706058587471, 0.0, 0.0)
    endPoint5 = NXOpen.Point3d(7.0084706058587614, 12.0, 0.0)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId47, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint6 = NXOpen.Point3d(7.0084706058587614, 12.0, 0.0)
    endPoint6 = NXOpen.Point3d(67.733689615455646, -7.1054273576010019e-14, 0.0)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId48, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint7 = NXOpen.Point3d(7.0084706058587471, 0.0, 0.0)
    endPoint7 = NXOpen.Point3d(68.571278843177424, 0.0, 0.0)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder8 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject15 = sketchFindMovableObjectsBuilder8.Commit()
    
    sketchFindMovableObjectsBuilder8.Destroy()
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Line...
    # ----------------------------------------------
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId50, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint8 = NXOpen.Point3d(67.733689615455646, 0.0, 0.0)
    endPoint8 = NXOpen.Point3d(7.0084706058587471, 6.1371523564650258e-14, 0.0)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder9 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject16 = sketchFindMovableObjectsBuilder9.Commit()
    
    sketchFindMovableObjectsBuilder9.Destroy()
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder3 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects5 = [None] * 1 
    dragobjects5[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects5[0].Geometry = line5
    dragobjects5[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects5[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects5)
    
    sketchDragGeometryBuilder3.SplineLinearScale = False
    
    foundrelations8 = sketchDragGeometryBuilder3.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects6 = [None] * 1 
    dragobjects6[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects6[0].Geometry = line5
    dragobjects6[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects6[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects6)
    
    foundrelations9 = sketchDragGeometryBuilder3.FindRelations()
    
    sketchDragGeometryBuilder3.Destroy()
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences3 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences3 = dimensionPreferences3.GetNarrowDimensionPreferences()
    
    option3 = narrowDimensionPreferences3.DimensionDisplayOption
    
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder3 = sketchLinearDimensionBuilder3.Driving
    
    drivingValueBuilder3.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject5 = sketchLinearDimensionBuilder3.FirstAssociativity
    
    selectNXObject6 = sketchLinearDimensionBuilder3.SecondAssociativity
    
    point1_11 = NXOpen.Point3d(7.0084706058587471, 0.0, 0.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject5.SetValue(NXOpen.InferSnapType.SnapType.Start, line5, NXOpen.View.Null, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(7.0084706058587614, 12.0, 0.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject6.SetValue(NXOpen.InferSnapType.SnapType.End, line5, NXOpen.View.Null, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    dimensionMeasurementBuilder3 = sketchLinearDimensionBuilder3.Measurement
    
    dimensionMeasurementBuilder3.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder3 = sketchLinearDimensionBuilder3.Origin
    
    origin22 = NXOpen.Point3d(-0.1143354251339801, 6.0, 0.0)
    originBuilder3.OriginPoint = origin22
    
    originBuilder3.SetInferRelativeToGeometry(True)
    
    nXObject17 = sketchLinearDimensionBuilder3.Commit()
    
    verticalDimension2 = nXObject17
    verticalDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder3.Destroy()
    
    narrowDimensionPreferences3.Dispose()
    dimensionPreferences3.Dispose()
    sketchFindMovableObjectsBuilder10 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject18 = sketchFindMovableObjectsBuilder10.Commit()
    
    sketchFindMovableObjectsBuilder10.Destroy()
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder3 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension2)
    
    selectNXObjectList6 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations10 = sketchEditDimensionValueBuilder3.FindRelations()
    
    sketchHelpedDimensionalConstraint3 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line5] StartVertex] [[Curve Line5] EndVertex]")
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId54, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId55, None)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.DimValue = 8.0
    
    theSession.ActiveSketch.Scale(0.66666666666666663)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin23 = NXOpen.Point3d(-0.076223616755986726, 4.0, 0.0)
    verticalDimension2.AnnotationOrigin = origin23
    
    sketchEditDimensionValueBuilder3.RestoreOperation()
    
    sketchEditDimensionValueBuilder3.LoadExtraGeometry()
    
    selectNXObjectList7 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations11 = sketchEditDimensionValueBuilder3.FindRelations()
    
    nXObject19 = sketchEditDimensionValueBuilder3.Commit()
    
    theSession.SetUndoMarkName(markId56, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId56, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    selectNXObjectList8 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    objects3 = [NXOpen.NXObject.Null] * 1 
    objects3[0] = line6
    selectNXObjectList8.SetArray(objects3)
    
    sketchEditDimensionValueBuilder3.RestoreOperation()
    
    sketchEditDimensionValueBuilder3.LoadExtraGeometry()
    
    selectNXObjectList9 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    theSession.ActiveSketch.Update()
    
    theSession.SetUndoMarkName(markId57, "Edit Dimension Value - Selection")
    
    theSession.SetUndoMarkVisibility(markId57, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    selectNXObjectList10 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    objects4 = [NXOpen.NXObject.Null] * 2 
    objects4[0] = line6
    objects4[1] = line8
    selectNXObjectList10.SetArray(objects4)
    
    sketchEditDimensionValueBuilder3.RestoreOperation()
    
    sketchEditDimensionValueBuilder3.LoadExtraGeometry()
    
    selectNXObjectList11 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    theSession.ActiveSketch.Update()
    
    theSession.SetUndoMarkName(markId58, "Edit Dimension Value - Selection")
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId60, None)
    
    theSession.SetUndoMarkName(markId54, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId59, None)
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId58, None)
    
    theSession.DeleteUndoMark(markId57, None)
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.DeleteUndoMark(markId54, None)
    
    sketchFindMovableObjectsBuilder11 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject20 = sketchFindMovableObjectsBuilder11.Commit()
    
    sketchFindMovableObjectsBuilder11.Destroy()
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder4 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects7 = [None] * 1 
    dragobjects7[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects7[0].Geometry = line8
    dragobjects7[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects7[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects7)
    
    sketchDragGeometryBuilder4.SplineLinearScale = False
    
    foundrelations12 = sketchDragGeometryBuilder4.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects8 = [None] * 1 
    dragobjects8[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects8[0].Geometry = line8
    dragobjects8[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects8[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects8)
    
    foundrelations13 = sketchDragGeometryBuilder4.FindRelations()
    
    sketchDragGeometryBuilder4.Destroy()
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences4 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences4 = dimensionPreferences4.GetNarrowDimensionPreferences()
    
    option4 = narrowDimensionPreferences4.DimensionDisplayOption
    
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder4 = sketchLinearDimensionBuilder4.Driving
    
    drivingValueBuilder4.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject7 = sketchLinearDimensionBuilder4.FirstAssociativity
    
    selectNXObject8 = sketchLinearDimensionBuilder4.SecondAssociativity
    
    point1_15 = NXOpen.Point3d(45.155793076970426, 0.0, 0.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject7.SetValue(NXOpen.InferSnapType.SnapType.Start, line8, NXOpen.View.Null, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(4.6723137372391648, 4.0914349043100172e-14, 0.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject8.SetValue(NXOpen.InferSnapType.SnapType.End, line8, NXOpen.View.Null, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    dimensionMeasurementBuilder4 = sketchLinearDimensionBuilder4.Measurement
    
    dimensionMeasurementBuilder4.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder4 = sketchLinearDimensionBuilder4.Origin
    
    origin25 = NXOpen.Point3d(24.914053407104795, -4.7485373539951512, 0.0)
    originBuilder4.OriginPoint = origin25
    
    originBuilder4.SetInferRelativeToGeometry(True)
    
    nXObject21 = sketchLinearDimensionBuilder4.Commit()
    
    horizontalDimension2 = nXObject21
    horizontalDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder4.Destroy()
    
    narrowDimensionPreferences4.Dispose()
    dimensionPreferences4.Dispose()
    sketchFindMovableObjectsBuilder12 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject22 = sketchFindMovableObjectsBuilder12.Commit()
    
    sketchFindMovableObjectsBuilder12.Destroy()
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder4 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension2)
    
    selectNXObjectList12 = sketchEditDimensionValueBuilder4.ExtraGeometries
    
    foundrelations14 = sketchEditDimensionValueBuilder4.FindRelations()
    
    sketchHelpedDimensionalConstraint4 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line7] StartVertex] [[Curve Line7] EndVertex]")
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId64, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId65, None)
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.DimValue = 65.0
    
    nXObject23 = sketchEditDimensionValueBuilder4.Commit()
    
    theSession.SetUndoMarkName(markId66, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId66, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId68, None)
    
    theSession.SetUndoMarkName(markId64, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId67, None)
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId66, None)
    
    theSession.DeleteUndoMark(markId64, None)
    
    sketchFindMovableObjectsBuilder13 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject24 = sketchFindMovableObjectsBuilder13.Commit()
    
    sketchFindMovableObjectsBuilder13.Destroy()
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Sketch Drag")
    
    sketchDragGeometryBuilder5 = workPart.Sketches.CreateDragGeometryBuilder()
    
    sketchDragGeometryBuilder5.SnapRadius = 5.528088902942689
    
    sketchDragGeometryBuilder5.SplineLinearScale = False
    
    snapgeometry1 = NXOpen.Sketch.SketchGeometry()
    
    snapgeometry1.Geometry = line5
    snapgeometry1.PointType = NXOpen.Sketch.PointType.NotSet
    snapgeometry1.PointIndex = 0
    sketchDragGeometryBuilder5.SnapGeometry = snapgeometry1
    
    dragobjects9 = [None] * 1 
    dragobjects9[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects9[0].Geometry = line5
    dragobjects9[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects9[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects9)
    
    initialposition1 = NXOpen.Point3d(-20.213179294994831, 4.0375951914053267, 0.0)
    sketchDragGeometryBuilder5.InitializeDrag(initialposition1)
    
    infiniteLine1 = theSession.ActiveSketch.FindObject("YAxis")
    sketchDragGeometryBuilder5.SetSnapTarget(infiniteLine1)
    
    newposition1 = NXOpen.Point3d(18.525322486989914, 3.4094032706163837, 0.0)
    sketchDragGeometryBuilder5.DragToPoint(newposition1)
    
    nXObject25 = sketchDragGeometryBuilder5.Commit()
    
    sketchDragGeometryBuilder5.Destroy()
    
    theSession.ActiveSketch.Update()
    
    sketchFindMovableObjectsBuilder14 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject26 = sketchFindMovableObjectsBuilder14.Commit()
    
    sketchFindMovableObjectsBuilder14.Destroy()
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder6 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects10 = [None] * 1 
    dragobjects10[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects10[0].Geometry = line5
    dragobjects10[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects10[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects10)
    
    sketchDragGeometryBuilder6.SplineLinearScale = False
    
    foundrelations15 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects11 = [None] * 1 
    dragobjects11[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects11[0].Geometry = line5
    dragobjects11[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects11[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects11)
    
    foundrelations16 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects12 = [None] * 1 
    dragobjects12[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects12[0].Geometry = line5
    dragobjects12[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects12[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects12)
    
    foundrelations17 = sketchDragGeometryBuilder6.FindRelations()
    
    sketchDragGeometryBuilder6.Destroy()
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences5 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences5 = dimensionPreferences5.GetNarrowDimensionPreferences()
    
    option5 = narrowDimensionPreferences5.DimensionDisplayOption
    
    sketchLinearDimensionBuilder5 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder5 = sketchLinearDimensionBuilder5.Driving
    
    drivingValueBuilder5.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder5 = sketchLinearDimensionBuilder5.Measurement
    
    dimensionMeasurementBuilder5.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject9 = sketchLinearDimensionBuilder5.FirstAssociativity
    
    selectNXObject10 = sketchLinearDimensionBuilder5.SecondAssociativity
    
    point1_19 = NXOpen.Point3d(0.0, -6.2228728481459257, 0.0)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject9.SetValue(NXOpen.InferSnapType.SnapType.NotSet, infiniteLine1, NXOpen.View.Null, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    point1_20 = NXOpen.Point3d(18.894294858955185, 7.9999999999999964, 0.0)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject10.SetValue(NXOpen.InferSnapType.SnapType.End, line5, NXOpen.View.Null, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    originBuilder5 = sketchLinearDimensionBuilder5.Origin
    
    origin27 = NXOpen.Point3d(9.4471474294775888, 4.0375951914041348, 0.0)
    originBuilder5.OriginPoint = origin27
    
    originBuilder5.SetInferRelativeToGeometry(True)
    
    nXObject27 = sketchLinearDimensionBuilder5.Commit()
    
    perpendicularDimension1 = nXObject27
    perpendicularDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder5.Destroy()
    
    narrowDimensionPreferences5.Dispose()
    dimensionPreferences5.Dispose()
    sketchFindMovableObjectsBuilder15 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject28 = sketchFindMovableObjectsBuilder15.Commit()
    
    sketchFindMovableObjectsBuilder15.Destroy()
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder5 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension1)
    
    selectNXObjectList13 = sketchEditDimensionValueBuilder5.ExtraGeometries
    
    foundrelations18 = sketchEditDimensionValueBuilder5.FindRelations()
    
    sketchHelpedDimensionalConstraint5 = theSession.ActiveSketch.FindObject("PerpendicularDim [YAxis] [[Curve Line5] EndVertex]")
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId73, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId73, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId74, None)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.DimValue = 10.0
    
    nXObject29 = sketchEditDimensionValueBuilder5.Commit()
    
    theSession.SetUndoMarkName(markId75, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId75, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId73, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.DimValue = 5.0
    
    nXObject30 = sketchEditDimensionValueBuilder5.Commit()
    
    theSession.SetUndoMarkName(markId76, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId76, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId73, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId78, None)
    
    theSession.SetUndoMarkName(markId73, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.Destroy()
    
    theSession.DeleteUndoMark(markId77, None)
    
    theSession.SetUndoMarkVisibility(markId73, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId76, None)
    
    theSession.DeleteUndoMark(markId75, None)
    
    theSession.DeleteUndoMark(markId73, None)
    
    sketchFindMovableObjectsBuilder16 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject31 = sketchFindMovableObjectsBuilder16.Commit()
    
    sketchFindMovableObjectsBuilder16.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder2 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder2.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject32 = sketchWorkRegionBuilder2.Commit()
    
    sketchWorkRegionBuilder2.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId80, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions2 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions2.SetSelectedFromInactive(False)
    
    curves2 = [NXOpen.ICurve.Null] * 3 
    curves2[0] = line5
    curves2[1] = line6
    curves2[2] = line8
    seedPoint2 = NXOpen.Point3d(32.717755000000004, 2.6318878906319552, 0.0)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch2, curves2, seedPoint2, 0.01, selectionIntentRuleOptions2)
    
    selectionIntentRuleOptions2.Dispose()
    section2.AllowSelfIntersection(True)
    
    section2.AllowDegenerateCurves(False)
    
    rules2 = [None] * 1 
    rules2[0] = regionBoundaryRule2
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section2.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId81, None)
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId83, None)
    
    direction8 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction8
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies10[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies11)
    
    theSession.DeleteUndoMark(markId82, None)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies13)
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId84, None)
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId85, None)
    
    theSession.SetUndoMarkName(markId80, "Extrude")
    
    expression11 = extrudeBuilder2.Limits.StartExtend.Value
    expression12 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression10)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin28, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane10
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder4 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId88, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder4.UseWorkPartOrigin = False
    
    coordinates7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point10 = workPart.Points.CreatePoint(coordinates7)
    
    origin29 = NXOpen.Point3d(65.946496286981642, -0.053503713018351107, 0.0)
    matrix7 = NXOpen.Matrix3x3()
    
    matrix7.Xx = 1.0
    matrix7.Xy = 0.0
    matrix7.Xz = 0.0
    matrix7.Yx = 0.0
    matrix7.Yy = 1.0
    matrix7.Yz = 0.0
    matrix7.Zx = 0.0
    matrix7.Zy = 0.0
    matrix7.Zz = 1.0
    plane11 = workPart.Planes.CreateFixedTypePlane(origin29, matrix7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point11 = workPart.Points.CreatePoint(coordinates8)
    
    origin30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction9 = workPart.Directions.CreateDirection(origin30, vector7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector8 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction10 = workPart.Directions.CreateDirection(origin31, vector8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix8 = NXOpen.Matrix3x3()
    
    matrix8.Xx = 1.0
    matrix8.Xy = 0.0
    matrix8.Xz = 0.0
    matrix8.Yx = 0.0
    matrix8.Yy = 1.0
    matrix8.Yz = 0.0
    matrix8.Zx = 0.0
    matrix8.Zy = 0.0
    matrix8.Zz = 1.0
    plane12 = workPart.Planes.CreateFixedTypePlane(origin32, matrix8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane12, direction10, point11, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder4.CoordinateSystem = cartesianCoordinateSystem4
    
    simpleSketchInPlaceBuilder4.HorizontalReference.Value = datumAxis1
    
    point12 = simpleSketchInPlaceBuilder4.SketchOrigin
    
    simpleSketchInPlaceBuilder4.SketchOrigin = point12
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId89, None)
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject33 = simpleSketchInPlaceBuilder4.Commit()
    
    sketch3 = nXObject33
    feature5 = sketch3.Feature
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId91)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder17 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject34 = sketchFindMovableObjectsBuilder17.Commit()
    
    sketchFindMovableObjectsBuilder17.Destroy()
    
    theSession.DeleteUndoMark(markId90, None)
    
    theSession.SetUndoMarkName(markId88, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    simpleSketchInPlaceBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId87, None, True)
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_002")
    
    scaleAboutPoint21 = NXOpen.Point3d(49.486472926733086, -67.277064433451159, 0.0)
    viewCenter21 = NXOpen.Point3d(-49.486472926732944, 67.277064433451088, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(62.36931505228754, -83.073882754071462, 0.0)
    viewCenter22 = NXOpen.Point3d(-62.369315052287369, 83.07388275407142, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(77.961643815359309, -103.84235344258937, 0.0)
    viewCenter23 = NXOpen.Point3d(-77.961643815359196, 103.84235344258926, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(97.452054769199137, -129.80294180323665, 0.0)
    viewCenter24 = NXOpen.Point3d(-97.452054769199137, 129.80294180323665, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(121.81506846149891, -162.25367725404573, 0.0)
    viewCenter25 = NXOpen.Point3d(-121.81506846149891, 162.2536772540459, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(162.25367725404587, -245.25267369553853, 0.0)
    viewCenter26 = NXOpen.Point3d(-162.25367725404587, 245.25267369553862, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(131.79991013867107, -198.19910729186518, 0.0)
    viewCenter27 = NXOpen.Point3d(-131.79991013867107, 198.19910729186526, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(106.23871544511059, -158.55928583349208, 0.0)
    viewCenter28 = NXOpen.Point3d(-106.23871544511059, 158.55928583349223, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(85.63000222342751, -128.12548840147176, 0.0)
    viewCenter29 = NXOpen.Point3d(-85.630002223427454, 128.12548840147187, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(68.504001778741966, -102.5003907211774, 0.0)
    viewCenter30 = NXOpen.Point3d(-68.504001778741966, 102.50039072117752, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(55.212180538090578, -82.00031257694188, 0.0)
    viewCenter31 = NXOpen.Point3d(-55.212180538090578, 82.00031257694198, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(35.008612252300367, -10.960640284598659, 0.0)
    viewCenter32 = NXOpen.Point3d(-35.008612252300395, 10.960640284598771, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(26.436409999867898, -2.4865930197894874, 0.0)
    viewCenter33 = NXOpen.Point3d(-26.436409999867987, 2.4865930197895989, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(21.14912799989435, 0.52349326732417767, 0.0)
    viewCenter34 = NXOpen.Point3d(-21.149127999894386, -0.52349326732407053, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(15.746677481109437, 8.1246155088703667, 0.0)
    viewCenter35 = NXOpen.Point3d(-15.746677481109494, -8.1246155088702512, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Line...
    # ----------------------------------------------
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId94, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint9 = NXOpen.Point3d(7.0, -60.0, 0.0)
    endPoint9 = NXOpen.Point3d(6.9999999999999627, -70.0, 0.0)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId95, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint10 = NXOpen.Point3d(6.9999999999999627, -70.0, 0.0)
    endPoint10 = NXOpen.Point3d(65.45750817080264, -60.0, 0.0)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId96, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint11 = NXOpen.Point3d(7.0, -60.0, 0.0)
    endPoint11 = NXOpen.Point3d(65.45750817080264, -60.0, 0.0)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder18 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject35 = sketchFindMovableObjectsBuilder18.Commit()
    
    sketchFindMovableObjectsBuilder18.Destroy()
    
    scaleAboutPoint36 = NXOpen.Point3d(-30.421240750739184, 19.499077221288811, 0.0)
    viewCenter36 = NXOpen.Point3d(30.421240750739138, -19.499077221288708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(-23.264878389111573, 14.419936144403286, 0.0)
    viewCenter37 = NXOpen.Point3d(23.264878389111502, -14.419936144403176, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(-18.183057026697345, -1.1578833483981192, 0.0)
    viewCenter38 = NXOpen.Point3d(18.183057026697288, 1.1578833483982363, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(-22.29997559877976, -3.1627369238653409, 0.0)
    viewCenter39 = NXOpen.Point3d(22.299975598779685, 3.1627369238654506, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint39, viewCenter39)
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder7 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects13 = [None] * 1 
    dragobjects13[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects13[0].Geometry = line11
    dragobjects13[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects13[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects13)
    
    sketchDragGeometryBuilder7.SplineLinearScale = False
    
    foundrelations19 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects14 = [None] * 1 
    dragobjects14[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects14[0].Geometry = line11
    dragobjects14[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects14[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects14)
    
    foundrelations20 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects15 = [None] * 1 
    dragobjects15[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects15[0].Geometry = line11
    dragobjects15[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects15[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects15)
    
    foundrelations21 = sketchDragGeometryBuilder7.FindRelations()
    
    sketchDragGeometryBuilder7.Destroy()
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences6 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences6 = dimensionPreferences6.GetNarrowDimensionPreferences()
    
    option6 = narrowDimensionPreferences6.DimensionDisplayOption
    
    sketchLinearDimensionBuilder6 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder6 = sketchLinearDimensionBuilder6.Driving
    
    drivingValueBuilder6.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder6 = sketchLinearDimensionBuilder6.Measurement
    
    dimensionMeasurementBuilder6.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject11 = sketchLinearDimensionBuilder6.FirstAssociativity
    
    selectNXObject12 = sketchLinearDimensionBuilder6.SecondAssociativity
    
    point1_25 = NXOpen.Point3d(11.101317648777023, -60.0, 0.0)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject11.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line11, NXOpen.View.Null, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    point1_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject12.SetValue(NXOpen.InferSnapType.SnapType.Mid, line3, NXOpen.View.Null, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    originBuilder6 = sketchLinearDimensionBuilder6.Origin
    
    origin35 = NXOpen.Point3d(3.8645467212884057, -30.0, 0.0)
    originBuilder6.OriginPoint = origin35
    
    originBuilder6.SetInferRelativeToGeometry(True)
    
    nXObject36 = sketchLinearDimensionBuilder6.Commit()
    
    perpendicularDimension2 = nXObject36
    perpendicularDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder6.Destroy()
    
    narrowDimensionPreferences6.Dispose()
    dimensionPreferences6.Dispose()
    sketchFindMovableObjectsBuilder19 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject37 = sketchFindMovableObjectsBuilder19.Commit()
    
    sketchFindMovableObjectsBuilder19.Destroy()
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder6 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension2)
    
    selectNXObjectList14 = sketchEditDimensionValueBuilder6.ExtraGeometries
    
    foundrelations22 = sketchEditDimensionValueBuilder6.FindRelations()
    
    sketchHelpedDimensionalConstraint6 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line10] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line3] EndVertex]")
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId100, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId100, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId101, None)
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    nXObject38 = sketchEditDimensionValueBuilder6.Commit()
    
    theSession.SetUndoMarkName(markId102, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId102, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId100, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId104, None)
    
    theSession.SetUndoMarkName(markId100, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.Destroy()
    
    theSession.DeleteUndoMark(markId103, None)
    
    theSession.SetUndoMarkVisibility(markId100, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId102, None)
    
    theSession.DeleteUndoMark(markId100, None)
    
    sketchFindMovableObjectsBuilder20 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject39 = sketchFindMovableObjectsBuilder20.Commit()
    
    sketchFindMovableObjectsBuilder20.Destroy()
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder8 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects16 = [None] * 1 
    dragobjects16[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects16[0].Geometry = line9
    dragobjects16[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects16[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects16)
    
    sketchDragGeometryBuilder8.SplineLinearScale = False
    
    foundrelations23 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects17 = [None] * 1 
    dragobjects17[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects17[0].Geometry = line9
    dragobjects17[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects17[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects17)
    
    foundrelations24 = sketchDragGeometryBuilder8.FindRelations()
    
    sketchDragGeometryBuilder8.Destroy()
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences7 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences7 = dimensionPreferences7.GetNarrowDimensionPreferences()
    
    option7 = narrowDimensionPreferences7.DimensionDisplayOption
    
    sketchLinearDimensionBuilder7 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder7 = sketchLinearDimensionBuilder7.Driving
    
    drivingValueBuilder7.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject13 = sketchLinearDimensionBuilder7.FirstAssociativity
    
    selectNXObject14 = sketchLinearDimensionBuilder7.SecondAssociativity
    
    point1_29 = NXOpen.Point3d(7.0, -60.0, 0.0)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject13.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, NXOpen.View.Null, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    point1_30 = NXOpen.Point3d(6.9999999999999627, -70.0, 0.0)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject14.SetValue(NXOpen.InferSnapType.SnapType.End, line9, NXOpen.View.Null, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    dimensionMeasurementBuilder7 = sketchLinearDimensionBuilder7.Measurement
    
    dimensionMeasurementBuilder7.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder7 = sketchLinearDimensionBuilder7.Origin
    
    origin37 = NXOpen.Point3d(2.441404140164618, -65.0, 0.0)
    originBuilder7.OriginPoint = origin37
    
    originBuilder7.SetInferRelativeToGeometry(True)
    
    nXObject40 = sketchLinearDimensionBuilder7.Commit()
    
    verticalDimension3 = nXObject40
    verticalDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder7.Destroy()
    
    narrowDimensionPreferences7.Dispose()
    dimensionPreferences7.Dispose()
    sketchFindMovableObjectsBuilder21 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject41 = sketchFindMovableObjectsBuilder21.Commit()
    
    sketchFindMovableObjectsBuilder21.Destroy()
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder7 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension3)
    
    selectNXObjectList15 = sketchEditDimensionValueBuilder7.ExtraGeometries
    
    foundrelations25 = sketchEditDimensionValueBuilder7.FindRelations()
    
    sketchHelpedDimensionalConstraint7 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line8] StartVertex] [[Curve Line8] EndVertex]")
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId108, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId108, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId109, None)
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.DimValue = 8.0
    
    nXObject42 = sketchEditDimensionValueBuilder7.Commit()
    
    theSession.SetUndoMarkName(markId110, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId110, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId108, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId112, None)
    
    theSession.SetUndoMarkName(markId108, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId111, None)
    
    theSession.SetUndoMarkVisibility(markId108, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId110, None)
    
    theSession.DeleteUndoMark(markId108, None)
    
    sketchFindMovableObjectsBuilder22 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject43 = sketchFindMovableObjectsBuilder22.Commit()
    
    sketchFindMovableObjectsBuilder22.Destroy()
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder9 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects18 = [None] * 1 
    dragobjects18[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects18[0].Geometry = line11
    dragobjects18[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects18[0].PointIndex = 0
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects18)
    
    sketchDragGeometryBuilder9.SplineLinearScale = False
    
    foundrelations26 = sketchDragGeometryBuilder9.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects19 = [None] * 1 
    dragobjects19[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects19[0].Geometry = line11
    dragobjects19[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects19[0].PointIndex = 0
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects19)
    
    foundrelations27 = sketchDragGeometryBuilder9.FindRelations()
    
    sketchDragGeometryBuilder9.Destroy()
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences8 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences8 = dimensionPreferences8.GetNarrowDimensionPreferences()
    
    option8 = narrowDimensionPreferences8.DimensionDisplayOption
    
    sketchLinearDimensionBuilder8 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder8 = sketchLinearDimensionBuilder8.Driving
    
    drivingValueBuilder8.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject15 = sketchLinearDimensionBuilder8.FirstAssociativity
    
    selectNXObject16 = sketchLinearDimensionBuilder8.SecondAssociativity
    
    point1_33 = NXOpen.Point3d(7.0, -60.0, 0.0)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject15.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, NXOpen.View.Null, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    point1_34 = NXOpen.Point3d(65.457508170802626, -60.0, 0.0)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject16.SetValue(NXOpen.InferSnapType.SnapType.End, line11, NXOpen.View.Null, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    dimensionMeasurementBuilder8 = sketchLinearDimensionBuilder8.Measurement
    
    dimensionMeasurementBuilder8.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder8 = sketchLinearDimensionBuilder8.Origin
    
    origin39 = NXOpen.Point3d(36.228754085401313, -55.441404140164657, 0.0)
    originBuilder8.OriginPoint = origin39
    
    originBuilder8.SetInferRelativeToGeometry(True)
    
    nXObject44 = sketchLinearDimensionBuilder8.Commit()
    
    horizontalDimension3 = nXObject44
    horizontalDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder8.Destroy()
    
    narrowDimensionPreferences8.Dispose()
    dimensionPreferences8.Dispose()
    sketchFindMovableObjectsBuilder23 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject45 = sketchFindMovableObjectsBuilder23.Commit()
    
    sketchFindMovableObjectsBuilder23.Destroy()
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder8 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension3)
    
    selectNXObjectList16 = sketchEditDimensionValueBuilder8.ExtraGeometries
    
    foundrelations28 = sketchEditDimensionValueBuilder8.FindRelations()
    
    sketchHelpedDimensionalConstraint8 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line10] StartVertex] [[Curve Line10] EndVertex]")
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId116, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId116, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId117, None)
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder8.DimValue = 65.0
    
    nXObject46 = sketchEditDimensionValueBuilder8.Commit()
    
    theSession.SetUndoMarkName(markId118, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId118, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId116, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId120, None)
    
    theSession.SetUndoMarkName(markId116, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder8.Destroy()
    
    theSession.DeleteUndoMark(markId119, None)
    
    theSession.SetUndoMarkVisibility(markId116, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId118, None)
    
    theSession.DeleteUndoMark(markId116, None)
    
    sketchFindMovableObjectsBuilder24 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject47 = sketchFindMovableObjectsBuilder24.Commit()
    
    sketchFindMovableObjectsBuilder24.Destroy()
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder10 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects20 = [None] * 1 
    dragobjects20[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects20[0].Geometry = line9
    dragobjects20[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects20[0].PointIndex = 0
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects20)
    
    sketchDragGeometryBuilder10.SplineLinearScale = False
    
    foundrelations29 = sketchDragGeometryBuilder10.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects21 = [None] * 1 
    dragobjects21[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects21[0].Geometry = line9
    dragobjects21[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects21[0].PointIndex = 0
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects21)
    
    foundrelations30 = sketchDragGeometryBuilder10.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects22 = [None] * 1 
    dragobjects22[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects22[0].Geometry = line9
    dragobjects22[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects22[0].PointIndex = 0
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects22)
    
    foundrelations31 = sketchDragGeometryBuilder10.FindRelations()
    
    sketchDragGeometryBuilder10.Destroy()
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder11 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects23 = [None] * 1 
    dragobjects23[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects23[0].Geometry = line9
    dragobjects23[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects23[0].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects23)
    
    sketchDragGeometryBuilder11.SplineLinearScale = False
    
    foundrelations32 = sketchDragGeometryBuilder11.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects24 = [None] * 1 
    dragobjects24[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects24[0].Geometry = line9
    dragobjects24[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects24[0].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects24)
    
    foundrelations33 = sketchDragGeometryBuilder11.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    sketchDragGeometryBuilder11.Destroy()
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences9 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences9 = dimensionPreferences9.GetNarrowDimensionPreferences()
    
    option9 = narrowDimensionPreferences9.DimensionDisplayOption
    
    sketchLinearDimensionBuilder9 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder9 = sketchLinearDimensionBuilder9.Driving
    
    drivingValueBuilder9.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder9 = sketchLinearDimensionBuilder9.Measurement
    
    dimensionMeasurementBuilder9.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject17 = sketchLinearDimensionBuilder9.FirstAssociativity
    
    selectNXObject18 = sketchLinearDimensionBuilder9.SecondAssociativity
    
    infiniteLine4 = theSession.ActiveSketch.FindObject("YAxis")
    point1_39 = NXOpen.Point3d(0.0, -72.495358087904606, 0.0)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject17.SetValue(NXOpen.InferSnapType.SnapType.NotSet, infiniteLine4, NXOpen.View.Null, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(7.0, -60.0, 0.0)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject18.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, NXOpen.View.Null, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    originBuilder9 = sketchLinearDimensionBuilder9.Origin
    
    origin42 = NXOpen.Point3d(3.4999999999999947, -60.686603876361637, 0.0)
    originBuilder9.OriginPoint = origin42
    
    originBuilder9.SetInferRelativeToGeometry(True)
    
    nXObject48 = sketchLinearDimensionBuilder9.Commit()
    
    perpendicularDimension3 = nXObject48
    perpendicularDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder9.Destroy()
    
    narrowDimensionPreferences9.Dispose()
    dimensionPreferences9.Dispose()
    sketchFindMovableObjectsBuilder25 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject49 = sketchFindMovableObjectsBuilder25.Commit()
    
    sketchFindMovableObjectsBuilder25.Destroy()
    
    theAnnotationsAngularDimensionUtils = NXOpen.Annotations.AngularDimensionUtils.GetAngularDimensionUtils(theSession)
    
    theAnnotationsAngularDimensionUtils.SetAllowSupplementaryAngle(perpendicularDimension3, True)
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Object Origin")
    
    perpendicularDimension3.LeaderOrientation = NXOpen.Annotations.LeaderOrientation.FromLeft
    
    perpendicularDimension3.IsOriginCentered = True
    
    origin43 = perpendicularDimension3.AnnotationOrigin
    
    location1 = NXOpen.Point3d(3.194475339113545, -76.24775782808365, 0.0)
    changed1 = theAnnotationsAngularDimensionUtils.InferQuadrantAngleFromLocation(perpendicularDimension3, location1)
    
    origin44 = NXOpen.Point3d(3.194475339113545, -76.24775782808365, 0.0)
    perpendicularDimension3.AnnotationOrigin = origin44
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId124)
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder9 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension3)
    
    selectNXObjectList17 = sketchEditDimensionValueBuilder9.ExtraGeometries
    
    foundrelations34 = sketchEditDimensionValueBuilder9.FindRelations()
    
    sketchHelpedDimensionalConstraint9 = theSession.ActiveSketch.FindObject("PerpendicularDim [YAxis] [[Curve Line8] StartVertex]")
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId126, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId126, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId127, None)
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder9.Destroy()
    
    theSession.UndoToMark(markId126, None)
    
    theSession.DeleteUndoMark(markId126, None)
    
    theSession.DeleteUndoMark(markId126, None)
    
    sketchFindMovableObjectsBuilder26 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject50 = sketchFindMovableObjectsBuilder26.Commit()
    
    sketchFindMovableObjectsBuilder26.Destroy()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder10 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension3)
    
    selectNXObjectList18 = sketchEditDimensionValueBuilder10.ExtraGeometries
    
    foundrelations35 = sketchEditDimensionValueBuilder10.FindRelations()
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId130, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId130, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId131, None)
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder10.DimValue = 5.0
    
    nXObject51 = sketchEditDimensionValueBuilder10.Commit()
    
    theSession.SetUndoMarkName(markId132, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId132, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId130, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId134, None)
    
    theSession.SetUndoMarkName(markId130, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder10.Destroy()
    
    theSession.DeleteUndoMark(markId133, None)
    
    theSession.SetUndoMarkVisibility(markId130, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId132, None)
    
    theSession.DeleteUndoMark(markId130, None)
    
    sketchFindMovableObjectsBuilder27 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject52 = sketchFindMovableObjectsBuilder27.Commit()
    
    sketchFindMovableObjectsBuilder27.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder3 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder3.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject53 = sketchWorkRegionBuilder3.Commit()
    
    sketchWorkRegionBuilder3.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies15)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId136, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions3 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions3.SetSelectedFromInactive(False)
    
    curves3 = [NXOpen.ICurve.Null] * 3 
    curves3[0] = line9
    curves3[1] = line10
    curves3[2] = line11
    seedPoint3 = NXOpen.Point3d(42.282245000000032, -61.956696109367996, 0.0)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch3, curves3, seedPoint3, 0.01, selectionIntentRuleOptions3)
    
    selectionIntentRuleOptions3.Dispose()
    section3.AllowSelfIntersection(True)
    
    section3.AllowDegenerateCurves(False)
    
    rules3 = [None] * 1 
    rules3[0] = regionBoundaryRule3
    helpPoint3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section3.AddToSection(rules3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId137, None)
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId139, None)
    
    direction11 = workPart.Directions.CreateDirection(sketch3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction11
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies17)
    
    theSession.DeleteUndoMark(markId138, None)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies18)
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId140, None)
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    feature6 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId141, None)
    
    theSession.SetUndoMarkName(markId136, "Extrude")
    
    expression16 = extrudeBuilder3.Limits.StartExtend.Value
    expression17 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression15)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.91406937317798842
    rotMatrix2.Xy = 0.35965886718735962
    rotMatrix2.Xz = 0.1874104593439361
    rotMatrix2.Yx = -0.25779279913676112
    rotMatrix2.Yy = 0.15853530460088491
    rotMatrix2.Yz = 0.9531051515485256
    rotMatrix2.Zx = 0.31308154485889678
    rotMatrix2.Zy = -0.91951729535045201
    rotMatrix2.Zz = 0.2376297326096985
    translation2 = NXOpen.Point3d(-39.697987557362168, -1.3445146369126775, 7.5754963971071589)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.6469360501956235)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin45, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane13
    
    expression18 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression19 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder5 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId144, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder5.UseWorkPartOrigin = False
    
    coordinates9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point13 = workPart.Points.CreatePoint(coordinates9)
    
    origin46 = NXOpen.Point3d(65.779829540842115, 0.0, 35.779829540842123)
    matrix9 = NXOpen.Matrix3x3()
    
    matrix9.Xx = 1.0
    matrix9.Xy = 0.0
    matrix9.Xz = 0.0
    matrix9.Yx = -0.0
    matrix9.Yy = 0.0
    matrix9.Yz = 1.0
    matrix9.Zx = 0.0
    matrix9.Zy = -1.0
    matrix9.Zz = 0.0
    plane14 = workPart.Planes.CreateFixedTypePlane(origin46, matrix9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point14 = workPart.Points.CreatePoint(coordinates10)
    
    origin47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector9 = NXOpen.Vector3d(0.0, -1.0, 0.0)
    direction12 = workPart.Directions.CreateDirection(origin47, vector9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector10 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction13 = workPart.Directions.CreateDirection(origin48, vector10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix10 = NXOpen.Matrix3x3()
    
    matrix10.Xx = 1.0
    matrix10.Xy = 0.0
    matrix10.Xz = 0.0
    matrix10.Yx = -0.0
    matrix10.Yy = 0.0
    matrix10.Yz = 1.0
    matrix10.Zx = 0.0
    matrix10.Zy = -1.0
    matrix10.Zz = 0.0
    plane15 = workPart.Planes.CreateFixedTypePlane(origin49, matrix10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane15, direction13, point14, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder5.CoordinateSystem = cartesianCoordinateSystem5
    
    simpleSketchInPlaceBuilder5.HorizontalReference.Value = datumAxis1
    
    point15 = simpleSketchInPlaceBuilder5.SketchOrigin
    
    simpleSketchInPlaceBuilder5.SketchOrigin = point15
    
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId145, None)
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject54 = simpleSketchInPlaceBuilder5.Commit()
    
    sketch4 = nXObject54
    feature7 = sketch4.Feature
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId147)
    
    sketch4.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder28 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject55 = sketchFindMovableObjectsBuilder28.Commit()
    
    sketchFindMovableObjectsBuilder28.Destroy()
    
    theSession.DeleteUndoMark(markId146, None)
    
    theSession.SetUndoMarkName(markId144, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    simpleSketchInPlaceBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression19)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression18)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId143, None, True)
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_003")
    
    scaleAboutPoint40 = NXOpen.Point3d(73.616240717454176, 9.2020300896817293, 0.0)
    viewCenter40 = NXOpen.Point3d(-73.616240717454033, -9.2020300896817986, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(92.02030089681773, 10.991313718230982, 0.0)
    viewCenter41 = NXOpen.Point3d(-92.020300896817545, -10.991313718231025, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(115.66440598836114, 11.183022678432717, 0.0)
    viewCenter42 = NXOpen.Point3d(-115.66440598836093, -11.183022678432717, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(93.042748684560138, 7.9239703550037275, 0.0)
    viewCenter43 = NXOpen.Point3d(-93.042748684559925, -7.923970355003771, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(74.434198947648113, 5.9301971689060036, 0.0)
    viewCenter44 = NXOpen.Point3d(-74.4341989476479, -5.9301971689060728, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(59.547359158118525, 4.7441577351248032, 0.0)
    viewCenter45 = NXOpen.Point3d(-59.547359158118361, -4.7441577351248592, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(47.637887326494827, 3.795326188099843, 0.0)
    viewCenter46 = NXOpen.Point3d(-47.637887326494649, -3.7953261880998874, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(38.110309861195837, 3.0362609504798739, 0.0)
    viewCenter47 = NXOpen.Point3d(-38.110309861195752, -3.0362609504799098, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(30.488247888956671, 2.4290087603838995, 0.0)
    viewCenter48 = NXOpen.Point3d(-30.488247888956586, -2.4290087603839279, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId150, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(74.498465925793425, 0.0, 0.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 4.7463460500979302, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId151, "Curve")
    
    sketchFindMovableObjectsBuilder29 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject56 = sketchFindMovableObjectsBuilder29.Commit()
    
    sketchFindMovableObjectsBuilder29.Destroy()
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder12 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects25 = [None] * 1 
    dragobjects25[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects25[0].Geometry = arc1
    dragobjects25[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects25[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects25)
    
    sketchDragGeometryBuilder12.SplineLinearScale = False
    
    foundrelations36 = sketchDragGeometryBuilder12.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects26 = [None] * 1 
    dragobjects26[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects26[0].Geometry = arc1
    dragobjects26[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects26[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects26)
    
    foundrelations37 = sketchDragGeometryBuilder12.FindRelations()
    
    sketchDragGeometryBuilder12.Destroy()
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences10 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences10 = dimensionPreferences10.GetNarrowDimensionPreferences()
    
    option10 = narrowDimensionPreferences10.DimensionDisplayOption
    
    sketchRadialDimensionBuilder1 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder10 = sketchRadialDimensionBuilder1.Driving
    
    drivingValueBuilder10.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject19 = sketchRadialDimensionBuilder1.FirstAssociativity
    
    point1_42 = NXOpen.Point3d(74.498465925793425, 0.0, 0.0)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject19.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, NXOpen.View.Null, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    dimensionMeasurementBuilder10 = sketchRadialDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder10.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder10 = sketchRadialDimensionBuilder1.Origin
    
    origin51 = NXOpen.Point3d(84.670144138943414, 0.0, 5.2217200553990768)
    originBuilder10.OriginPoint = origin51
    
    originBuilder10.SetInferRelativeToGeometry(True)
    
    nXObject57 = sketchRadialDimensionBuilder1.Commit()
    
    sketchRadialDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences10.Dispose()
    dimensionPreferences10.Dispose()
    sketchFindMovableObjectsBuilder30 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject58 = sketchFindMovableObjectsBuilder30.Commit()
    
    sketchFindMovableObjectsBuilder30.Destroy()
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension1 = nXObject57
    sketchEditDimensionValueBuilder11 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension1)
    
    selectNXObjectList19 = sketchEditDimensionValueBuilder11.ExtraGeometries
    
    foundrelations38 = sketchEditDimensionValueBuilder11.FindRelations()
    
    sketchDimensionalConstraint1 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc1]")
    sketchDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId155, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId155, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId156, None)
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder11.DimValue = 8.0
    
    theSession.ActiveSketch.Scale(0.84275355352897729)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin52 = NXOpen.Point3d(71.35606485090527, 0.0, 4.4006231322211002)
    diameterDimension1.AnnotationOrigin = origin52
    
    sketchEditDimensionValueBuilder11.RestoreOperation()
    
    sketchEditDimensionValueBuilder11.LoadExtraGeometry()
    
    selectNXObjectList20 = sketchEditDimensionValueBuilder11.ExtraGeometries
    
    foundrelations39 = sketchEditDimensionValueBuilder11.FindRelations()
    
    nXObject59 = sketchEditDimensionValueBuilder11.Commit()
    
    theSession.SetUndoMarkName(markId157, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId157, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId155, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId159, None)
    
    theSession.SetUndoMarkName(markId155, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder11.Destroy()
    
    theSession.DeleteUndoMark(markId158, None)
    
    theSession.SetUndoMarkVisibility(markId155, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId157, None)
    
    theSession.DeleteUndoMark(markId155, None)
    
    sketchFindMovableObjectsBuilder31 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject60 = sketchFindMovableObjectsBuilder31.Commit()
    
    sketchFindMovableObjectsBuilder31.Destroy()
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder13 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects27 = [None] * 1 
    dragobjects27[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects27[0].Geometry = arc1
    dragobjects27[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects27[0].PointIndex = 0
    sketchDragGeometryBuilder13.SetDragGeometry(dragobjects27)
    
    sketchDragGeometryBuilder13.SplineLinearScale = False
    
    foundrelations40 = sketchDragGeometryBuilder13.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    theSession.SetUndoMarkVisibility(markId160, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkName(markId160, "Sketch Drag")
    
    sketchDragGeometryBuilder13.SnapRadius = 3.5379768978833197
    
    sketchDragGeometryBuilder13.SplineLinearScale = False
    
    snapgeometry2 = NXOpen.Sketch.SketchGeometry()
    
    snapgeometry2.Geometry = arc1
    snapgeometry2.PointType = NXOpen.Sketch.PointType.Center
    snapgeometry2.PointIndex = 0
    sketchDragGeometryBuilder13.SnapGeometry = snapgeometry2
    
    dragobjects28 = [None] * 1 
    dragobjects28[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects28[0].Geometry = arc1
    dragobjects28[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects28[0].PointIndex = 0
    sketchDragGeometryBuilder13.SetDragGeometry(dragobjects28)
    
    initialposition2 = NXOpen.Point3d(62.783846891419842, 0.0, 0.0)
    sketchDragGeometryBuilder13.InitializeDrag(initialposition2)
    
    sketchDragGeometryBuilder13.SetSnapTarget(line1)
    
    snaphelppoint1 = NXOpen.Point3d(74.766494478664328, 0.0, 0.0)
    sketchDragGeometryBuilder13.SetSnapPointTarget(line1, snaphelppoint1)
    
    newposition2 = NXOpen.Point3d(74.766494478664328, 0.0, 0.14677442482598657)
    sketchDragGeometryBuilder13.DragToPoint(newposition2)
    
    nXObject61 = sketchDragGeometryBuilder13.Commit()
    
    sketchDragGeometryBuilder13.Destroy()
    
    theSession.ActiveSketch.Update()
    
    sketchFindMovableObjectsBuilder32 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject62 = sketchFindMovableObjectsBuilder32.Commit()
    
    sketchFindMovableObjectsBuilder32.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId162, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 6.4158598548190851, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder33 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject63 = sketchFindMovableObjectsBuilder33.Commit()
    
    sketchFindMovableObjectsBuilder33.Destroy()
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder14 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects29 = [None] * 1 
    dragobjects29[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects29[0].Geometry = arc2
    dragobjects29[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects29[0].PointIndex = 0
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects29)
    
    sketchDragGeometryBuilder14.SplineLinearScale = False
    
    foundrelations41 = sketchDragGeometryBuilder14.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects30 = [None] * 1 
    dragobjects30[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects30[0].Geometry = arc2
    dragobjects30[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects30[0].PointIndex = 0
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects30)
    
    foundrelations42 = sketchDragGeometryBuilder14.FindRelations()
    
    sketchDragGeometryBuilder14.Destroy()
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences11 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences11 = dimensionPreferences11.GetNarrowDimensionPreferences()
    
    option11 = narrowDimensionPreferences11.DimensionDisplayOption
    
    sketchRadialDimensionBuilder2 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder11 = sketchRadialDimensionBuilder2.Driving
    
    drivingValueBuilder11.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject20 = sketchRadialDimensionBuilder2.FirstAssociativity
    
    point1_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject20.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, NXOpen.View.Null, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    dimensionMeasurementBuilder11 = sketchRadialDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder11.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder11 = sketchRadialDimensionBuilder2.Origin
    
    origin54 = NXOpen.Point3d(10.842383637913484, 0.0, 5.2268958660216498)
    originBuilder11.OriginPoint = origin54
    
    originBuilder11.SetInferRelativeToGeometry(True)
    
    nXObject64 = sketchRadialDimensionBuilder2.Commit()
    
    sketchRadialDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences11.Dispose()
    dimensionPreferences11.Dispose()
    sketchFindMovableObjectsBuilder34 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject65 = sketchFindMovableObjectsBuilder34.Commit()
    
    sketchFindMovableObjectsBuilder34.Destroy()
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension2 = nXObject64
    sketchEditDimensionValueBuilder12 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension2)
    
    selectNXObjectList21 = sketchEditDimensionValueBuilder12.ExtraGeometries
    
    foundrelations43 = sketchEditDimensionValueBuilder12.FindRelations()
    
    sketchDimensionalConstraint2 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc2]")
    sketchDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId166, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId166, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId167, None)
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder12.DimValue = 9.0
    
    nXObject66 = sketchEditDimensionValueBuilder12.Commit()
    
    theSession.SetUndoMarkName(markId168, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId168, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId166, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder12.DimValue = 8.0
    
    nXObject67 = sketchEditDimensionValueBuilder12.Commit()
    
    theSession.SetUndoMarkName(markId169, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId169, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId166, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId171, None)
    
    theSession.SetUndoMarkName(markId166, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder12.Destroy()
    
    theSession.DeleteUndoMark(markId170, None)
    
    theSession.SetUndoMarkVisibility(markId166, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId169, None)
    
    theSession.DeleteUndoMark(markId168, None)
    
    theSession.DeleteUndoMark(markId166, None)
    
    sketchFindMovableObjectsBuilder35 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject68 = sketchFindMovableObjectsBuilder35.Commit()
    
    sketchFindMovableObjectsBuilder35.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder4 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder4.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject69 = sketchWorkRegionBuilder4.Commit()
    
    sketchWorkRegionBuilder4.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Revolve...
    # ----------------------------------------------
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    revolveBuilder1 = workPart.Features.CreateRevolveBuilder(NXOpen.Features.Feature.Null)
    
    revolveBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    revolveBuilder1.Limits.EndExtend.Value.SetFormula("360")
    
    revolveBuilder1.Tolerance = 0.01
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    revolveBuilder1.Section = section4
    
    smartVolumeProfileBuilder4 = revolveBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId173, "Revolve Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    starthelperpoint1 = [None] * 3 
    starthelperpoint1[0] = 0.0
    starthelperpoint1[1] = 0.0
    starthelperpoint1[2] = 0.0
    revolveBuilder1.SetStartLimitHelperPoint(starthelperpoint1)
    
    endhelperpoint1 = [None] * 3 
    endhelperpoint1[0] = 0.0
    endhelperpoint1[1] = 0.0
    endhelperpoint1[2] = 0.0
    revolveBuilder1.SetEndLimitHelperPoint(endhelperpoint1)
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions4 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions4.SetSelectedFromInactive(False)
    
    curves4 = [NXOpen.ICurve.Null] * 2 
    curves4[0] = arc1
    curves4[1] = arc2
    seedPoint4 = NXOpen.Point3d(-0.52680691912656685, 0.0, -0.26249875240917825)
    regionBoundaryRule4 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch4, curves4, seedPoint4, 0.01, selectionIntentRuleOptions4)
    
    selectionIntentRuleOptions4.Dispose()
    selectionIntentRuleOptions5 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions5.SetSelectedFromInactive(False)
    
    curves5 = [NXOpen.ICurve.Null] * 2 
    curves5[0] = arc1
    curves5[1] = arc2
    seedPoint5 = NXOpen.Point3d(74.239687559537984, 0.0, -0.26249875240906312)
    regionBoundaryRule5 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch4, curves5, seedPoint5, 0.01, selectionIntentRuleOptions5)
    
    selectionIntentRuleOptions5.Dispose()
    section4.AllowSelfIntersection(False)
    
    section4.AllowDegenerateCurves(False)
    
    rules4 = [None] * 2 
    rules4[0] = regionBoundaryRule4
    rules4[1] = regionBoundaryRule5
    helpPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section4.AddToSection(rules4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId174, None)
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId176, None)
    
    revolveBuilder1.Section = section4
    
    expression20 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression21 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId175, None)
    
    revolveBuilder1.Section = section4
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.99509871386259541
    rotMatrix3.Xy = -0.054068583164033845
    rotMatrix3.Xz = 0.082795760662265946
    rotMatrix3.Yx = -0.057350839051058498
    rotMatrix3.Yy = 0.36652655507225651
    rotMatrix3.Yz = 0.92863833955259378
    rotMatrix3.Zx = -0.080557004221536554
    rotMatrix3.Zy = -0.92883522367613369
    rotMatrix3.Zz = 0.36162922493813093
    translation3 = NXOpen.Point3d(-54.352008424465687, -2.5258371100607757, 21.262227473765723)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 0.6469360501956235)
    
    revolveBuilder1.Destroy()
    
    section4.Destroy()
    
    workPart.MeasureManager.SetPartTransientModification()
    
    workPart.Expressions.Delete(expression20)
    
    workPart.MeasureManager.ClearPartTransientModification()
    
    workPart.MeasureManager.SetPartTransientModification()
    
    workPart.Expressions.Delete(expression21)
    
    workPart.MeasureManager.ClearPartTransientModification()
    
    theSession.UndoToMark(markId173, None)
    
    theSession.DeleteUndoMark(markId173, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Hole...
    # ----------------------------------------------
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    holePackageBuilder1 = workPart.Features.CreateHolePackageBuilder(NXOpen.Features.HolePackage.Null)
    
    holePackageBuilder1.StartHoleData.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = NXOpen.Body.Null
    holePackageBuilder1.StartHoleData.BooleanOperation.SetTargetBodies(targetBodies19)
    
    holePackageBuilder1.MiddleHoleData.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies20 = []
    holePackageBuilder1.MiddleHoleData.BooleanOperation.SetTargetBodies(targetBodies20)
    
    holePackageBuilder1.EndHoleData.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = NXOpen.Body.Null
    holePackageBuilder1.EndHoleData.BooleanOperation.SetTargetBodies(targetBodies21)
    
    holePackageBuilder1.Tolerance = 0.01
    
    holePackageBuilder1.ScrewStandard = "ISO"
    
    holePackageBuilder1.ScrewClearanceHoleDiameter.SetFormula("1.7")
    
    holePackageBuilder1.ScrewClearanceStartChamferOffset.SetFormula("0.2")
    
    holePackageBuilder1.ScrewClearanceEndChamferOffset.SetFormula("0.2")
    
    holePackageBuilder1.MiddleHoleData.HoleDiameter.SetFormula("1.7")
    
    holePackageBuilder1.MiddleHoleData.StartChamferOffset.SetFormula("0.2")
    
    holePackageBuilder1.MiddleHoleData.EndChamferOffset.SetFormula("0.2")
    
    holePackageBuilder1.EndHoleData.HoleDiameter.SetFormula("1.7")
    
    holePackageBuilder1.EndHoleData.ScrewClearanceStartChamferOffset.SetFormula("0.2")
    
    holePackageBuilder1.EndHoleData.ScrewClearanceEndChamferOffset.SetFormula("0.2")
    
    holePackageBuilder1.StartHoleData.HoleDiameter.SetFormula("1.7")
    
    holePackageBuilder1.StartHoleData.StartChamferOffset.SetFormula("0.2")
    
    holePackageBuilder1.StartHoleData.EndChamferOffset.SetFormula("0.2")
    
    holePackageBuilder1.ThreadSize = "M1.0 x 0.25"
    
    holePackageBuilder1.EndHoleData.ThreadSize = "M1.0 x 0.25"
    
    holePackageBuilder1.ThreadStandard = "Metric Coarse"
    
    holePackageBuilder1.TapDrillDiameter.SetFormula("0.75")
    
    holePackageBuilder1.ThreadedReliefDepth.SetFormula("0.5")
    
    holePackageBuilder1.ThreadedReliefDiameter.SetFormula("1")
    
    holePackageBuilder1.ThreadedReliefChamferOffset.SetFormula("0.08")
    
    holePackageBuilder1.ThreadedStartChamferDiameter.SetFormula("1")
    
    holePackageBuilder1.ThreadedEndChamferDiameter.SetFormula("1")
    
    holePackageBuilder1.ThreadedHoleDepth.SetFormula("2")
    
    holePackageBuilder1.ThreadDepth.SetFormula("1.5")
    
    holePackageBuilder1.EndHoleData.TapDrillDiameter.SetFormula("0.75")
    
    holePackageBuilder1.EndHoleData.ThreadedStartChamferDiameter.SetFormula("1")
    
    holePackageBuilder1.EndHoleData.ThreadedEndChamferDiameter.SetFormula("1")
    
    holePackageBuilder1.EndHoleData.ThreadedReliefDepth.SetFormula("0.5")
    
    holePackageBuilder1.EndHoleData.ThreadedReliefDiameter.SetFormula("1")
    
    holePackageBuilder1.EndHoleData.ThreadedReliefChamferOffset.SetFormula("0.08")
    
    holePackageBuilder1.DrillSizeStandard = "ISO"
    
    holePackageBuilder1.DrillSizeHoleDiameter.SetFormula("0.35")
    
    holePackageBuilder1.DrillSizeStartChamferOffset.SetFormula("0.03")
    
    holePackageBuilder1.DrillSizeEndChamferOffset.SetFormula("0.03")
    
    holePackageBuilder1.GeneralTaperedHoleDepth.SetFormula("25")
    
    holePackageBuilder1.NeckChamferEnabled = True
    
    holePackageBuilder1.ScrewClearanceStartChamferEnabled = True
    
    holePackageBuilder1.ScrewClearanceEndChamferEnabled = True
    
    holePackageBuilder1.StartHoleData.StartChamferEnabled = True
    
    holePackageBuilder1.StartHoleData.EndChamferEnabled = True
    
    holePackageBuilder1.MiddleHoleData.StartChamferEnabled = True
    
    holePackageBuilder1.MiddleHoleData.EndChamferEnabled = True
    
    holePackageBuilder1.EndHoleData.ScrewClearanceStartChamferEnabled = True
    
    holePackageBuilder1.EndHoleData.ScrewClearanceEndChamferEnabled = True
    
    holePackageBuilder1.EndHoleData.ThreadedStartChamferEnabled = True
    
    holePackageBuilder1.EndHoleData.ThreadedEndChamferEnabled = True
    
    holePackageBuilder1.ThreadSize = "M10 x 1.5"
    
    holePackageBuilder1.TapDrillDiameter.SetFormula("8.5")
    
    holePackageBuilder1.ThreadedReliefDepth.SetFormula("5")
    
    holePackageBuilder1.ThreadedReliefDiameter.SetFormula("10")
    
    holePackageBuilder1.ThreadedReliefChamferOffset.SetFormula("0.6")
    
    holePackageBuilder1.ThreadedStartChamferDiameter.SetFormula("10")
    
    holePackageBuilder1.ThreadedEndChamferDiameter.SetFormula("10")
    
    holePackageBuilder1.ThreadedHoleDepth.SetFormula("20")
    
    holePackageBuilder1.ThreadDepth.SetFormula("15")
    
    holePackageBuilder1.RadialEngageOption = "0.75"
    
    holePackageBuilder1.ThreadedStartChamferEnabled = True
    
    holePackageBuilder1.ThreadedEndChamferEnabled = True
    
    holePackageBuilder1.EndHoleData.ThreadSize = "M10 x 1.5"
    
    holePackageBuilder1.EndHoleData.TapDrillDiameter.SetFormula("8.5")
    
    holePackageBuilder1.EndHoleData.ThreadedStartChamferDiameter.SetFormula("10")
    
    holePackageBuilder1.EndHoleData.ThreadedEndChamferDiameter.SetFormula("10")
    
    holePackageBuilder1.EndHoleData.ThreadedReliefDepth.SetFormula("5")
    
    holePackageBuilder1.EndHoleData.ThreadedReliefDiameter.SetFormula("10")
    
    holePackageBuilder1.EndHoleData.ThreadedReliefChamferOffset.SetFormula("0.6")
    
    holePackageBuilder1.EndHoleData.RadialEngageOption = "0.75"
    
    holePackageBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = body1
    holePackageBuilder1.BooleanOperation.SetTargetBodies(targetBodies22)
    
    holePackageBuilder1.ScrewStandard = "ISO"
    
    holePackageBuilder1.ScrewClearanceHoleDiameter.SetFormula("11")
    
    holePackageBuilder1.ScrewClearanceStartChamferOffset.SetFormula("0.6")
    
    holePackageBuilder1.ScrewClearanceEndChamferOffset.SetFormula("0.6")
    
    holePackageBuilder1.MiddleHoleData.HoleDiameter.SetFormula("11")
    
    holePackageBuilder1.MiddleHoleData.StartChamferOffset.SetFormula("0.6")
    
    holePackageBuilder1.MiddleHoleData.EndChamferOffset.SetFormula("0.6")
    
    holePackageBuilder1.EndHoleData.HoleDiameter.SetFormula("11")
    
    holePackageBuilder1.EndHoleData.ScrewClearanceStartChamferOffset.SetFormula("0.6")
    
    holePackageBuilder1.EndHoleData.ScrewClearanceEndChamferOffset.SetFormula("0.6")
    
    holePackageBuilder1.StartHoleData.HoleDiameter.SetFormula("11")
    
    holePackageBuilder1.StartHoleData.StartChamferOffset.SetFormula("0.6")
    
    holePackageBuilder1.StartHoleData.EndChamferOffset.SetFormula("0.6")
    
    holePackageBuilder1.ThreadStandard = "Metric Coarse"
    
    holePackageBuilder1.DrillSizeStandard = "ISO"
    
    theSession.SetUndoMarkName(markId177, "Hole Dialog")
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    holePackageBuilder1.HolePosition.DistanceTolerance = 0.01
    
    holePackageBuilder1.HolePosition.ChainingTolerance = 0.0094999999999999998
    
    holePackageBuilder1.HolePosition.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyPoints)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.98786421940848346
    rotMatrix4.Xy = 0.14891099135601008
    rotMatrix4.Xz = 0.04415654725902865
    rotMatrix4.Yx = -0.002589143534911794
    rotMatrix4.Yy = -0.2684666775552752
    rotMatrix4.Yz = 0.96328549214559556
    rotMatrix4.Zx = 0.15529835912920772
    rotMatrix4.Zy = -0.95170959840478475
    rotMatrix4.Zz = -0.26482307292978385
    translation4 = NXOpen.Point3d(-47.678596692382222, -23.933755739244319, 16.625110807521231)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 0.6469360501956235)
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    point16 = workPart.Points.CreatePoint(arc2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    selectionIntentRuleOptions6 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions6.SetSelectedFromInactive(False)
    
    points1 = [NXOpen.Point.Null] * 1 
    points1[0] = point16
    curveDumbRule1 = workPart.ScRuleFactory.CreateRuleCurveDumbFromPoints(points1, selectionIntentRuleOptions6)
    
    selectionIntentRuleOptions6.Dispose()
    holePackageBuilder1.HolePosition.AllowSelfIntersection(True)
    
    holePackageBuilder1.HolePosition.AllowDegenerateCurves(False)
    
    rules5 = [None] * 1 
    rules5[0] = curveDumbRule1
    helpPoint5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    holePackageBuilder1.HolePosition.AddToSection(rules5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId178, None)
    
    scaleAboutPoint49 = NXOpen.Point3d(39.67097416440587, -36.194651686081642, 0.0)
    viewCenter49 = NXOpen.Point3d(-39.670974164405735, 36.194651686081571, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(32.063962623602315, -28.955721348865318, 0.0)
    viewCenter50 = NXOpen.Point3d(-32.063962623602151, 28.955721348865264, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(25.651170098881853, -23.164577079092254, 0.0)
    viewCenter51 = NXOpen.Point3d(-25.651170098881675, 23.164577079092208, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(4.8161380593819896, 4.2926447920577582, 0.0)
    viewCenter52 = NXOpen.Point3d(-4.8161380593817933, -4.2926447920577937, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint52, viewCenter52)
    
    holePackageBuilder1.Destroy()
    
    workPart.MeasureManager.SetPartTransientModification()
    
    workPart.Expressions.Delete(expression22)
    
    workPart.MeasureManager.ClearPartTransientModification()
    
    theSession.UndoToMark(markId177, None)
    
    theSession.DeleteUndoMark(markId177, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Combine->Subtract...
    # ----------------------------------------------
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    booleanBuilder1 = workPart.Features.CreateBooleanBuilderUsingCollector(NXOpen.Features.BooleanFeature.Null)
    
    scCollector1 = booleanBuilder1.ToolBodyCollector
    
    scCollector2 = booleanBuilder1.TargetBodyCollector
    
    booleanRegionSelect1 = booleanBuilder1.BooleanRegionSelect
    
    booleanBuilder1.Tolerance = 0.01
    
    booleanBuilder1.Operation = NXOpen.Features.Feature.BooleanType.Subtract
    
    theSession.SetUndoMarkName(markId180, "Subtract Dialog")
    
    scCollector3 = workPart.ScCollectors.CreateCollector()
    
    selectionIntentRuleOptions7 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions7.SetSelectedFromInactive(False)
    
    bodies1 = [NXOpen.Body.Null] * 1 
    bodies1[0] = body1
    bodyDumbRule1 = workPart.ScRuleFactory.CreateRuleBodyDumb(bodies1, True, selectionIntentRuleOptions7)
    
    selectionIntentRuleOptions7.Dispose()
    rules6 = [None] * 1 
    rules6[0] = bodyDumbRule1
    scCollector3.ReplaceRules(rules6, False)
    
    booleanBuilder1.TargetBodyCollector = scCollector3
    
    booleanBuilder1.Destroy()
    
    scCollector3.Destroy()
    
    theSession.UndoToMark(markId180, None)
    
    theSession.DeleteUndoMark(markId180, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Revolve...
    # ----------------------------------------------
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    revolveBuilder2 = workPart.Features.CreateRevolveBuilder(NXOpen.Features.Feature.Null)
    
    revolveBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    revolveBuilder2.Limits.EndExtend.Value.SetFormula("360")
    
    revolveBuilder2.Tolerance = 0.01
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    revolveBuilder2.Section = section5
    
    smartVolumeProfileBuilder5 = revolveBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId181, "Revolve Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    starthelperpoint2 = [None] * 3 
    starthelperpoint2[0] = 0.0
    starthelperpoint2[1] = 0.0
    starthelperpoint2[2] = 0.0
    revolveBuilder2.SetStartLimitHelperPoint(starthelperpoint2)
    
    endhelperpoint2 = [None] * 3 
    endhelperpoint2[0] = 0.0
    endhelperpoint2[1] = 0.0
    endhelperpoint2[2] = 0.0
    revolveBuilder2.SetEndLimitHelperPoint(endhelperpoint2)
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions8 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions8.SetSelectedFromInactive(False)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature7
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1, NXOpen.DisplayableObject.Null, selectionIntentRuleOptions8)
    
    selectionIntentRuleOptions8.Dispose()
    section5.AllowSelfIntersection(False)
    
    section5.AllowDegenerateCurves(False)
    
    rules7 = [None] * 1 
    rules7[0] = curveFeatureRule1
    helpPoint6 = NXOpen.Point3d(-2.2949167210733536, -0.0, -3.2643113363829332)
    section5.AddToSection(rules7, arc2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId183, None)
    
    revolveBuilder2.Section = section5
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId182, None)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.94271904291702247
    rotMatrix5.Xy = 0.33236925536565509
    rotMatrix5.Xz = 0.028486561907204645
    rotMatrix5.Yx = -0.059449207009109183
    rotMatrix5.Yy = 0.083362253422492788
    rotMatrix5.Yz = 0.99474445285726831
    rotMatrix5.Zx = 0.32824776908244457
    rotMatrix5.Zy = -0.93945804206042016
    rotMatrix5.Zz = 0.098346272427555378
    translation5 = NXOpen.Point3d(-60.774421171857121, 5.3345839808111366, 7.5152251567704553)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 1.5794337162979084)
    
    revolveBuilder2.Destroy()
    
    section5.Destroy()
    
    workPart.MeasureManager.SetPartTransientModification()
    
    workPart.Expressions.Delete(expression23)
    
    workPart.MeasureManager.ClearPartTransientModification()
    
    workPart.MeasureManager.SetPartTransientModification()
    
    workPart.Expressions.Delete(expression24)
    
    workPart.MeasureManager.ClearPartTransientModification()
    
    theSession.UndoToMark(markId181, None)
    
    theSession.DeleteUndoMark(markId181, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section6
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies24)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId184, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    scaleAboutPoint53 = NXOpen.Point3d(-55.615924720514236, 7.2870262811517117, 0.0)
    viewCenter53 = NXOpen.Point3d(55.615924720514435, -7.287026281151741, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint53, viewCenter53)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.99901656151161466
    rotMatrix6.Xy = -0.002611246537934658
    rotMatrix6.Xz = 0.04426162239489994
    rotMatrix6.Yx = -0.044258189095884699
    rotMatrix6.Yy = 0.0013582916024344506
    rotMatrix6.Yz = 0.99901920288944845
    rotMatrix6.Zx = -0.002668805624884466
    rotMatrix6.Zy = -0.99999566820833485
    rotMatrix6.Zz = 0.0012413867631423242
    translation6 = NXOpen.Point3d(-61.966157475358017, 0.80560318901907468, 19.050765296526823)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 1.9742921453723854)
    
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions9 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions9.SetSelectedFromInactive(False)
    
    features2 = [NXOpen.Features.Feature.Null] * 1 
    features2[0] = sketchFeature1
    curveFeatureRule2 = workPart.ScRuleFactory.CreateRuleCurveFeature(features2, NXOpen.DisplayableObject.Null, selectionIntentRuleOptions9)
    
    selectionIntentRuleOptions9.Dispose()
    section6.AllowSelfIntersection(True)
    
    section6.AllowDegenerateCurves(False)
    
    rules8 = [None] * 1 
    rules8[0] = curveFeatureRule2
    helpPoint7 = NXOpen.Point3d(75.806763904990675, 0.0, -3.8551000219833376)
    section6.AddToSection(rules8, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint7, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId186, None)
    
    direction14 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction14
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies26)
    
    theSession.DeleteUndoMark(markId185, None)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.98716318315128926
    rotMatrix7.Xy = 0.1536701337873668
    rotMatrix7.Xz = 0.043524014203508016
    rotMatrix7.Yx = -0.044258189095884699
    rotMatrix7.Yy = 0.0013582916024344506
    rotMatrix7.Yz = 0.99901920288944845
    rotMatrix7.Zx = 0.15346029626117424
    rotMatrix7.Zy = -0.98812127040444231
    rotMatrix7.Zz = 0.0081420173014582486
    translation7 = NXOpen.Point3d(-56.82138682237548, 0.80560318901907468, 13.418886314666835)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 1.9742921453723854)
    
    scaleAboutPoint54 = NXOpen.Point3d(-50.523382215985173, -9.3139922122307208, 0.0)
    viewCenter54 = NXOpen.Point3d(50.523382215985428, 9.3139922122307084, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(-40.418705772788122, -7.4511937697845676, 0.0)
    viewCenter55 = NXOpen.Point3d(40.418705772788378, 7.4511937697845676, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(-31.734580659801782, -5.9609550158276541, 0.0)
    viewCenter56 = NXOpen.Point3d(31.734580659802045, 5.9609550158276541, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(-39.561014403604283, -7.5584051909325503, 0.0)
    viewCenter57 = NXOpen.Point3d(39.561014403604538, 7.5584051909325503, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(-49.451268004505394, -9.4480064886656869, 0.0)
    viewCenter58 = NXOpen.Point3d(49.451268004505629, 9.4480064886656869, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(-61.814085005631789, -11.810008110832108, 0.0)
    viewCenter59 = NXOpen.Point3d(61.814085005631988, 11.810008110832108, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(-76.848811643180426, -14.553112831610479, 0.0)
    viewCenter60 = NXOpen.Point3d(76.848811643180667, 14.553112831610479, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint60, viewCenter60)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.90163400766615165
    rotMatrix8.Xy = 0.43100113755888197
    rotMatrix8.Xz = 0.035974096831231782
    rotMatrix8.Yx = -0.069955456406106661
    rotMatrix8.Yy = 0.063249159761156817
    rotMatrix8.Yz = 0.99554295633514189
    rotMatrix8.Zx = 0.42680481527143965
    rotMatrix8.Zy = -0.90013196988688915
    rotMatrix8.Zz = 0.087178474686451735
    translation8 = NXOpen.Point3d(-91.854971033242919, -5.3129493490604265, 5.039181948723396)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 1.0108375784306616)
    
    scaleAboutPoint61 = NXOpen.Point3d(-97.108001088623823, -11.90947183162368, 0.0)
    viewCenter61 = NXOpen.Point3d(97.10800108862405, 11.90947183162368, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(-121.38500136077975, -14.232473205374488, 0.0)
    viewCenter62 = NXOpen.Point3d(121.38500136078001, 14.232473205374433, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(-151.73125170097472, -16.972633276524185, 0.0)
    viewCenter63 = NXOpen.Point3d(151.73125170097492, 16.972633276524114, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(-202.95588586686989, -13.547433187587052, 0.0)
    viewCenter64 = NXOpen.Point3d(202.95588586687006, 13.547433187587009, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(-162.77368780859283, -10.837946550069677, 0.0)
    viewCenter65 = NXOpen.Point3d(162.77368780859302, 10.837946550069608, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(-130.54613353895178, -8.6703572400557434, 0.0)
    viewCenter66 = NXOpen.Point3d(130.54613353895206, 8.6703572400556865, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(-104.43690683116142, -6.9362857920446164, 0.0)
    viewCenter67 = NXOpen.Point3d(104.43690683116169, 6.9362857920445498, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(-83.54952546492909, -5.5490286336356922, 0.0)
    viewCenter68 = NXOpen.Point3d(83.549525464929374, 5.5490286336356389, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint68, viewCenter68)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies27)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.90604319928003074
    rotMatrix9.Xy = 0.42185274558676811
    rotMatrix9.Xz = 0.033555656442867267
    rotMatrix9.Yx = 0.11644526880070025
    rotMatrix9.Yy = -0.3247574896432473
    rotMatrix9.Yz = 0.93860165794363604
    rotMatrix9.Zx = 0.40684913716553456
    rotMatrix9.Zy = -0.846506251578519
    rotMatrix9.Zz = -0.34336707126068294
    translation9 = NXOpen.Point3d(-47.981260186120224, -25.251280299621193, 10.850633633575981)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 1.5794337162979089)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies28)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("100")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies29)
    
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId187, None)
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    feature8 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId188, None)
    
    theSession.SetUndoMarkName(markId184, "Extrude")
    
    expression26 = extrudeBuilder4.Limits.StartExtend.Value
    expression27 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression25)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = 0.98928502881171265
    rotMatrix10.Xy = -0.048376591544024343
    rotMatrix10.Xz = -0.13774918206505302
    rotMatrix10.Yx = 0.1387512953370183
    rotMatrix10.Yy = 0.017990538508506036
    rotMatrix10.Yz = 0.99016383420445708
    rotMatrix10.Zx = -0.04542256940451761
    rotMatrix10.Zy = -0.99866713469241353
    rotMatrix10.Zz = 0.024510085147448089
    translation10 = NXOpen.Point3d(-63.880891114184671, -16.228965873535245, 20.529114738556135)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 1.5794337162979089)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 0.60761367617254358
    rotMatrix11.Xy = 0.79313209716477273
    rotMatrix11.Xz = 0.041798289140768906
    rotMatrix11.Yx = -0.47236855496612989
    rotMatrix11.Yy = 0.31856872608489201
    rotMatrix11.Yz = 0.82181622948190591
    rotMatrix11.Zx = 0.6384932018489291
    rotMatrix11.Zy = -0.51909097777524038
    rotMatrix11.Zz = 0.56821737740502443
    translation11 = NXOpen.Point3d(-25.568498822278894, 17.357714903056372, 4.5779418003797474)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 1.5794337162979089)
    
    scaleAboutPoint69 = NXOpen.Point3d(-6.7007138217485727, 14.825329330618993, 0.0)
    viewCenter69 = NXOpen.Point3d(6.7007138217488587, -14.825329330619052, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(-5.3605710573988237, 11.592234911625233, 0.0)
    viewCenter70 = NXOpen.Point3d(5.3605710573991097, -11.59223491162529, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(-4.2884568459190318, 9.2737879293001875, 0.0)
    viewCenter71 = NXOpen.Point3d(4.2884568459193062, -9.2737879293002425, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(-3.4307654767352038, 7.4190303434401503, 0.0)
    viewCenter72 = NXOpen.Point3d(3.4307654767354814, -7.4190303434401939, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(-4.2884568459190318, 9.2737879293001964, 0.0)
    viewCenter73 = NXOpen.Point3d(4.2884568459193062, -9.2737879293002337, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(-5.4945853338338013, 11.592234911625244, 0.0)
    viewCenter74 = NXOpen.Point3d(5.4945853338340873, -11.59223491162529, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(-7.0357495128360039, 14.490293639531556, 0.0)
    viewCenter75 = NXOpen.Point3d(7.035749512836289, -14.490293639531613, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint75, viewCenter75)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()