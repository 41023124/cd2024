﻿# NX 2027
# Journal created by Admin on Fri Jun 14 14:38:51 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\yan1\\portable_2024\\portable_2024\\data\\w1703.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    scaleAboutPoint1 = NXOpen.Point3d(8.9863575094548445, 2.4962104192930408, 0.0)
    viewCenter1 = NXOpen.Point3d(-8.9863575094548445, -2.4962104192930408, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(23.713998983283545, 8.1126838627022551, 0.0)
    viewCenter2 = NXOpen.Point3d(-23.713998983283545, -8.1126838627022551, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(18.971199186626837, 6.4901470901618037, 0.0)
    viewCenter3 = NXOpen.Point3d(-18.971199186626837, -6.4901470901618037, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(18.372108685996484, 8.3872670088245229, 0.0)
    viewCenter4 = NXOpen.Point3d(-18.372108685996484, -8.3872670088245229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(14.697686948797244, 6.7098136070596741, 0.0)
    viewCenter5 = NXOpen.Point3d(-14.697686948797189, -6.7098136070595658, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(11.758149559037751, 5.8790747795189633, 0.0)
    viewCenter6 = NXOpen.Point3d(-11.758149559037751, -5.8790747795189189, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder1 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder1.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId6, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder1.UseWorkPartOrigin = False
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 1.0
    matrix1.Xy = 0.0
    matrix1.Xz = 0.0
    matrix1.Yx = -0.0
    matrix1.Yy = 0.0
    matrix1.Yz = 1.0
    matrix1.Zx = 0.0
    matrix1.Zy = -1.0
    matrix1.Zz = 0.0
    plane2 = workPart.Planes.CreateFixedTypePlane(origin2, matrix1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector1 = NXOpen.Vector3d(0.0, -1.0, 0.0)
    direction1 = workPart.Directions.CreateDirection(origin3, vector1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector2 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction2 = workPart.Directions.CreateDirection(origin4, vector2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix2 = NXOpen.Matrix3x3()
    
    matrix2.Xx = 1.0
    matrix2.Xy = 0.0
    matrix2.Xz = 0.0
    matrix2.Yx = -0.0
    matrix2.Yy = 0.0
    matrix2.Yz = 1.0
    matrix2.Zx = 0.0
    matrix2.Zy = -1.0
    matrix2.Zz = 0.0
    plane3 = workPart.Planes.CreateFixedTypePlane(origin5, matrix2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane3, direction2, point2, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder1.CoordinateSystem = cartesianCoordinateSystem1
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    simpleSketchInPlaceBuilder1.HorizontalReference.Value = datumAxis1
    
    point3 = simpleSketchInPlaceBuilder1.SketchOrigin
    
    simpleSketchInPlaceBuilder1.SketchOrigin = point3
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId7, None)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject2 = simpleSketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId9)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder1 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject3 = sketchFindMovableObjectsBuilder1.Commit()
    
    sketchFindMovableObjectsBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId8, None)
    
    theSession.SetUndoMarkName(markId6, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    simpleSketchInPlaceBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId5, None, True)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_000")
    
    scaleAboutPoint7 = NXOpen.Point3d(39.670974164405806, 10.019988319875722, 0.0)
    viewCenter7 = NXOpen.Point3d(-39.670974164405806, -10.019988319875651, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Line...
    # ----------------------------------------------
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint8 = NXOpen.Point3d(39.261995049308808, 22.739238799391401, 0.0)
    viewCenter8 = NXOpen.Point3d(-39.261995049308922, -22.739238799391348, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(31.409596039447049, 17.667897772189011, 0.0)
    viewCenter9 = NXOpen.Point3d(-31.409596039447162, -17.667897772188969, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(-0.41879461385937788, -4.0832474851280862, 0.0)
    viewCenter10 = NXOpen.Point3d(0.41879461385921718, 4.0832474851281395, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(-1.1726249188061151, -3.9366693702773592, 0.0)
    viewCenter11 = NXOpen.Point3d(1.1726249188059437, 3.9366693702773876, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(-1.0721142114799158, -3.1493354962218874, 0.0)
    viewCenter12 = NXOpen.Point3d(1.0721142114797102, 3.1493354962218985, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint12, viewCenter12)
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId12, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(2.9882304432030651, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId13, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(7.6927325602571326, 0.0, 36.191461227150803)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder2 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject4 = sketchFindMovableObjectsBuilder2.Commit()
    
    sketchFindMovableObjectsBuilder2.Destroy()
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder1 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects1 = [None] * 1 
    dragobjects1[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects1[0].Geometry = line1
    dragobjects1[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects1[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects1)
    
    sketchDragGeometryBuilder1.SplineLinearScale = False
    
    foundrelations1 = sketchDragGeometryBuilder1.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    sketchDragGeometryBuilder1.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Line...
    # ----------------------------------------------
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId17, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint3 = NXOpen.Point3d(2.9882304432030651, 0.0, 0.0)
    endPoint3 = NXOpen.Point3d(10.680963003460214, 0.0, 36.191461227150803)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId18, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint4 = NXOpen.Point3d(7.6927325602571326, 0.0, 36.191461227150803)
    endPoint4 = NXOpen.Point3d(10.680963003460214, 0.0, 36.191461227150803)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder3 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject5 = sketchFindMovableObjectsBuilder3.Commit()
    
    sketchFindMovableObjectsBuilder3.Destroy()
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder2 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects2 = [None] * 1 
    dragobjects2[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects2[0].Geometry = line3
    dragobjects2[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects2[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects2)
    
    sketchDragGeometryBuilder2.SplineLinearScale = False
    
    foundrelations2 = sketchDragGeometryBuilder2.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects3 = [None] * 1 
    dragobjects3[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects3[0].Geometry = line3
    dragobjects3[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects3[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects3)
    
    foundrelations3 = sketchDragGeometryBuilder2.FindRelations()
    
    sketchDragGeometryBuilder2.Destroy()
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences1 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences1 = dimensionPreferences1.GetNarrowDimensionPreferences()
    
    option1 = narrowDimensionPreferences1.DimensionDisplayOption
    
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder1 = sketchLinearDimensionBuilder1.Driving
    
    drivingValueBuilder1.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject1 = sketchLinearDimensionBuilder1.FirstAssociativity
    
    selectNXObject2 = sketchLinearDimensionBuilder1.SecondAssociativity
    
    point1_9 = NXOpen.Point3d(2.9882304432030651, 0.0, 0.0)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject1.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, NXOpen.View.Null, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    point1_10 = NXOpen.Point3d(10.680963003460214, 0.0, 36.191461227150803)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject2.SetValue(NXOpen.InferSnapType.SnapType.End, line3, NXOpen.View.Null, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    dimensionMeasurementBuilder1 = sketchLinearDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder1.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder1 = sketchLinearDimensionBuilder1.Origin
    
    origin10 = NXOpen.Point3d(14.32783969132849, 0.0, 18.095730613575402)
    originBuilder1.OriginPoint = origin10
    
    originBuilder1.SetInferRelativeToGeometry(True)
    
    nXObject6 = sketchLinearDimensionBuilder1.Commit()
    
    verticalDimension1 = nXObject6
    verticalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences1.Dispose()
    dimensionPreferences1.Dispose()
    sketchFindMovableObjectsBuilder4 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject7 = sketchFindMovableObjectsBuilder4.Commit()
    
    sketchFindMovableObjectsBuilder4.Destroy()
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder1 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension1)
    
    selectNXObjectList1 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations4 = sketchEditDimensionValueBuilder1.FindRelations()
    
    sketchHelpedDimensionalConstraint1 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line3] StartVertex] [[Curve Line3] EndVertex]")
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId22, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId22, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId23, None)
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.DimValue = 140.0
    
    theSession.ActiveSketch.Scale(3.8683157643489068)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin11 = NXOpen.Point3d(55.424608147029971, 0.0, 69.999999999904844)
    verticalDimension1.AnnotationOrigin = origin11
    
    sketchEditDimensionValueBuilder1.RestoreOperation()
    
    sketchEditDimensionValueBuilder1.LoadExtraGeometry()
    
    selectNXObjectList2 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations5 = sketchEditDimensionValueBuilder1.FindRelations()
    
    nXObject8 = sketchEditDimensionValueBuilder1.Commit()
    
    sketchEditDimensionValueBuilder1.DimValue = 139.9999999998
    
    theSession.SetUndoMarkName(markId24, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId22, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint13 = NXOpen.Point3d(-12.865370537757622, 9.0593650870042666, 0.0)
    viewCenter13 = NXOpen.Point3d(12.86537053775743, -9.0593650870042488, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(-10.206527293287749, 7.2474920696034211, 0.0)
    viewCenter14 = NXOpen.Point3d(10.206527293287543, -7.2474920696033918, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-8.165221834630211, 5.7979936556827436, 0.0)
    viewCenter15 = NXOpen.Point3d(8.1652218346300174, -5.7979936556827143, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(-6.5321774677041962, 4.6383949245461986, 0.0)
    viewCenter16 = NXOpen.Point3d(6.5321774677039901, -4.6383949245461666, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-4.3035522140169125, 3.7546297377391689, 0.0)
    viewCenter17 = NXOpen.Point3d(4.3035522140167179, -3.7546297377391427, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-3.0564003479140767, 3.003703790191341, 0.0)
    viewCenter18 = NXOpen.Point3d(3.056400347913879, -3.0037037901913113, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-2.4170154475458707, 2.4029630321530773, 0.0)
    viewCenter19 = NXOpen.Point3d(2.4170154475456695, -2.4029630321530462, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-3.0212693094323146, 3.0037037901913406, 0.0)
    viewCenter20 = NXOpen.Point3d(3.0212693094321108, -3.0037037901913108, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-3.7765866367903707, 3.754629737739172, 0.0)
    viewCenter21 = NXOpen.Point3d(3.7765866367901681, -3.7546297377391422, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-4.7207332959879347, 4.6932871721739593, 0.0)
    viewCenter22 = NXOpen.Point3d(4.7207332959877242, -4.6932871721739318, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(-5.900916619984895, 5.935224274752156, 0.0)
    viewCenter23 = NXOpen.Point3d(5.9009166199846783, -5.9352242747521204, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(-6.7757618165524161, 8.4482599864607888, 0.0)
    viewCenter24 = NXOpen.Point3d(6.7757618165521825, -8.4482599864607586, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(-8.4697022706904814, 10.560324983075985, 0.0)
    viewCenter25 = NXOpen.Point3d(8.4697022706902629, -10.560324983075947, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(-10.587127838363079, 13.200406228844979, 0.0)
    viewCenter26 = NXOpen.Point3d(10.58712783836285, -13.200406228844944, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(-13.233909797953821, 16.500507786056207, 0.0)
    viewCenter27 = NXOpen.Point3d(13.233909797953592, -16.500507786056193, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(-5.444329980170945, 26.069964712741072, 0.0)
    viewCenter28 = NXOpen.Point3d(5.4443299801707132, -26.069964712741054, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-6.8054124752136813, 32.587455890926336, 0.0)
    viewCenter29 = NXOpen.Point3d(6.8054124752134131, -32.587455890926314, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(-8.1795823019394636, 40.734319863657959, 0.0)
    viewCenter30 = NXOpen.Point3d(8.1795823019392415, -40.734319863657902, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(11.451415222714918, 84.863166382620705, 0.0)
    viewCenter31 = NXOpen.Point3d(-11.451415222715196, -84.863166382620633, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(14.314269028393735, 106.59018187214711, 0.0)
    viewCenter32 = NXOpen.Point3d(-14.314269028393909, -106.59018187214703, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(17.892836285492169, 134.51578707486186, 0.0)
    viewCenter33 = NXOpen.Point3d(-17.89283628549239, -134.51578707486186, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(29.555131364429087, 256.81012793686511, 0.0)
    viewCenter34 = NXOpen.Point3d(-29.555131364429357, -256.81012793686511, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(23.644105091543157, 206.08713221683109, 0.0)
    viewCenter35 = NXOpen.Point3d(-23.644105091543484, -206.08713221683109, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(18.915284073234524, 164.86970577346486, 0.0)
    viewCenter36 = NXOpen.Point3d(-18.915284073234787, -164.86970577346486, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(9.4065196472301285, 144.16513807168096, 0.0)
    viewCenter37 = NXOpen.Point3d(-9.406519647230267, -144.1651380716809, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(7.5252157177840466, 111.40591095241382, 0.0)
    viewCenter38 = NXOpen.Point3d(-7.5252157177842696, -111.40591095241385, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(6.020172574227237, 88.07774222728284, 0.0)
    viewCenter39 = NXOpen.Point3d(-6.0201725742274155, -88.07774222728284, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-15.07660609893467, -36.121035445364157, 0.0)
    viewCenter40 = NXOpen.Point3d(15.076606098934509, 36.121035445364143, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(-19.107504257330408, -45.151294306705182, 0.0)
    viewCenter41 = NXOpen.Point3d(19.107504257330227, 45.151294306705182, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint41, viewCenter41)
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId26, None)
    
    theSession.SetUndoMarkName(markId22, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId25, None)
    
    theSession.SetUndoMarkVisibility(markId22, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId24, None)
    
    theSession.DeleteUndoMark(markId22, None)
    
    sketchFindMovableObjectsBuilder5 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject9 = sketchFindMovableObjectsBuilder5.Commit()
    
    sketchFindMovableObjectsBuilder5.Destroy()
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder3 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects4 = [None] * 1 
    dragobjects4[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects4[0].Geometry = line1
    dragobjects4[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects4[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects4)
    
    sketchDragGeometryBuilder3.SplineLinearScale = False
    
    foundrelations6 = sketchDragGeometryBuilder3.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects5 = [None] * 1 
    dragobjects5[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects5[0].Geometry = line1
    dragobjects5[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects5[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects5)
    
    foundrelations7 = sketchDragGeometryBuilder3.FindRelations()
    
    sketchDragGeometryBuilder3.Destroy()
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences2 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences2 = dimensionPreferences2.GetNarrowDimensionPreferences()
    
    option2 = narrowDimensionPreferences2.DimensionDisplayOption
    
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder2 = sketchLinearDimensionBuilder2.Driving
    
    drivingValueBuilder2.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject3 = sketchLinearDimensionBuilder2.FirstAssociativity
    
    selectNXObject4 = sketchLinearDimensionBuilder2.SecondAssociativity
    
    point1_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject3.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, NXOpen.View.Null, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    point1_14 = NXOpen.Point3d(11.559418930949738, 0.0, 0.0)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject4.SetValue(NXOpen.InferSnapType.SnapType.End, line1, NXOpen.View.Null, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    dimensionMeasurementBuilder2 = sketchLinearDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder2.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder2 = sketchLinearDimensionBuilder2.Origin
    
    origin13 = NXOpen.Point3d(5.7797094654748689, 0.0, -14.10727058231738)
    originBuilder2.OriginPoint = origin13
    
    originBuilder2.SetInferRelativeToGeometry(True)
    
    nXObject10 = sketchLinearDimensionBuilder2.Commit()
    
    horizontalDimension1 = nXObject10
    horizontalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences2.Dispose()
    dimensionPreferences2.Dispose()
    sketchFindMovableObjectsBuilder6 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject11 = sketchFindMovableObjectsBuilder6.Commit()
    
    sketchFindMovableObjectsBuilder6.Destroy()
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder2 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension1)
    
    selectNXObjectList3 = sketchEditDimensionValueBuilder2.ExtraGeometries
    
    foundrelations8 = sketchEditDimensionValueBuilder2.FindRelations()
    
    sketchHelpedDimensionalConstraint2 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line1] StartVertex] [[Curve Line1] EndVertex]")
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId30, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId30, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId31, None)
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.DimValue = 8.0
    
    nXObject12 = sketchEditDimensionValueBuilder2.Commit()
    
    theSession.SetUndoMarkName(markId32, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId32, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId30, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId34, None)
    
    theSession.SetUndoMarkName(markId30, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId33, None)
    
    theSession.SetUndoMarkVisibility(markId30, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId32, None)
    
    theSession.DeleteUndoMark(markId30, None)
    
    sketchFindMovableObjectsBuilder7 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject13 = sketchFindMovableObjectsBuilder7.Commit()
    
    sketchFindMovableObjectsBuilder7.Destroy()
    
    scaleAboutPoint42 = NXOpen.Point3d(31.082412747369418, -9.324723824210853, 0.0)
    viewCenter42 = NXOpen.Point3d(-31.082412747369585, 9.324723824210853, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(24.865930197895537, -9.2920054950031048, 0.0)
    viewCenter43 = NXOpen.Point3d(-24.865930197895651, 9.2920054950031048, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(17.798771089019972, -9.5275774652989469, 0.0)
    viewCenter44 = NXOpen.Point3d(-17.7987710890201, 9.5275774652989469, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(20.677984059302567, -11.909471831623705, 0.0)
    viewCenter45 = NXOpen.Point3d(-20.677984059302744, 11.909471831623682, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(25.193113489973097, -14.886839789529603, 0.0)
    viewCenter46 = NXOpen.Point3d(-25.193113489973211, 14.886839789529603, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(30.264454517175398, -18.608549736911968, 0.0)
    viewCenter47 = NXOpen.Point3d(-30.264454517175537, 18.608549736912003, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint47, viewCenter47)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder1 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder1.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject14 = sketchWorkRegionBuilder1.Commit()
    
    sketchWorkRegionBuilder1.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId36, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions1 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions1.SetSelectedFromInactive(False)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    curves1[0] = line1
    curves1[1] = line2
    curves1[2] = line3
    curves1[3] = line4
    seedPoint1 = NXOpen.Point3d(34.346502633803325, 0.0, 130.79446856859033)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch1, curves1, seedPoint1, 0.01, selectionIntentRuleOptions1)
    
    selectionIntentRuleOptions1.Dispose()
    section1.AllowSelfIntersection(True)
    
    section1.AllowDegenerateCurves(False)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId37, None)
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId39, None)
    
    direction3 = workPart.Directions.CreateDirection(sketch1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction3
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies2)
    
    targetBodies3 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies3)
    
    theSession.DeleteUndoMark(markId38, None)
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies4)
    
    targetBodies5 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies6)
    
    targetBodies7 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies7)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.36478260424496101
    rotMatrix1.Xy = 0.91905157402893112
    rotMatrix1.Xz = -0.14925768293527941
    rotMatrix1.Yx = -0.56593639713543631
    rotMatrix1.Yy = 0.346147892789398
    rotMatrix1.Yz = 0.74826307587293162
    rotMatrix1.Zx = 0.73935759009942215
    rotMatrix1.Zy = -0.18848299815209749
    rotMatrix1.Zz = 0.64639346637320727
    translation1 = NXOpen.Point3d(0.58065892116447682, 11.469812029760822, -18.363508589225859)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.6469360501956235)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("8")
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies8)
    
    targetBodies9 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies9)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId40, None)
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId41, None)
    
    theSession.SetUndoMarkName(markId36, "Extrude")
    
    expression4 = extrudeBuilder1.Limits.StartExtend.Value
    expression5 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression3)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.86016637551882602
    rotMatrix2.Xy = 0.46348940212193024
    rotMatrix2.Xz = 0.21281771671423871
    rotMatrix2.Yx = -0.29252570420496299
    rotMatrix2.Yy = 0.10653785855424461
    rotMatrix2.Yz = 0.95030437075395258
    rotMatrix2.Zx = 0.41778286083346738
    rotMatrix2.Zy = -0.87967451868025126
    rotMatrix2.Zz = 0.227222847395397
    translation2 = NXOpen.Point3d(-35.939197806027963, -8.7932280974723316, 14.284664888223993)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.6469360501956235)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()