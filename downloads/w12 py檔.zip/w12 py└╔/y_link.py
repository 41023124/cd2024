﻿# NX 2027
# Journal created by Admin on Fri May 17 14:31:36 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\yan1\\portable_2024\\portable_2024\\y_link.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder1 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder1.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId6, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder1.UseWorkPartOrigin = False
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 1.0
    matrix1.Xy = 0.0
    matrix1.Xz = 0.0
    matrix1.Yx = 0.0
    matrix1.Yy = 1.0
    matrix1.Yz = 0.0
    matrix1.Zx = 0.0
    matrix1.Zy = 0.0
    matrix1.Zz = 1.0
    plane2 = workPart.Planes.CreateFixedTypePlane(origin2, matrix1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction1 = workPart.Directions.CreateDirection(origin3, vector1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector2 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction2 = workPart.Directions.CreateDirection(origin4, vector2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix2 = NXOpen.Matrix3x3()
    
    matrix2.Xx = 1.0
    matrix2.Xy = 0.0
    matrix2.Xz = 0.0
    matrix2.Yx = 0.0
    matrix2.Yy = 1.0
    matrix2.Yz = 0.0
    matrix2.Zx = 0.0
    matrix2.Zy = 0.0
    matrix2.Zz = 1.0
    plane3 = workPart.Planes.CreateFixedTypePlane(origin5, matrix2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane3, direction2, point2, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder1.CoordinateSystem = cartesianCoordinateSystem1
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    simpleSketchInPlaceBuilder1.HorizontalReference.Value = datumAxis1
    
    point3 = simpleSketchInPlaceBuilder1.SketchOrigin
    
    simpleSketchInPlaceBuilder1.SketchOrigin = point3
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId7, None)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject2 = simpleSketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId9)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder1 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject3 = sketchFindMovableObjectsBuilder1.Commit()
    
    sketchFindMovableObjectsBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId8, None)
    
    theSession.SetUndoMarkName(markId6, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    simpleSketchInPlaceBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId5, None, True)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_000")
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId12, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(100.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(100.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(100.0, 145.0, 0.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(100.0, 145.0, 0.0)
    endPoint3 = NXOpen.Point3d(0.0, 145.0, 0.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 145.0, 0.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    objects1 = [NXOpen.NXObject.Null] * 4 
    objects1[0] = sketchGeometricConstraint1
    objects1[1] = sketchGeometricConstraint2
    objects1[2] = sketchGeometricConstraint3
    objects1[3] = sketchGeometricConstraint4
    errorList1 = theSession.ActiveSketch.DeleteObjects(objects1)
    
    errorList1.Dispose()
    scaleAboutPoint1 = NXOpen.Point3d(106.12477798793545, 107.67028446348799, 0.0)
    viewCenter1 = NXOpen.Point3d(-106.12477798793545, -107.67028446348799, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(141.6714269256419, 116.55694669791461, 0.0)
    viewCenter2 = NXOpen.Point3d(-141.6714269256419, -116.55694669791461, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(180.30908881445345, 140.86647563629185, 0.0)
    viewCenter3 = NXOpen.Point3d(-180.30908881445345, -140.86647563629185, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(227.39873924144229, 172.05833809861358, 0.0)
    viewCenter4 = NXOpen.Point3d(-227.39873924144229, -172.05833809861358, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(286.76389683102286, 212.55744984404734, 0.0)
    viewCenter5 = NXOpen.Point3d(-286.76389683102286, -212.55744984404754, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(389.89828077902177, 265.69681230505938, 0.0)
    viewCenter6 = NXOpen.Point3d(-389.89828077902177, -265.69681230505938, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(319.46504296087619, 212.55744984404754, 0.0)
    viewCenter7 = NXOpen.Point3d(-319.46504296087619, -212.55744984404734, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(257.58441259207643, 170.0459598752382, 0.0)
    viewCenter8 = NXOpen.Point3d(-257.58441259207609, -170.045959875238, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(206.06753007366129, 136.03676790019054, 0.0)
    viewCenter9 = NXOpen.Point3d(-206.06753007366072, -136.03676790019028, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(166.14194612188942, 108.82941432015242, 0.0)
    viewCenter10 = NXOpen.Point3d(-166.14194612188919, -108.8294143201521, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(132.9135568975118, 87.06353145612195, 0.0)
    viewCenter11 = NXOpen.Point3d(-132.91355689751111, -87.06353145612168, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(107.1551156383041, 69.650825164897697, 0.0)
    viewCenter12 = NXOpen.Point3d(-107.15511563830347, -69.650825164897341, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(81.767595933229046, 58.358324516861067, 0.0)
    viewCenter13 = NXOpen.Point3d(-81.767595933228378, -58.358324516860613, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(64.886543869594746, 46.686659613488899, 0.0)
    viewCenter14 = NXOpen.Point3d(-64.886543869594121, -46.686659613488452, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(51.487208794085007, 37.349327690791199, 0.0)
    viewCenter15 = NXOpen.Point3d(-51.487208794084218, -37.34932769079073, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    sketchFindMovableObjectsBuilder2 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject4 = sketchFindMovableObjectsBuilder2.Commit()
    
    sketchFindMovableObjectsBuilder2.Destroy()
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder1 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects1 = [None] * 1 
    dragobjects1[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects1[0].Geometry = line3
    dragobjects1[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects1[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects1)
    
    sketchDragGeometryBuilder1.SplineLinearScale = False
    
    foundrelations1 = sketchDragGeometryBuilder1.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects2 = [None] * 1 
    dragobjects2[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects2[0].Geometry = line3
    dragobjects2[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects2[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects2)
    
    foundrelations2 = sketchDragGeometryBuilder1.FindRelations()
    
    sketchDragGeometryBuilder1.Destroy()
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences1 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences1 = dimensionPreferences1.GetNarrowDimensionPreferences()
    
    option1 = narrowDimensionPreferences1.DimensionDisplayOption
    
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder1 = sketchLinearDimensionBuilder1.Driving
    
    drivingValueBuilder1.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject1 = sketchLinearDimensionBuilder1.FirstAssociativity
    
    selectNXObject2 = sketchLinearDimensionBuilder1.SecondAssociativity
    
    point1_3 = NXOpen.Point3d(100.0, 145.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject1.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(0.0, 145.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject2.SetValue(NXOpen.InferSnapType.SnapType.End, line3, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionMeasurementBuilder1 = sketchLinearDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder1.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder1 = sketchLinearDimensionBuilder1.Origin
    
    origin7 = NXOpen.Point3d(50.0, 156.48443227006302, 0.0)
    originBuilder1.OriginPoint = origin7
    
    originBuilder1.SetInferRelativeToGeometry(True)
    
    nXObject5 = sketchLinearDimensionBuilder1.Commit()
    
    horizontalDimension1 = nXObject5
    horizontalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences1.Dispose()
    dimensionPreferences1.Dispose()
    sketchFindMovableObjectsBuilder3 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject6 = sketchFindMovableObjectsBuilder3.Commit()
    
    sketchFindMovableObjectsBuilder3.Destroy()
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder1 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension1)
    
    selectNXObjectList1 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations3 = sketchEditDimensionValueBuilder1.FindRelations()
    
    sketchHelpedDimensionalConstraint1 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line3] StartVertex] [[Curve Line3] EndVertex]")
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId16, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId17, None)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.DimValue = 5.7999999999999998
    
    theSession.ActiveSketch.Scale(0.057999999999999996)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin8 = NXOpen.Point3d(2.8999999999999999, 9.0760970716636553, 0.0)
    horizontalDimension1.AnnotationOrigin = origin8
    
    sketchEditDimensionValueBuilder1.RestoreOperation()
    
    sketchEditDimensionValueBuilder1.LoadExtraGeometry()
    
    selectNXObjectList2 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations4 = sketchEditDimensionValueBuilder1.FindRelations()
    
    nXObject7 = sketchEditDimensionValueBuilder1.Commit()
    
    theSession.SetUndoMarkName(markId18, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId18, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint16 = NXOpen.Point3d(-108.71397528980465, -47.773377340084899, 0.0)
    viewCenter16 = NXOpen.Point3d(108.71397528980546, 47.773377340085354, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-139.26867952498284, -58.872669071924498, 0.0)
    viewCenter17 = NXOpen.Point3d(139.26867952498355, 58.872669071924925, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-181.4713096840687, -70.953171954962755, 0.0)
    viewCenter18 = NXOpen.Point3d(181.47130968406933, 70.95317195496321, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-226.83913710508588, -88.691464943703579, 0.0)
    viewCenter19 = NXOpen.Point3d(226.83913710508662, 88.691464943703906, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-181.4713096840687, -70.953171954962812, 0.0)
    viewCenter20 = NXOpen.Point3d(181.47130968406933, 70.953171954963125, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-145.17704774725487, -57.184563865561124, 0.0)
    viewCenter21 = NXOpen.Point3d(145.17704774725559, 57.184563865561408, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-116.14163819780389, -46.08527213372156, 0.0)
    viewCenter22 = NXOpen.Point3d(116.14163819780445, 46.085272133721851, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(-92.913310558243083, -37.408411373013521, 0.0)
    viewCenter23 = NXOpen.Point3d(92.913310558243595, 37.408411373013799, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(-72.602028715278266, -31.655348829726947, 0.0)
    viewCenter24 = NXOpen.Point3d(72.602028715278749, 31.655348829727224, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(-57.3901750796961, -25.842864983176359, 0.0)
    viewCenter25 = NXOpen.Point3d(57.390175079696597, 25.842864983176653, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(-45.773850485251522, -20.674291986541064, 0.0)
    viewCenter26 = NXOpen.Point3d(45.773850485252041, 20.674291986541345, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(-35.180868771746127, -16.650065252037059, 0.0)
    viewCenter27 = NXOpen.Point3d(35.180868771746638, 16.65006525203734, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(-27.879179026666687, -13.320052201629615, 0.0)
    viewCenter28 = NXOpen.Point3d(27.879179026667199, 13.320052201629903, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-22.232538957138591, -10.656041761303662, 0.0)
    viewCenter29 = NXOpen.Point3d(22.232538957139102, 10.656041761303946, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId20, None)
    
    theSession.SetUndoMarkName(markId16, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId19, None)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId18, None)
    
    theSession.DeleteUndoMark(markId16, None)
    
    sketchFindMovableObjectsBuilder4 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject8 = sketchFindMovableObjectsBuilder4.Commit()
    
    sketchFindMovableObjectsBuilder4.Destroy()
    
    scaleAboutPoint30 = NXOpen.Point3d(-18.125891633845423, -7.2220349478602488, 0.0)
    viewCenter30 = NXOpen.Point3d(18.125891633845946, 7.222034947860533, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(-14.908545868837816, -6.3214047073035395, 0.0)
    viewCenter31 = NXOpen.Point3d(14.908545868838342, 6.3214047073038255, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(-12.144347394676354, -5.3108862487166375, 0.0)
    viewCenter32 = NXOpen.Point3d(12.144347394676865, 5.3108862487169253, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-9.7734807689693337, -4.306711852201591, 0.0)
    viewCenter33 = NXOpen.Point3d(9.7734807689698506, 4.3067118522018779, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder2 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects3 = [None] * 1 
    dragobjects3[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects3[0].Geometry = line2
    dragobjects3[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects3[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects3)
    
    sketchDragGeometryBuilder2.SplineLinearScale = False
    
    foundrelations5 = sketchDragGeometryBuilder2.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects4 = [None] * 1 
    dragobjects4[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects4[0].Geometry = line2
    dragobjects4[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects4[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects4)
    
    foundrelations6 = sketchDragGeometryBuilder2.FindRelations()
    
    sketchDragGeometryBuilder2.Destroy()
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences2 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences2 = dimensionPreferences2.GetNarrowDimensionPreferences()
    
    option2 = narrowDimensionPreferences2.DimensionDisplayOption
    
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder2 = sketchLinearDimensionBuilder2.Driving
    
    drivingValueBuilder2.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject3 = sketchLinearDimensionBuilder2.FirstAssociativity
    
    selectNXObject4 = sketchLinearDimensionBuilder2.SecondAssociativity
    
    point1_7 = NXOpen.Point3d(5.7999999999999998, 0.0, 0.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject3.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, NXOpen.View.Null, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(5.7999999999999998, 8.4100000000000001, 0.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject4.SetValue(NXOpen.InferSnapType.SnapType.End, line2, NXOpen.View.Null, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    dimensionMeasurementBuilder2 = sketchLinearDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder2.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder2 = sketchLinearDimensionBuilder2.Origin
    
    origin10 = NXOpen.Point3d(6.4660970716636559, 4.2050000000000001, 0.0)
    originBuilder2.OriginPoint = origin10
    
    originBuilder2.SetInferRelativeToGeometry(True)
    
    nXObject9 = sketchLinearDimensionBuilder2.Commit()
    
    verticalDimension1 = nXObject9
    verticalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences2.Dispose()
    dimensionPreferences2.Dispose()
    sketchFindMovableObjectsBuilder5 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject10 = sketchFindMovableObjectsBuilder5.Commit()
    
    sketchFindMovableObjectsBuilder5.Destroy()
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder2 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension1)
    
    selectNXObjectList3 = sketchEditDimensionValueBuilder2.ExtraGeometries
    
    foundrelations7 = sketchEditDimensionValueBuilder2.FindRelations()
    
    sketchHelpedDimensionalConstraint2 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line2] StartVertex] [[Curve Line2] EndVertex]")
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId24, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId25, None)
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.DimValue = 8.0
    
    nXObject11 = sketchEditDimensionValueBuilder2.Commit()
    
    theSession.SetUndoMarkName(markId26, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId28, None)
    
    theSession.SetUndoMarkName(markId24, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId27, None)
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId26, None)
    
    theSession.DeleteUndoMark(markId24, None)
    
    sketchFindMovableObjectsBuilder6 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject12 = sketchFindMovableObjectsBuilder6.Commit()
    
    sketchFindMovableObjectsBuilder6.Destroy()
    
    sketchWorkRegionBuilder1 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder1.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject13 = sketchWorkRegionBuilder1.Commit()
    
    sketchWorkRegionBuilder1.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId30, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions1 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions1.SetSelectedFromInactive(False)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    curves1[0] = line1
    curves1[1] = line2
    curves1[2] = line3
    curves1[3] = line4
    seedPoint1 = NXOpen.Point3d(3.3267233999999997, 4.588584, 0.0)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch1, curves1, seedPoint1, 0.01, selectionIntentRuleOptions1)
    
    selectionIntentRuleOptions1.Dispose()
    section1.AllowSelfIntersection(True)
    
    section1.AllowDegenerateCurves(False)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId31, None)
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId33, None)
    
    direction3 = workPart.Directions.CreateDirection(sketch1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction3
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies2)
    
    targetBodies3 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies3)
    
    theSession.DeleteUndoMark(markId32, None)
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies4)
    
    targetBodies5 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies5)
    
    scaleAboutPoint34 = NXOpen.Point3d(77.275323777622944, -24.212934783655129, 0.0)
    viewCenter34 = NXOpen.Point3d(-77.275323777622944, 24.212934783655129, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(86.290778218345537, -26.402402290687764, 0.0)
    viewCenter35 = NXOpen.Point3d(-86.290778218345537, 26.402402290687764, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(103.03376503683023, -28.173295127258275, 0.0)
    viewCenter36 = NXOpen.Point3d(-103.03376503683077, 28.173295127258275, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(114.7055587324087, -27.167106015570564, 0.0)
    viewCenter37 = NXOpen.Point3d(-114.7055587324094, 27.167106015570564, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(128.28911174019436, -23.896991402585151, 0.0)
    viewCenter38 = NXOpen.Point3d(-128.28911174019478, 23.896991402585151, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(147.78402577914454, -23.582557305182782, 0.0)
    viewCenter39 = NXOpen.Point3d(-147.78402577914559, 23.582557305182782, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(120.74269340253544, -18.866045844146228, 0.0)
    viewCenter40 = NXOpen.Point3d(-120.7426934025365, 18.866045844146228, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(96.594154722028335, -17.105214898692637, 0.0)
    viewCenter41 = NXOpen.Point3d(-96.594154722029188, 17.105214898692463, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(77.27532377762239, -15.294074497654632, 0.0)
    viewCenter42 = NXOpen.Point3d(-77.275323777623498, 15.294074497654359, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(51.516882518414775, -12.235259598123815, 0.0)
    viewCenter43 = NXOpen.Point3d(-51.516882518415436, 12.235259598123484, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(41.213506014731827, -9.7882076784989636, 0.0)
    viewCenter44 = NXOpen.Point3d(-41.213506014732531, 9.7882076784987877, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(32.970804811785456, -9.4791063833885065, 0.0)
    viewCenter45 = NXOpen.Point3d(-32.970804811786088, 9.4791063833882951, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(41.21350601473182, -11.848882979235546, 0.0)
    viewCenter46 = NXOpen.Point3d(-41.213506014732523, 11.84888297923537, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(51.516882518414768, -14.811103724044539, 0.0)
    viewCenter47 = NXOpen.Point3d(-51.516882518415422, 14.811103724044209, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(64.396103148018739, -18.51387965505554, 0.0)
    viewCenter48 = NXOpen.Point3d(-64.396103148019563, 18.513879655055266, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(80.49512893502343, -23.142349568819597, 0.0)
    viewCenter49 = NXOpen.Point3d(-80.495128935024113, 23.142349568819082, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(105.64985672721798, -23.896991402585353, 0.0)
    viewCenter50 = NXOpen.Point3d(-105.64985672721883, 23.896991402584927, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(132.06232090902301, -29.871239253231696, 0.0)
    viewCenter51 = NXOpen.Point3d(-132.06232090902409, 29.87123925323116, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(165.07790113627877, -37.339049066539289, 0.0)
    viewCenter52 = NXOpen.Point3d(-165.0779011362801, 37.339049066538955, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(211.26040919226128, -46.673811333174108, 0.0)
    viewCenter53 = NXOpen.Point3d(-211.26040919226293, 46.673811333173688, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(454.45553140195909, -113.61388285049028, 0.0)
    viewCenter54 = NXOpen.Point3d(-454.45553140195909, 113.61388285048925, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(568.06941425244872, -142.01735356311283, 0.0)
    viewCenter55 = NXOpen.Point3d(-568.06941425244872, 142.01735356311218, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(710.08676781556096, -177.52169195389106, 0.0)
    viewCenter56 = NXOpen.Point3d(-710.08676781556096, 177.52169195389024, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(887.60845976945109, -209.90740602655904, 0.0)
    viewCenter57 = NXOpen.Point3d(-887.60845976945109, 209.90740602655904, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(1139.4973470013233, -262.38425753319882, 0.0)
    viewCenter58 = NXOpen.Point3d(-1139.4973470013233, 262.38425753319882, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(923.59258651686139, -209.90740602655904, 0.0)
    viewCenter59 = NXOpen.Point3d(-923.59258651686139, 209.90740602655904, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(738.87406921348747, -167.92592482124724, 0.0)
    viewCenter60 = NXOpen.Point3d(-738.87406921349077, 167.92592482124724, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(591.09925537079118, -134.34073985699777, 0.0)
    viewCenter61 = NXOpen.Point3d(-591.09925537079255, 134.34073985699777, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(460.59682236684989, -107.47259188559821, 0.0)
    viewCenter62 = NXOpen.Point3d(-460.596822366852, 107.47259188559821, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(363.56442512156627, -85.978073508478559, 0.0)
    viewCenter63 = NXOpen.Point3d(-363.56442512156798, 85.978073508478559, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(290.85154009725301, -68.782458806782842, 0.0)
    viewCenter64 = NXOpen.Point3d(-290.85154009725471, 68.782458806782842, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(229.53689110377772, -55.025967045426292, 0.0)
    viewCenter65 = NXOpen.Point3d(-229.53689110377988, 55.025967045426292, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(17.608309454535039, -36.474355298682539, 0.0)
    viewCenter66 = NXOpen.Point3d(-17.608309454537611, 36.474355298682752, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(-1.3726854990924923e-12, -25.154727792194898, 0.0)
    viewCenter67 = NXOpen.Point3d(-1.0295141243193692e-12, 25.154727792195068, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(-3.2198051574021447, -20.123782233755783, 0.0)
    viewCenter68 = NXOpen.Point3d(3.2198051573999482, 20.12378223375606, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(-14.167142692565372, -13.523181661083902, 0.0)
    viewCenter69 = NXOpen.Point3d(14.167142692563177, 13.52318166108423, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(-42.24384366510165, 9.7882076784990524, 0.0)
    viewCenter70 = NXOpen.Point3d(42.243843665099455, -9.7882076784988765, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(-35.443615172670867, 12.776186864567178, 0.0)
    viewCenter71 = NXOpen.Point3d(35.443615172668544, -12.776186864566968, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(-28.354892138136918, 10.220949491653743, 0.0)
    viewCenter72 = NXOpen.Point3d(28.354892138134669, -10.220949491653519, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(-35.44361517267086, 12.776186864567107, 0.0)
    viewCenter73 = NXOpen.Point3d(35.443615172668608, -12.776186864566895, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(-44.30451896583822, 15.970233580708882, 0.0)
    viewCenter74 = NXOpen.Point3d(44.304518965836024, -15.970233580708706, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(-55.380648707297546, 19.962791975886098, 0.0)
    viewCenter75 = NXOpen.Point3d(55.38064870729535, -19.962791975885768, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(-69.225810884121657, 24.953489969857625, 0.0)
    viewCenter76 = NXOpen.Point3d(69.225810884119326, -24.953489969857351, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(-78.482750711649629, 31.191862462322028, 0.0)
    viewCenter77 = NXOpen.Point3d(78.482750711646887, -31.191862462321858, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(-95.587965610342252, 38.989828077902324, 0.0)
    viewCenter78 = NXOpen.Point3d(95.587965610339467, -38.989828077902104, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(-119.48495701292727, 45.59294412335371, 0.0)
    viewCenter79 = NXOpen.Point3d(119.4849570129246, -45.59294412335317, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(-145.42577004862852, 56.991180154192136, 0.0)
    viewCenter80 = NXOpen.Point3d(145.42577004862551, -56.991180154191461, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(-117.91278652591552, 105.63020459613185, 0.0)
    viewCenter81 = NXOpen.Point3d(117.91278652591217, -105.63020459613143, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(-147.39098315739335, 132.03775574516482, 0.0)
    viewCenter82 = NXOpen.Point3d(147.39098315739125, -132.03775574516376, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(-184.23872894674167, 165.04719468145601, 0.0)
    viewCenter83 = NXOpen.Point3d(184.23872894673906, -165.0471946814547, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint83, viewCenter83)
    
    scaleAboutPoint84 = NXOpen.Point3d(-230.29841118342705, 206.30899335181996, 0.0)
    viewCenter84 = NXOpen.Point3d(230.2984111834254, -206.30899335181914, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(-287.87301397928383, 221.90211494236371, 0.0)
    viewCenter85 = NXOpen.Point3d(287.87301397927973, -221.90211494236371, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint85, viewCenter85)
    
    scaleAboutPoint86 = NXOpen.Point3d(-359.84126747410477, 262.38425753319996, 0.0)
    viewCenter86 = NXOpen.Point3d(359.84126747409965, -262.38425753319996, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint86, viewCenter86)
    
    scaleAboutPoint87 = NXOpen.Point3d(-449.80158434263092, 309.23858923555656, 0.0)
    viewCenter87 = NXOpen.Point3d(449.80158434262455, -309.23858923555656, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(-538.82481457711151, 386.54823654444573, 0.0)
    viewCenter88 = NXOpen.Point3d(538.82481457710355, -386.54823654444573, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(-439.25935970959733, 483.18529568055709, 0.0)
    viewCenter89 = NXOpen.Point3d(439.25935970959233, -483.18529568055709, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(-512.46925299453858, 603.98161960069638, 0.0)
    viewCenter90 = NXOpen.Point3d(512.46925299452607, -603.98161960069638, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(-640.58656624317325, 754.97702450086661, 0.0)
    viewCenter91 = NXOpen.Point3d(640.58656624315756, -754.97702450087434, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(-800.73320780396648, 1000.9165097549386, 0.0)
    viewCenter92 = NXOpen.Point3d(800.73320780394693, -1000.9165097549484, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint92, viewCenter92)
    
    scaleAboutPoint93 = NXOpen.Point3d(-1000.916509754958, 1251.1456371936731, 0.0)
    viewCenter93 = NXOpen.Point3d(1000.9165097549337, -1251.1456371936792, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(-1251.1456371936822, 1563.9320464920991, 0.0)
    viewCenter94 = NXOpen.Point3d(1251.1456371936822, -1563.9320464920991, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(-1563.9320464921027, 1954.9150581151234, 0.0)
    viewCenter95 = NXOpen.Point3d(1563.9320464921027, -1954.9150581151234, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(-1815.2782682497464, 2443.6438226439041, 0.0)
    viewCenter96 = NXOpen.Point3d(1815.2782682497464, -2443.6438226439041, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(-1570.9138859853645, 3054.5547783048801, 0.0)
    viewCenter97 = NXOpen.Point3d(1570.9138859853645, -3054.5547783048801, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(-1963.6423574817059, 3818.1934728811007, 0.0)
    viewCenter98 = NXOpen.Point3d(1963.6423574817059, -3818.1934728811007, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(-1909.0967364405549, 4500.0137358955753, 0.0)
    viewCenter99 = NXOpen.Point3d(1909.0967364405549, -4500.0137358955753, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint99, viewCenter99)
    
    scaleAboutPoint100 = NXOpen.Point3d(-340.91013150725024, 4602.2867753477476, 0.0)
    viewCenter100 = NXOpen.Point3d(340.91013150725024, -4602.2867753477476, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(-272.7281052058002, 3681.8294202781981, 0.0)
    viewCenter101 = NXOpen.Point3d(272.7281052058002, -3681.8294202781749, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(-218.18248416464019, 2945.4635362225772, 0.0)
    viewCenter102 = NXOpen.Point3d(218.18248416464019, -2945.4635362225399, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(0.0, 2356.3708289780616, 0.0)
    viewCenter103 = NXOpen.Point3d(0.0, -2356.370828978032, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(0.0, 1885.096663182449, 0.0)
    viewCenter104 = NXOpen.Point3d(0.0, -1885.0966631824253, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(111.70943189228623, 1508.0773305459595, 0.0)
    viewCenter105 = NXOpen.Point3d(-111.70943189228623, -1508.0773305459309, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(89.367545513828986, 1295.8294099506118, 0.0)
    viewCenter106 = NXOpen.Point3d(-89.367545513828986, -1295.8294099505813, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(-71.494036411063192, 1108.1575643715587, 0.0)
    viewCenter107 = NXOpen.Point3d(71.494036411063192, -1108.1575643715405, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint107, viewCenter107)
    
    scaleAboutPoint108 = NXOpen.Point3d(-457.56183303083367, 1058.1117388838084, 0.0)
    viewCenter108 = NXOpen.Point3d(457.56183303083367, -1058.1117388837888, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(-503.31801633391603, 892.24557441013098, 0.0)
    viewCenter109 = NXOpen.Point3d(503.31801633391603, -892.24557441010757, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(-622.28409292193146, 787.00635281303983, 0.0)
    viewCenter110 = NXOpen.Point3d(622.28409292193146, -787.006352813018, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(-1434.9139083846851, 951.72861270413807, 0.0)
    viewCenter111 = NXOpen.Point3d(1434.9139083846851, -951.72861270411568, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(-1218.2126242612837, 761.3828901633126, 0.0)
    viewCenter112 = NXOpen.Point3d(1218.2126242612837, -761.38289016329054, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(-1087.0204954946842, 609.10631213065176, 0.0)
    viewCenter113 = NXOpen.Point3d(1087.020495494681, -609.10631213063255, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(-914.59655483000995, 487.28504970452389, 0.0)
    viewCenter114 = NXOpen.Point3d(914.59655483000995, -487.28504970450348, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint114, viewCenter114)
    
    scaleAboutPoint115 = NXOpen.Point3d(-791.65078844302457, 389.82803976362118, 0.0)
    viewCenter115 = NXOpen.Point3d(791.65078844302457, -389.82803976360071, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(-2801.964002731675, 935.58729543267623, 0.0)
    viewCenter116 = NXOpen.Point3d(2801.964002731675, -935.58729543265497, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(-2241.5712021853401, 702.41015410945772, 0.0)
    viewCenter117 = NXOpen.Point3d(2241.5712021853401, -702.41015410943669, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(-1793.256961748272, 525.08037749822029, 0.0)
    viewCenter118 = NXOpen.Point3d(1793.256961748272, -525.08037749819925, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(-1429.6925366267046, 410.23823645475233, 0.0)
    viewCenter119 = NXOpen.Point3d(1429.6925366267042, -410.23823645473141, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(-1124.1018982137123, 312.46888429368192, 0.0)
    viewCenter120 = NXOpen.Point3d(1124.1018982137109, -312.46888429366112, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(-732.63144694767823, 237.39774353885022, 0.0)
    viewCenter121 = NXOpen.Point3d(732.6314469476772, -237.3977435388293, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(-583.58968477892313, 189.91819483108233, 0.0)
    viewCenter122 = NXOpen.Point3d(583.58968477892222, -189.91819483106133, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(-464.85936959976283, 149.9221776414922, 0.0)
    viewCenter123 = NXOpen.Point3d(464.85936959976209, -149.92217764147159, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(-370.27759310110991, 116.71793695579484, 0.0)
    viewCenter124 = NXOpen.Point3d(370.27759310110935, -116.71793695577412, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(-287.20662004016521, 92.086427501677591, 0.0)
    viewCenter125 = NXOpen.Point3d(287.20662004016475, -92.086427501656843, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(-226.67428308102731, 73.669142001344198, 0.0)
    viewCenter126 = NXOpen.Point3d(226.67428308102686, -73.669142001323465, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(-180.51515634452733, 58.935313601077475, 0.0)
    viewCenter127 = NXOpen.Point3d(180.51515634452676, -58.93531360105667, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(-144.41212507562187, 47.148250880864062, 0.0)
    viewCenter128 = NXOpen.Point3d(144.4121250756213, -47.148250880843257, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(-117.11229869146325, 37.718600704693351, 0.0)
    viewCenter129 = NXOpen.Point3d(117.11229869146267, -37.718600704672482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(-94.533891556352444, 30.174880563756773, 0.0)
    viewCenter130 = NXOpen.Point3d(94.533891556351861, -30.174880563735904, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(-76.977597410172734, 24.139904451007492, 0.0)
    viewCenter131 = NXOpen.Point3d(76.977597410172166, -24.13990445098662, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    scaleAboutPoint132 = NXOpen.Point3d(-64.012949425301571, 19.852117226844381, 0.0)
    viewCenter132 = NXOpen.Point3d(64.012949425301002, -19.852117226823491, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(-53.587211670801061, 17.826390979208259, 0.0)
    viewCenter133 = NXOpen.Point3d(53.587211670800471, -17.826390979187401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(-42.869769336640907, 14.779698702763547, 0.0)
    viewCenter134 = NXOpen.Point3d(42.869769336640317, -14.779698702742676, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(-34.295815469312792, 12.10033811922351, 0.0)
    viewCenter135 = NXOpen.Point3d(34.295815469312181, -12.100338119202627, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint135, viewCenter135)
    
    scaleAboutPoint136 = NXOpen.Point3d(-27.436652375450297, 9.9015338209893642, 0.0)
    viewCenter136 = NXOpen.Point3d(27.436652375449693, -9.9015338209684884, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(-21.241279258413211, 12.612009559693092, 0.0)
    viewCenter137 = NXOpen.Point3d(21.241279258412579, -12.61200955967222, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(-16.922219142535926, 10.302020440340693, 0.0)
    viewCenter138 = NXOpen.Point3d(16.922219142535297, -10.302020440319817, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint138, viewCenter138)
    
    scaleAboutPoint139 = NXOpen.Point3d(-13.537775314028806, 8.2982597636304085, 0.0)
    viewCenter139 = NXOpen.Point3d(13.537775314028163, -8.2982597636095345, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(-10.830220251223107, 6.7292372690756412, 0.0)
    viewCenter140 = NXOpen.Point3d(10.830220251222469, -6.7292372690547655, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint140, viewCenter140)
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId34, None)
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId35, None)
    
    theSession.SetUndoMarkName(markId30, "Extrude")
    
    expression4 = extrudeBuilder1.Limits.StartExtend.Value
    expression5 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression3)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin11, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression7 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder2 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId38, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder2.UseWorkPartOrigin = False
    
    coordinates3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point4 = workPart.Points.CreatePoint(coordinates3)
    
    origin12 = NXOpen.Point3d(3.647557165894006, 4.7475570705265744, 0.0)
    matrix3 = NXOpen.Matrix3x3()
    
    matrix3.Xx = 1.0
    matrix3.Xy = 0.0
    matrix3.Xz = 0.0
    matrix3.Yx = 0.0
    matrix3.Yy = 1.0
    matrix3.Yz = 0.0
    matrix3.Zx = 0.0
    matrix3.Zy = 0.0
    matrix3.Zz = 1.0
    plane5 = workPart.Planes.CreateFixedTypePlane(origin12, matrix3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point5 = workPart.Points.CreatePoint(coordinates4)
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction4 = workPart.Directions.CreateDirection(origin13, vector3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector4 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction5 = workPart.Directions.CreateDirection(origin14, vector4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix4 = NXOpen.Matrix3x3()
    
    matrix4.Xx = 1.0
    matrix4.Xy = 0.0
    matrix4.Xz = 0.0
    matrix4.Yx = 0.0
    matrix4.Yy = 1.0
    matrix4.Yz = 0.0
    matrix4.Zx = 0.0
    matrix4.Zy = 0.0
    matrix4.Zz = 1.0
    plane6 = workPart.Planes.CreateFixedTypePlane(origin15, matrix4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane6, direction5, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder2.CoordinateSystem = cartesianCoordinateSystem2
    
    simpleSketchInPlaceBuilder2.HorizontalReference.Value = datumAxis1
    
    point6 = simpleSketchInPlaceBuilder2.SketchOrigin
    
    simpleSketchInPlaceBuilder2.SketchOrigin = point6
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId39, None)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject14 = simpleSketchInPlaceBuilder2.Commit()
    
    sketch2 = nXObject14
    feature3 = sketch2.Feature
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId41)
    
    sketch2.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder7 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject15 = sketchFindMovableObjectsBuilder7.Commit()
    
    sketchFindMovableObjectsBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId40, None)
    
    theSession.SetUndoMarkName(markId38, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    simpleSketchInPlaceBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression7)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression6)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId37, None, True)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_001")
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId44, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(1.7400855968480755, 0.0, 0.0)
    endPoint5 = NXOpen.Point3d(3.940085596848077, 0.0, 0.0)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(3.940085596848077, 0.0, 0.0)
    endPoint6 = NXOpen.Point3d(3.940085596848077, 6.1000000000000005, 0.0)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(3.940085596848077, 6.1000000000000005, 0.0)
    endPoint7 = NXOpen.Point3d(1.7400855968480755, 6.1000000000000005, 0.0)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(1.7400855968480755, 6.1000000000000005, 0.0)
    endPoint8 = NXOpen.Point3d(1.7400855968480755, 0.0, 0.0)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line5
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line6
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line6
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line7
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line7
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line8
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line8
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line5
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    objects2 = [NXOpen.NXObject.Null] * 4 
    objects2[0] = sketchGeometricConstraint5
    objects2[1] = sketchGeometricConstraint6
    objects2[2] = sketchGeometricConstraint7
    objects2[3] = sketchGeometricConstraint8
    errorList2 = theSession.ActiveSketch.DeleteObjects(objects2)
    
    errorList2.Dispose()
    sketchFindMovableObjectsBuilder8 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject16 = sketchFindMovableObjectsBuilder8.Commit()
    
    sketchFindMovableObjectsBuilder8.Destroy()
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder3 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects5 = [None] * 1 
    dragobjects5[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects5[0].Geometry = line7
    dragobjects5[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects5[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects5)
    
    sketchDragGeometryBuilder3.SplineLinearScale = False
    
    foundrelations8 = sketchDragGeometryBuilder3.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects6 = [None] * 1 
    dragobjects6[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects6[0].Geometry = line7
    dragobjects6[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects6[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects6)
    
    foundrelations9 = sketchDragGeometryBuilder3.FindRelations()
    
    sketchDragGeometryBuilder3.Destroy()
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences3 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences3 = dimensionPreferences3.GetNarrowDimensionPreferences()
    
    option3 = narrowDimensionPreferences3.DimensionDisplayOption
    
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder3 = sketchLinearDimensionBuilder3.Driving
    
    drivingValueBuilder3.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject5 = sketchLinearDimensionBuilder3.FirstAssociativity
    
    selectNXObject6 = sketchLinearDimensionBuilder3.SecondAssociativity
    
    point1_11 = NXOpen.Point3d(3.940085596848077, 6.1000000000000005, 0.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject5.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, NXOpen.View.Null, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(1.7400855968480755, 6.1000000000000005, 0.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject6.SetValue(NXOpen.InferSnapType.SnapType.End, line7, NXOpen.View.Null, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    dimensionMeasurementBuilder3 = sketchLinearDimensionBuilder3.Measurement
    
    dimensionMeasurementBuilder3.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder3 = sketchLinearDimensionBuilder3.Origin
    
    origin17 = NXOpen.Point3d(2.840085596848076, 7.3331315253261931, 0.0)
    originBuilder3.OriginPoint = origin17
    
    originBuilder3.SetInferRelativeToGeometry(True)
    
    nXObject17 = sketchLinearDimensionBuilder3.Commit()
    
    horizontalDimension2 = nXObject17
    horizontalDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder3.Destroy()
    
    narrowDimensionPreferences3.Dispose()
    dimensionPreferences3.Dispose()
    sketchFindMovableObjectsBuilder9 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject18 = sketchFindMovableObjectsBuilder9.Commit()
    
    sketchFindMovableObjectsBuilder9.Destroy()
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder3 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension2)
    
    selectNXObjectList4 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations10 = sketchEditDimensionValueBuilder3.FindRelations()
    
    sketchHelpedDimensionalConstraint3 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line7] StartVertex] [[Curve Line7] EndVertex]")
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId48, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId48, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId49, None)
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.DimValue = 3.7999999999999998
    
    theSession.ActiveSketch.Scale(1.7272727272727271)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin18 = NXOpen.Point3d(4.9056023945557667, 12.666318089199786, 0.0)
    horizontalDimension2.AnnotationOrigin = origin18
    
    sketchEditDimensionValueBuilder3.RestoreOperation()
    
    sketchEditDimensionValueBuilder3.LoadExtraGeometry()
    
    selectNXObjectList5 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations11 = sketchEditDimensionValueBuilder3.FindRelations()
    
    nXObject19 = sketchEditDimensionValueBuilder3.Commit()
    
    theSession.SetUndoMarkName(markId50, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId48, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId52, None)
    
    theSession.SetUndoMarkName(markId48, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId51, None)
    
    theSession.SetUndoMarkVisibility(markId48, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId50, None)
    
    theSession.DeleteUndoMark(markId48, None)
    
    sketchFindMovableObjectsBuilder10 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject20 = sketchFindMovableObjectsBuilder10.Commit()
    
    sketchFindMovableObjectsBuilder10.Destroy()
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder4 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects7 = [None] * 1 
    dragobjects7[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects7[0].Geometry = line6
    dragobjects7[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects7[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects7)
    
    sketchDragGeometryBuilder4.SplineLinearScale = False
    
    foundrelations12 = sketchDragGeometryBuilder4.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects8 = [None] * 1 
    dragobjects8[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects8[0].Geometry = line6
    dragobjects8[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects8[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects8)
    
    foundrelations13 = sketchDragGeometryBuilder4.FindRelations()
    
    sketchDragGeometryBuilder4.Destroy()
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences4 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences4 = dimensionPreferences4.GetNarrowDimensionPreferences()
    
    option4 = narrowDimensionPreferences4.DimensionDisplayOption
    
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder4 = sketchLinearDimensionBuilder4.Driving
    
    drivingValueBuilder4.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject7 = sketchLinearDimensionBuilder4.FirstAssociativity
    
    selectNXObject8 = sketchLinearDimensionBuilder4.SecondAssociativity
    
    point1_15 = NXOpen.Point3d(6.8056023945557689, 0.0, 0.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject7.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, NXOpen.View.Null, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(6.8056023945557689, 10.536363636363635, 0.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject8.SetValue(NXOpen.InferSnapType.SnapType.End, line6, NXOpen.View.Null, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    dimensionMeasurementBuilder4 = sketchLinearDimensionBuilder4.Measurement
    
    dimensionMeasurementBuilder4.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder4 = sketchLinearDimensionBuilder4.Origin
    
    origin20 = NXOpen.Point3d(8.9355568473919185, 5.2681818181818176, 0.0)
    originBuilder4.OriginPoint = origin20
    
    originBuilder4.SetInferRelativeToGeometry(True)
    
    nXObject21 = sketchLinearDimensionBuilder4.Commit()
    
    verticalDimension2 = nXObject21
    verticalDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder4.Destroy()
    
    narrowDimensionPreferences4.Dispose()
    dimensionPreferences4.Dispose()
    sketchFindMovableObjectsBuilder11 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject22 = sketchFindMovableObjectsBuilder11.Commit()
    
    sketchFindMovableObjectsBuilder11.Destroy()
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder4 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension2)
    
    selectNXObjectList6 = sketchEditDimensionValueBuilder4.ExtraGeometries
    
    foundrelations14 = sketchEditDimensionValueBuilder4.FindRelations()
    
    sketchHelpedDimensionalConstraint4 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line6] StartVertex] [[Curve Line6] EndVertex]")
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId56, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId56, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId57, None)
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.DimValue = 7.0
    
    nXObject23 = sketchEditDimensionValueBuilder4.Commit()
    
    theSession.SetUndoMarkName(markId58, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId56, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId60, None)
    
    theSession.SetUndoMarkName(markId56, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId59, None)
    
    theSession.SetUndoMarkVisibility(markId56, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId58, None)
    
    theSession.DeleteUndoMark(markId56, None)
    
    sketchFindMovableObjectsBuilder12 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject24 = sketchFindMovableObjectsBuilder12.Commit()
    
    sketchFindMovableObjectsBuilder12.Destroy()
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder5 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects9 = [None] * 1 
    dragobjects9[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects9[0].Geometry = line8
    dragobjects9[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects9[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects9)
    
    sketchDragGeometryBuilder5.SplineLinearScale = False
    
    foundrelations15 = sketchDragGeometryBuilder5.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects10 = [None] * 1 
    dragobjects10[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects10[0].Geometry = line8
    dragobjects10[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects10[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects10)
    
    foundrelations16 = sketchDragGeometryBuilder5.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects11 = [None] * 1 
    dragobjects11[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects11[0].Geometry = line8
    dragobjects11[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects11[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects11)
    
    foundrelations17 = sketchDragGeometryBuilder5.FindRelations()
    
    sketchDragGeometryBuilder5.Destroy()
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences5 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences5 = dimensionPreferences5.GetNarrowDimensionPreferences()
    
    option5 = narrowDimensionPreferences5.DimensionDisplayOption
    
    sketchLinearDimensionBuilder5 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder5 = sketchLinearDimensionBuilder5.Driving
    
    drivingValueBuilder5.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder5 = sketchLinearDimensionBuilder5.Measurement
    
    dimensionMeasurementBuilder5.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject9 = sketchLinearDimensionBuilder5.FirstAssociativity
    
    selectNXObject10 = sketchLinearDimensionBuilder5.SecondAssociativity
    
    point1_21 = NXOpen.Point3d(3.0056023945557664, 5.2021308989241444, 0.0)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject9.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line8, NXOpen.View.Null, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    point1_22 = NXOpen.Point3d(0.0, 8.0, 0.0)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject10.SetValue(NXOpen.InferSnapType.SnapType.Start, line4, NXOpen.View.Null, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    originBuilder5 = sketchLinearDimensionBuilder5.Origin
    
    origin23 = NXOpen.Point3d(1.5028011972778832, 5.1296273323887602, 0.0)
    originBuilder5.OriginPoint = origin23
    
    originBuilder5.SetInferRelativeToGeometry(True)
    
    nXObject25 = sketchLinearDimensionBuilder5.Commit()
    
    perpendicularDimension1 = nXObject25
    perpendicularDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder5.Destroy()
    
    narrowDimensionPreferences5.Dispose()
    dimensionPreferences5.Dispose()
    sketchFindMovableObjectsBuilder13 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject26 = sketchFindMovableObjectsBuilder13.Commit()
    
    sketchFindMovableObjectsBuilder13.Destroy()
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder5 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension1)
    
    selectNXObjectList7 = sketchEditDimensionValueBuilder5.ExtraGeometries
    
    foundrelations18 = sketchEditDimensionValueBuilder5.FindRelations()
    
    sketchHelpedDimensionalConstraint5 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line8] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line4] StartVertex]")
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId64, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId65, None)
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.DimValue = 1.0
    
    nXObject27 = sketchEditDimensionValueBuilder5.Commit()
    
    theSession.SetUndoMarkName(markId66, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId66, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId68, None)
    
    theSession.SetUndoMarkName(markId64, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.Destroy()
    
    theSession.DeleteUndoMark(markId67, None)
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId66, None)
    
    theSession.DeleteUndoMark(markId64, None)
    
    sketchFindMovableObjectsBuilder14 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject28 = sketchFindMovableObjectsBuilder14.Commit()
    
    sketchFindMovableObjectsBuilder14.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder2 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder2.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject29 = sketchWorkRegionBuilder2.Commit()
    
    sketchWorkRegionBuilder2.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies6)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies7)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId70, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions2 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions2.SetSelectedFromInactive(False)
    
    curves2 = [NXOpen.ICurve.Null] * 4 
    curves2[0] = line5
    curves2[1] = line6
    curves2[2] = line7
    curves2[3] = line8
    seedPoint2 = NXOpen.Point3d(3.1795774000000012, 4.0150109999999994, 0.0)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch2, curves2, seedPoint2, 0.01, selectionIntentRuleOptions2)
    
    selectionIntentRuleOptions2.Dispose()
    section2.AllowSelfIntersection(True)
    
    section2.AllowDegenerateCurves(False)
    
    rules2 = [None] * 1 
    rules2[0] = regionBoundaryRule2
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section2.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId71, None)
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId73, None)
    
    direction6 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction6
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies8[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies9)
    
    theSession.DeleteUndoMark(markId72, None)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies10)
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId74, None)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId75, None)
    
    theSession.SetUndoMarkName(markId70, "Extrude")
    
    expression9 = extrudeBuilder2.Limits.StartExtend.Value
    expression10 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression8)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin24, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane7
    
    expression11 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder3 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId78, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder3.UseWorkPartOrigin = False
    
    coordinates5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point7 = workPart.Points.CreatePoint(coordinates5)
    
    origin25 = NXOpen.Point3d(0.0, 4.7475570705265744, 3.7475570705265744)
    matrix5 = NXOpen.Matrix3x3()
    
    matrix5.Xx = 0.0
    matrix5.Xy = 1.0
    matrix5.Xz = 0.0
    matrix5.Yx = 0.0
    matrix5.Yy = 0.0
    matrix5.Yz = 1.0
    matrix5.Zx = 1.0
    matrix5.Zy = 0.0
    matrix5.Zz = 0.0
    plane8 = workPart.Planes.CreateFixedTypePlane(origin25, matrix5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point8 = workPart.Points.CreatePoint(coordinates6)
    
    origin26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector5 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction7 = workPart.Directions.CreateDirection(origin26, vector5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector6 = NXOpen.Vector3d(0.0, 1.0, 0.0)
    direction8 = workPart.Directions.CreateDirection(origin27, vector6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix6 = NXOpen.Matrix3x3()
    
    matrix6.Xx = 0.0
    matrix6.Xy = 1.0
    matrix6.Xz = 0.0
    matrix6.Yx = 0.0
    matrix6.Yy = 0.0
    matrix6.Yz = 1.0
    matrix6.Zx = 1.0
    matrix6.Zy = 0.0
    matrix6.Zz = 0.0
    plane9 = workPart.Planes.CreateFixedTypePlane(origin28, matrix6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane9, direction8, point8, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder3.CoordinateSystem = cartesianCoordinateSystem3
    
    datumAxis2 = workPart.Datums.FindObject("DATUM_CSYS(0) Y axis")
    simpleSketchInPlaceBuilder3.HorizontalReference.Value = datumAxis2
    
    point9 = simpleSketchInPlaceBuilder3.SketchOrigin
    
    simpleSketchInPlaceBuilder3.SketchOrigin = point9
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId79, None)
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject30 = simpleSketchInPlaceBuilder3.Commit()
    
    sketch3 = nXObject30
    feature5 = sketch3.Feature
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId81)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder15 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject31 = sketchFindMovableObjectsBuilder15.Commit()
    
    sketchFindMovableObjectsBuilder15.Destroy()
    
    theSession.DeleteUndoMark(markId80, None)
    
    theSession.SetUndoMarkName(markId78, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    simpleSketchInPlaceBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression12)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression11)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId77, None, True)
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_002")
    
    scaleAboutPoint141 = NXOpen.Point3d(5.9452924559010611, 3.2445346024688151, 0.0)
    viewCenter141 = NXOpen.Point3d(-5.945292455901698, -3.244534602447938, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint141, viewCenter141)
    
    scaleAboutPoint142 = NXOpen.Point3d(7.3409861117071813, 4.0556682530834145, 0.0)
    viewCenter142 = NXOpen.Point3d(-7.3409861117078181, -4.0556682530625308, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(9.176232639634053, 5.0695853163516551, 0.0)
    viewCenter143 = NXOpen.Point3d(-9.1762326396346907, -5.0695853163307714, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(11.470290799542651, 6.3369816454369605, 0.0)
    viewCenter144 = NXOpen.Point3d(-11.470290799543285, -6.3369816454160723, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint144, viewCenter144)
    
    scaleAboutPoint145 = NXOpen.Point3d(14.337863499428387, 7.9212270567935814, 0.0)
    viewCenter145 = NXOpen.Point3d(-14.337863499429021, -7.9212270567727083, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(11.470290799542637, 6.3369816454369481, 0.0)
    viewCenter146 = NXOpen.Point3d(-11.470290799543278, -6.3369816454160777, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint146, viewCenter146)
    
    scaleAboutPoint147 = NXOpen.Point3d(9.1762326396340512, 5.0695853163516444, 0.0)
    viewCenter147 = NXOpen.Point3d(-9.1762326396346943, -5.0695853163307802, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(7.3409861117071795, 4.0556682530833985, 0.0)
    viewCenter148 = NXOpen.Point3d(-7.3409861117078172, -4.0556682530625379, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(5.7640335395626092, 3.2445346024688089, 0.0)
    viewCenter149 = NXOpen.Point3d(-5.7640335395632452, -3.2445346024479442, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(4.6112268316500211, 2.5956276819771333, 0.0)
    viewCenter150 = NXOpen.Point3d(-4.6112268316506544, -2.5956276819562678, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint150, viewCenter150)
    
    scaleAboutPoint151 = NXOpen.Point3d(3.619378041445986, 2.1925078520404049, 0.0)
    viewCenter151 = NXOpen.Point3d(-3.6193780414466188, -2.1925078520195402, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint151, viewCenter151)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId84, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(0.0, 4.4000000000000004, 2.8000000000000003)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 1.3567747357775997, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder16 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject32 = sketchFindMovableObjectsBuilder16.Commit()
    
    sketchFindMovableObjectsBuilder16.Destroy()
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder6 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects12 = [None] * 1 
    dragobjects12[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects12[0].Geometry = arc1
    dragobjects12[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects12[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects12)
    
    sketchDragGeometryBuilder6.SplineLinearScale = False
    
    foundrelations19 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects13 = [None] * 1 
    dragobjects13[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects13[0].Geometry = arc1
    dragobjects13[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects13[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects13)
    
    foundrelations20 = sketchDragGeometryBuilder6.FindRelations()
    
    sketchDragGeometryBuilder6.Destroy()
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences6 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences6 = dimensionPreferences6.GetNarrowDimensionPreferences()
    
    option6 = narrowDimensionPreferences6.DimensionDisplayOption
    
    sketchRadialDimensionBuilder1 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder6 = sketchRadialDimensionBuilder1.Driving
    
    drivingValueBuilder6.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject11 = sketchRadialDimensionBuilder1.FirstAssociativity
    
    point1_24 = NXOpen.Point3d(0.0, 4.4000000000000004, 2.8000000000000003)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject11.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, NXOpen.View.Null, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    dimensionMeasurementBuilder6 = sketchRadialDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder6.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder6 = sketchRadialDimensionBuilder1.Origin
    
    origin30 = NXOpen.Point3d(0.0, 6.4660011706675444, 3.7624173770711185)
    originBuilder6.OriginPoint = origin30
    
    originBuilder6.SetInferRelativeToGeometry(True)
    
    nXObject33 = sketchRadialDimensionBuilder1.Commit()
    
    sketchRadialDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences6.Dispose()
    dimensionPreferences6.Dispose()
    sketchFindMovableObjectsBuilder17 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject34 = sketchFindMovableObjectsBuilder17.Commit()
    
    sketchFindMovableObjectsBuilder17.Destroy()
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension1 = nXObject33
    sketchEditDimensionValueBuilder6 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension1)
    
    selectNXObjectList8 = sketchEditDimensionValueBuilder6.ExtraGeometries
    
    foundrelations21 = sketchEditDimensionValueBuilder6.FindRelations()
    
    sketchDimensionalConstraint1 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc1]")
    sketchDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId88, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId88, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId89, None)
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.DimValue = 3.0
    
    theSession.ActiveSketch.Scale(1.1055630388898343)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin31 = NXOpen.Point3d(0.0, 7.1485719037084374, 4.1595895889666652)
    diameterDimension1.AnnotationOrigin = origin31
    
    sketchEditDimensionValueBuilder6.RestoreOperation()
    
    sketchEditDimensionValueBuilder6.LoadExtraGeometry()
    
    selectNXObjectList9 = sketchEditDimensionValueBuilder6.ExtraGeometries
    
    foundrelations22 = sketchEditDimensionValueBuilder6.FindRelations()
    
    nXObject35 = sketchEditDimensionValueBuilder6.Commit()
    
    theSession.SetUndoMarkName(markId90, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId90, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId88, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId92, None)
    
    theSession.SetUndoMarkName(markId88, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.Destroy()
    
    theSession.DeleteUndoMark(markId91, None)
    
    theSession.SetUndoMarkVisibility(markId88, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId90, None)
    
    theSession.DeleteUndoMark(markId88, None)
    
    sketchFindMovableObjectsBuilder18 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject36 = sketchFindMovableObjectsBuilder18.Commit()
    
    sketchFindMovableObjectsBuilder18.Destroy()
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder7 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects14 = [None] * 1 
    dragobjects14[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects14[0].Geometry = arc1
    dragobjects14[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects14[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects14)
    
    sketchDragGeometryBuilder7.SplineLinearScale = False
    
    foundrelations23 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects15 = [None] * 1 
    dragobjects15[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects15[0].Geometry = arc1
    dragobjects15[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects15[0].PointIndex = -1475379168
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects15)
    
    foundrelations24 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects16 = [None] * 1 
    dragobjects16[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects16[0].Geometry = arc1
    dragobjects16[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects16[0].PointIndex = -1475379088
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects16)
    
    foundrelations25 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects17 = [None] * 1 
    dragobjects17[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects17[0].Geometry = arc1
    dragobjects17[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects17[0].PointIndex = -1475378416
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects17)
    
    foundrelations26 = sketchDragGeometryBuilder7.FindRelations()
    
    sketchDragGeometryBuilder7.Destroy()
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences7 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences7 = dimensionPreferences7.GetNarrowDimensionPreferences()
    
    option7 = narrowDimensionPreferences7.DimensionDisplayOption
    
    sketchLinearDimensionBuilder6 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder7 = sketchLinearDimensionBuilder6.Driving
    
    drivingValueBuilder7.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder7 = sketchLinearDimensionBuilder6.Measurement
    
    dimensionMeasurementBuilder7.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject12 = sketchLinearDimensionBuilder6.FirstAssociativity
    
    selectNXObject13 = sketchLinearDimensionBuilder6.SecondAssociativity
    
    point1_27 = NXOpen.Point3d(0.0, 4.8596240506002495, 0.0)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject12.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line2, NXOpen.View.Null, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    point1_28 = NXOpen.Point3d(0.0, 4.8644773711152718, 3.0955765088915363)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject13.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    originBuilder7 = sketchLinearDimensionBuilder6.Origin
    
    origin33 = NXOpen.Point3d(0.0, 4.8644773711152718, 1.5477882544457682)
    originBuilder7.OriginPoint = origin33
    
    originBuilder7.SetInferRelativeToGeometry(True)
    
    nXObject37 = sketchLinearDimensionBuilder6.Commit()
    
    perpendicularDimension2 = nXObject37
    perpendicularDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder6.Destroy()
    
    narrowDimensionPreferences7.Dispose()
    dimensionPreferences7.Dispose()
    sketchFindMovableObjectsBuilder19 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject38 = sketchFindMovableObjectsBuilder19.Commit()
    
    sketchFindMovableObjectsBuilder19.Destroy()
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder7 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension2)
    
    selectNXObjectList10 = sketchEditDimensionValueBuilder7.ExtraGeometries
    
    foundrelations27 = sketchEditDimensionValueBuilder7.FindRelations()
    
    sketchHelpedDimensionalConstraint6 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line2] [[Curve Arc1] ArcCenter]")
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId96, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId96, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId97, None)
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.DimValue = 3.0
    
    nXObject39 = sketchEditDimensionValueBuilder7.Commit()
    
    theSession.SetUndoMarkName(markId98, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId98, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId96, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId100, None)
    
    theSession.SetUndoMarkName(markId96, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId99, None)
    
    theSession.SetUndoMarkVisibility(markId96, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId98, None)
    
    theSession.DeleteUndoMark(markId96, None)
    
    sketchFindMovableObjectsBuilder20 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject40 = sketchFindMovableObjectsBuilder20.Commit()
    
    sketchFindMovableObjectsBuilder20.Destroy()
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder8 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects18 = [None] * 1 
    dragobjects18[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects18[0].Geometry = arc1
    dragobjects18[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects18[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects18)
    
    sketchDragGeometryBuilder8.SplineLinearScale = False
    
    foundrelations28 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects19 = [None] * 1 
    dragobjects19[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects19[0].Geometry = arc1
    dragobjects19[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects19[0].PointIndex = -1475378960
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects19)
    
    foundrelations29 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects20 = [None] * 1 
    dragobjects20[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects20[0].Geometry = arc1
    dragobjects20[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects20[0].PointIndex = -1475379040
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects20)
    
    foundrelations30 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects21 = [None] * 1 
    dragobjects21[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects21[0].Geometry = arc1
    dragobjects21[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects21[0].PointIndex = -1475379168
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects21)
    
    foundrelations31 = sketchDragGeometryBuilder8.FindRelations()
    
    sketchDragGeometryBuilder8.Destroy()
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences8 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences8 = dimensionPreferences8.GetNarrowDimensionPreferences()
    
    option8 = narrowDimensionPreferences8.DimensionDisplayOption
    
    sketchLinearDimensionBuilder7 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder8 = sketchLinearDimensionBuilder7.Driving
    
    drivingValueBuilder8.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder8 = sketchLinearDimensionBuilder7.Measurement
    
    dimensionMeasurementBuilder8.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject14 = sketchLinearDimensionBuilder7.FirstAssociativity
    
    selectNXObject15 = sketchLinearDimensionBuilder7.SecondAssociativity
    
    infiniteLine2 = theSession.ActiveSketch.FindObject("YAxis")
    point1_31 = NXOpen.Point3d(0.0, 0.0, 3.3976621349902416)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject14.SetValue(NXOpen.InferSnapType.SnapType.NotSet, infiniteLine2, NXOpen.View.Null, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    point1_32 = NXOpen.Point3d(0.0, 4.8644773711152718, 3.0)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject15.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    originBuilder8 = sketchLinearDimensionBuilder7.Origin
    
    origin35 = NXOpen.Point3d(0.0, 2.4322386855576359, 3.0)
    originBuilder8.OriginPoint = origin35
    
    originBuilder8.SetInferRelativeToGeometry(True)
    
    nXObject41 = sketchLinearDimensionBuilder7.Commit()
    
    perpendicularDimension3 = nXObject41
    perpendicularDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder7.Destroy()
    
    narrowDimensionPreferences8.Dispose()
    dimensionPreferences8.Dispose()
    sketchFindMovableObjectsBuilder21 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject42 = sketchFindMovableObjectsBuilder21.Commit()
    
    sketchFindMovableObjectsBuilder21.Destroy()
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder8 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension3)
    
    selectNXObjectList11 = sketchEditDimensionValueBuilder8.ExtraGeometries
    
    foundrelations32 = sketchEditDimensionValueBuilder8.FindRelations()
    
    sketchHelpedDimensionalConstraint7 = theSession.ActiveSketch.FindObject("PerpendicularDim [YAxis] [[Curve Arc1] ArcCenter]")
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId104, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId104, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId105, None)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder8.DimValue = 3.0
    
    nXObject43 = sketchEditDimensionValueBuilder8.Commit()
    
    theSession.SetUndoMarkName(markId106, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId106, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId104, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId108, None)
    
    theSession.SetUndoMarkName(markId104, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder8.Destroy()
    
    theSession.DeleteUndoMark(markId107, None)
    
    theSession.SetUndoMarkVisibility(markId104, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId106, None)
    
    theSession.DeleteUndoMark(markId104, None)
    
    sketchFindMovableObjectsBuilder22 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject44 = sketchFindMovableObjectsBuilder22.Commit()
    
    sketchFindMovableObjectsBuilder22.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder3 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder3.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject45 = sketchWorkRegionBuilder3.Commit()
    
    sketchWorkRegionBuilder3.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId110, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions3 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions3.SetSelectedFromInactive(False)
    
    curves3 = [NXOpen.ICurve.Null] * 1 
    curves3[0] = arc1
    seedPoint3 = NXOpen.Point3d(0.0, 2.8024474053307986, 2.9015629678481831)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch3, curves3, seedPoint3, 0.01, selectionIntentRuleOptions3)
    
    selectionIntentRuleOptions3.Dispose()
    section3.AllowSelfIntersection(True)
    
    section3.AllowDegenerateCurves(False)
    
    rules3 = [None] * 1 
    rules3[0] = regionBoundaryRule3
    helpPoint3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section3.AddToSection(rules3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId111, None)
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId113, None)
    
    direction9 = workPart.Directions.CreateDirection(sketch3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction9
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies14)
    
    theSession.DeleteUndoMark(markId112, None)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies15)
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId114, None)
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    feature6 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId115, None)
    
    theSession.SetUndoMarkName(markId110, "Extrude")
    
    expression14 = extrudeBuilder3.Limits.StartExtend.Value
    expression15 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression13)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin36, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane10
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression17 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder4 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId118, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder4.UseWorkPartOrigin = False
    
    coordinates7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point10 = workPart.Points.CreatePoint(coordinates7)
    
    origin37 = NXOpen.Point3d(3.647557165894006, 4.7475570705265744, 0.0)
    matrix7 = NXOpen.Matrix3x3()
    
    matrix7.Xx = 1.0
    matrix7.Xy = 0.0
    matrix7.Xz = 0.0
    matrix7.Yx = 0.0
    matrix7.Yy = 1.0
    matrix7.Yz = 0.0
    matrix7.Zx = 0.0
    matrix7.Zy = 0.0
    matrix7.Zz = 1.0
    plane11 = workPart.Planes.CreateFixedTypePlane(origin37, matrix7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point11 = workPart.Points.CreatePoint(coordinates8)
    
    origin38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction10 = workPart.Directions.CreateDirection(origin38, vector7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector8 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction11 = workPart.Directions.CreateDirection(origin39, vector8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix8 = NXOpen.Matrix3x3()
    
    matrix8.Xx = 1.0
    matrix8.Xy = 0.0
    matrix8.Xz = 0.0
    matrix8.Yx = 0.0
    matrix8.Yy = 1.0
    matrix8.Yz = 0.0
    matrix8.Zx = 0.0
    matrix8.Zy = 0.0
    matrix8.Zz = 1.0
    plane12 = workPart.Planes.CreateFixedTypePlane(origin40, matrix8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane12, direction11, point11, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder4.CoordinateSystem = cartesianCoordinateSystem4
    
    simpleSketchInPlaceBuilder4.HorizontalReference.Value = datumAxis1
    
    point12 = simpleSketchInPlaceBuilder4.SketchOrigin
    
    simpleSketchInPlaceBuilder4.SketchOrigin = point12
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId119, None)
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject46 = simpleSketchInPlaceBuilder4.Commit()
    
    sketch4 = nXObject46
    feature7 = sketch4.Feature
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId121)
    
    sketch4.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder23 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject47 = sketchFindMovableObjectsBuilder23.Commit()
    
    sketchFindMovableObjectsBuilder23.Destroy()
    
    theSession.DeleteUndoMark(markId120, None)
    
    theSession.SetUndoMarkName(markId118, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    simpleSketchInPlaceBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression17)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression16)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId117, None, True)
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_003")
    
    scaleAboutPoint152 = NXOpen.Point3d(-5.0389978742094135, 7.1959789786471715, 0.0)
    viewCenter152 = NXOpen.Point3d(5.0389978742087767, -7.195978978626294, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(-3.5671754735411501, 5.6987803296915196, 0.0)
    viewCenter153 = NXOpen.Point3d(3.567175473540507, -5.6987803296706394, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(-2.3201141291325671, 4.5590242637553029, 0.0)
    viewCenter154 = NXOpen.Point3d(2.3201141291319263, -4.5590242637344245, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint154, viewCenter154)
    
    scaleAboutPoint155 = NXOpen.Point3d(1.8375303902724189, 3.9813158456013742, 0.0)
    viewCenter155 = NXOpen.Point3d(-1.83753039027306, -3.9813158455804949, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint155, viewCenter155)
    
    scaleAboutPoint156 = NXOpen.Point3d(2.3201141291319236, 4.9766448069991078, 0.0)
    viewCenter156 = NXOpen.Point3d(-2.3201141291325689, -4.9766448069782276, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint156, viewCenter156)
    
    scaleAboutPoint157 = NXOpen.Point3d(2.9001426614149834, 6.2208060087462709, 0.0)
    viewCenter157 = NXOpen.Point3d(-2.9001426614156292, -6.2208060087253951, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint157, viewCenter157)
    
    scaleAboutPoint158 = NXOpen.Point3d(3.6251783267688098, 7.776007510930226, 0.0)
    viewCenter158 = NXOpen.Point3d(-3.6251783267694559, -7.776007510909352, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint158, viewCenter158)
    
    scaleAboutPoint159 = NXOpen.Point3d(4.5314729084610965, 9.8106388468294021, 0.0)
    viewCenter159 = NXOpen.Point3d(-4.5314729084617333, -9.8106388468085299, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint159, viewCenter159)
    
    scaleAboutPoint160 = NXOpen.Point3d(5.6643411355764473, 12.319941969889914, 0.0)
    viewCenter160 = NXOpen.Point3d(-5.6643411355770841, -12.31994196986903, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint160, viewCenter160)
    
    scaleAboutPoint161 = NXOpen.Point3d(7.7176647972230308, 16.037165840112173, 0.0)
    viewCenter161 = NXOpen.Point3d(-7.7176647972236712, -16.037165840091291, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint161, viewCenter161)
    
    scaleAboutPoint162 = NXOpen.Point3d(9.7355863267722444, 20.13496263038099, 0.0)
    viewCenter162 = NXOpen.Point3d(-9.7355863267728768, -20.134962630360111, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(12.16948290846538, 25.279334950777859, 0.0)
    viewCenter163 = NXOpen.Point3d(-12.169482908466021, -25.279334950756972, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint163, viewCenter163)
    
    scaleAboutPoint164 = NXOpen.Point3d(15.350143214087126, 31.737458266975004, 0.0)
    viewCenter164 = NXOpen.Point3d(-15.350143214087751, -31.737458266954111, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint164, viewCenter164)
    
    scaleAboutPoint165 = NXOpen.Point3d(19.879126910135447, 41.054718618769066, 0.0)
    viewCenter165 = NXOpen.Point3d(-19.879126910136037, -41.054718618748183, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint165, viewCenter165)
    
    scaleAboutPoint166 = NXOpen.Point3d(36.73316929046792, 72.710067448496105, 0.0)
    viewCenter166 = NXOpen.Point3d(-36.733169290468524, -72.710067448475215, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint166, viewCenter166)
    
    scaleAboutPoint167 = NXOpen.Point3d(29.55939740550588, 58.340915931930589, 0.0)
    viewCenter167 = NXOpen.Point3d(-29.559397405506527, -58.340915931909699, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint167, viewCenter167)
    
    scaleAboutPoint168 = NXOpen.Point3d(24.200676238425814, 46.672732745546554, 0.0)
    viewCenter168 = NXOpen.Point3d(-24.200676238426428, -46.672732745525657, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint168, viewCenter168)
    
    scaleAboutPoint169 = NXOpen.Point3d(20.024330967565998, 35.678711254375834, 0.0)
    viewCenter169 = NXOpen.Point3d(-20.024330967566602, -35.67871125435493, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint169, viewCenter169)
    
    scaleAboutPoint170 = NXOpen.Point3d(12.213735573587103, 25.710798435714366, 0.0)
    viewCenter170 = NXOpen.Point3d(-12.213735573587707, -25.710798435693469, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint170, viewCenter170)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint171 = NXOpen.Point3d(20.674845144854896, 5.4873304751004461, 0.0)
    viewCenter171 = NXOpen.Point3d(-20.6748451448555, -5.4873304750795517, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint171, viewCenter171)
    
    scaleAboutPoint172 = NXOpen.Point3d(15.63358153419157, 4.6730814368612803, 0.0)
    viewCenter172 = NXOpen.Point3d(-15.633581534192189, -4.6730814368403868, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint172, viewCenter172)
    
    scaleAboutPoint173 = NXOpen.Point3d(12.325606311014731, 3.7384651494911103, 0.0)
    viewCenter173 = NXOpen.Point3d(-12.325606311015349, -3.7384651494702226, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint173, viewCenter173)
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId124, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint9 = NXOpen.Point3d(0.80000000000000004, 22.0, 0.0)
    endPoint9 = NXOpen.Point3d(4.1999999999999993, 22.0, 0.0)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(4.1999999999999993, 22.0, 0.0)
    endPoint10 = NXOpen.Point3d(4.1999999999999993, 7.6999999999999993, 0.0)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(4.1999999999999993, 7.6999999999999993, 0.0)
    endPoint11 = NXOpen.Point3d(0.80000000000000004, 7.6999999999999993, 0.0)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(0.80000000000000004, 7.6999999999999993, 0.0)
    endPoint12 = NXOpen.Point3d(0.80000000000000004, 22.0, 0.0)
    line12 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line9
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line10
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line10
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line11
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line11
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line12
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line12
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line9
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line9
    geoms5[1] = line10
    geoms5[2] = line11
    geoms5[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line9
    geoms6[1] = line10
    geoms6[2] = line11
    geoms6[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms6)
    
    objects3 = [NXOpen.NXObject.Null] * 4 
    objects3[0] = sketchGeometricConstraint9
    objects3[1] = sketchGeometricConstraint10
    objects3[2] = sketchGeometricConstraint11
    objects3[3] = sketchGeometricConstraint12
    errorList3 = theSession.ActiveSketch.DeleteObjects(objects3)
    
    errorList3.Dispose()
    sketchFindMovableObjectsBuilder24 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject48 = sketchFindMovableObjectsBuilder24.Commit()
    
    sketchFindMovableObjectsBuilder24.Destroy()
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder9 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects22 = [None] * 1 
    dragobjects22[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects22[0].Geometry = line9
    dragobjects22[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects22[0].PointIndex = 0
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects22)
    
    sketchDragGeometryBuilder9.SplineLinearScale = False
    
    foundrelations33 = sketchDragGeometryBuilder9.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects23 = [None] * 1 
    dragobjects23[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects23[0].Geometry = line9
    dragobjects23[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects23[0].PointIndex = 0
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects23)
    
    foundrelations34 = sketchDragGeometryBuilder9.FindRelations()
    
    sketchDragGeometryBuilder9.Destroy()
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences9 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences9 = dimensionPreferences9.GetNarrowDimensionPreferences()
    
    option9 = narrowDimensionPreferences9.DimensionDisplayOption
    
    sketchLinearDimensionBuilder8 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder9 = sketchLinearDimensionBuilder8.Driving
    
    drivingValueBuilder9.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject16 = sketchLinearDimensionBuilder8.FirstAssociativity
    
    selectNXObject17 = sketchLinearDimensionBuilder8.SecondAssociativity
    
    point1_35 = NXOpen.Point3d(0.80000000000000004, 22.0, 0.0)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject16.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, NXOpen.View.Null, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    point1_36 = NXOpen.Point3d(4.1999999999999993, 22.0, 0.0)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject17.SetValue(NXOpen.InferSnapType.SnapType.End, line9, NXOpen.View.Null, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    dimensionMeasurementBuilder9 = sketchLinearDimensionBuilder8.Measurement
    
    dimensionMeasurementBuilder9.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder9 = sketchLinearDimensionBuilder8.Origin
    
    origin42 = NXOpen.Point3d(2.4999999999999996, 23.233131525326193, 0.0)
    originBuilder9.OriginPoint = origin42
    
    originBuilder9.SetInferRelativeToGeometry(True)
    
    nXObject49 = sketchLinearDimensionBuilder8.Commit()
    
    horizontalDimension3 = nXObject49
    horizontalDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder8.Destroy()
    
    narrowDimensionPreferences9.Dispose()
    dimensionPreferences9.Dispose()
    sketchFindMovableObjectsBuilder25 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject50 = sketchFindMovableObjectsBuilder25.Commit()
    
    sketchFindMovableObjectsBuilder25.Destroy()
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder9 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension3)
    
    selectNXObjectList12 = sketchEditDimensionValueBuilder9.ExtraGeometries
    
    foundrelations35 = sketchEditDimensionValueBuilder9.FindRelations()
    
    sketchHelpedDimensionalConstraint8 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line11] StartVertex] [[Curve Line11] EndVertex]")
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId128, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId128, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId129, None)
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder9.DimValue = 2.7999999999999998
    
    theSession.ActiveSketch.Scale(0.82352941176470584)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin43 = NXOpen.Point3d(2.0588235294117641, 19.133167138503921, 0.0)
    horizontalDimension3.AnnotationOrigin = origin43
    
    sketchEditDimensionValueBuilder9.RestoreOperation()
    
    sketchEditDimensionValueBuilder9.LoadExtraGeometry()
    
    selectNXObjectList13 = sketchEditDimensionValueBuilder9.ExtraGeometries
    
    foundrelations36 = sketchEditDimensionValueBuilder9.FindRelations()
    
    nXObject51 = sketchEditDimensionValueBuilder9.Commit()
    
    theSession.SetUndoMarkName(markId130, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId130, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId128, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId132, None)
    
    theSession.SetUndoMarkName(markId128, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder9.Destroy()
    
    theSession.DeleteUndoMark(markId131, None)
    
    theSession.SetUndoMarkVisibility(markId128, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId130, None)
    
    theSession.DeleteUndoMark(markId128, None)
    
    sketchFindMovableObjectsBuilder26 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject52 = sketchFindMovableObjectsBuilder26.Commit()
    
    sketchFindMovableObjectsBuilder26.Destroy()
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder10 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects24 = [None] * 1 
    dragobjects24[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects24[0].Geometry = line9
    dragobjects24[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects24[0].PointIndex = 0
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects24)
    
    sketchDragGeometryBuilder10.SplineLinearScale = False
    
    foundrelations37 = sketchDragGeometryBuilder10.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects25 = [None] * 1 
    dragobjects25[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects25[0].Geometry = line9
    dragobjects25[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects25[0].PointIndex = 0
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects25)
    
    foundrelations38 = sketchDragGeometryBuilder10.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects26 = [None] * 1 
    dragobjects26[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects26[0].Geometry = line9
    dragobjects26[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects26[0].PointIndex = 0
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects26)
    
    foundrelations39 = sketchDragGeometryBuilder10.FindRelations()
    
    sketchDragGeometryBuilder10.Destroy()
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences10 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences10 = dimensionPreferences10.GetNarrowDimensionPreferences()
    
    option10 = narrowDimensionPreferences10.DimensionDisplayOption
    
    sketchLinearDimensionBuilder9 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder10 = sketchLinearDimensionBuilder9.Driving
    
    drivingValueBuilder10.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder10 = sketchLinearDimensionBuilder9.Measurement
    
    dimensionMeasurementBuilder10.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject18 = sketchLinearDimensionBuilder9.FirstAssociativity
    
    selectNXObject19 = sketchLinearDimensionBuilder9.SecondAssociativity
    
    point1_39 = NXOpen.Point3d(2.0996942194931894, 18.117647058823529, 0.0)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject18.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, NXOpen.View.Null, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(5.7999999999999998, 0.0, 0.0)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject19.SetValue(NXOpen.InferSnapType.SnapType.End, line1, NXOpen.View.Null, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    originBuilder10 = sketchLinearDimensionBuilder9.Origin
    
    origin45 = NXOpen.Point3d(4.6010672649638895, 9.0588235294117645, 0.0)
    originBuilder10.OriginPoint = origin45
    
    originBuilder10.SetInferRelativeToGeometry(True)
    
    nXObject53 = sketchLinearDimensionBuilder9.Commit()
    
    perpendicularDimension4 = nXObject53
    perpendicularDimension4.IsOriginCentered = True
    
    sketchLinearDimensionBuilder9.Destroy()
    
    narrowDimensionPreferences10.Dispose()
    dimensionPreferences10.Dispose()
    sketchFindMovableObjectsBuilder27 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject54 = sketchFindMovableObjectsBuilder27.Commit()
    
    sketchFindMovableObjectsBuilder27.Destroy()
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder10 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension4)
    
    selectNXObjectList14 = sketchEditDimensionValueBuilder10.ExtraGeometries
    
    foundrelations40 = sketchEditDimensionValueBuilder10.FindRelations()
    
    sketchHelpedDimensionalConstraint9 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line11] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line1] EndVertex]")
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId136, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId136, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId137, None)
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder10.DimValue = 50.0
    
    nXObject55 = sketchEditDimensionValueBuilder10.Commit()
    
    theSession.SetUndoMarkName(markId138, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId138, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId136, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId140, None)
    
    theSession.SetUndoMarkName(markId136, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder10.Destroy()
    
    theSession.DeleteUndoMark(markId139, None)
    
    theSession.SetUndoMarkVisibility(markId136, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId138, None)
    
    theSession.DeleteUndoMark(markId136, None)
    
    sketchFindMovableObjectsBuilder28 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject56 = sketchFindMovableObjectsBuilder28.Commit()
    
    sketchFindMovableObjectsBuilder28.Destroy()
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder11 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects27 = [None] * 1 
    dragobjects27[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects27[0].Geometry = line11
    dragobjects27[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects27[0].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects27)
    
    sketchDragGeometryBuilder11.SplineLinearScale = False
    
    foundrelations41 = sketchDragGeometryBuilder11.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects28 = [None] * 1 
    dragobjects28[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects28[0].Geometry = line11
    dragobjects28[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects28[0].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects28)
    
    foundrelations42 = sketchDragGeometryBuilder11.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects29 = [None] * 1 
    dragobjects29[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects29[0].Geometry = line11
    dragobjects29[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects29[0].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects29)
    
    foundrelations43 = sketchDragGeometryBuilder11.FindRelations()
    
    sketchDragGeometryBuilder11.Destroy()
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences11 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences11 = dimensionPreferences11.GetNarrowDimensionPreferences()
    
    option11 = narrowDimensionPreferences11.DimensionDisplayOption
    
    sketchLinearDimensionBuilder10 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder11 = sketchLinearDimensionBuilder10.Driving
    
    drivingValueBuilder11.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder11 = sketchLinearDimensionBuilder10.Measurement
    
    dimensionMeasurementBuilder11.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject20 = sketchLinearDimensionBuilder10.FirstAssociativity
    
    selectNXObject21 = sketchLinearDimensionBuilder10.SecondAssociativity
    
    line14 = theSession.ActiveSketch.FindObject("Curve Included Curve15")
    point1_45 = NXOpen.Point3d(3.1872477175239271, 0.0, 0.0)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject20.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line14, NXOpen.View.Null, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    point1_46 = NXOpen.Point3d(3.458823529411764, 6.3411764705882341, 0.0)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject21.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, NXOpen.View.Null, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    originBuilder11 = sketchLinearDimensionBuilder10.Origin
    
    origin48 = NXOpen.Point3d(2.7159745350439435, 3.170588235294117, 0.0)
    originBuilder11.OriginPoint = origin48
    
    originBuilder11.SetInferRelativeToGeometry(True)
    
    nXObject57 = sketchLinearDimensionBuilder10.Commit()
    
    perpendicularDimension5 = nXObject57
    perpendicularDimension5.IsOriginCentered = True
    
    sketchLinearDimensionBuilder10.Destroy()
    
    narrowDimensionPreferences11.Dispose()
    dimensionPreferences11.Dispose()
    sketchFindMovableObjectsBuilder29 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject58 = sketchFindMovableObjectsBuilder29.Commit()
    
    sketchFindMovableObjectsBuilder29.Destroy()
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder11 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension5)
    
    selectNXObjectList15 = sketchEditDimensionValueBuilder11.ExtraGeometries
    
    foundrelations44 = sketchEditDimensionValueBuilder11.FindRelations()
    
    sketchHelpedDimensionalConstraint10 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line1] [[Curve Line13] StartVertex]")
    sketchHelpedDimensionalConstraint10.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId144, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId144, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint10.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId145, None)
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder11.DimValue = 8.0
    
    nXObject59 = sketchEditDimensionValueBuilder11.Commit()
    
    theSession.SetUndoMarkName(markId146, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId146, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId144, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint10.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId148, None)
    
    theSession.SetUndoMarkName(markId144, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder11.Destroy()
    
    theSession.DeleteUndoMark(markId147, None)
    
    theSession.SetUndoMarkVisibility(markId144, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId146, None)
    
    theSession.DeleteUndoMark(markId144, None)
    
    sketchFindMovableObjectsBuilder30 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject60 = sketchFindMovableObjectsBuilder30.Commit()
    
    sketchFindMovableObjectsBuilder30.Destroy()
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder12 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects30 = [None] * 1 
    dragobjects30[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects30[0].Geometry = line12
    dragobjects30[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects30[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects30)
    
    sketchDragGeometryBuilder12.SplineLinearScale = False
    
    foundrelations45 = sketchDragGeometryBuilder12.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects31 = [None] * 1 
    dragobjects31[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects31[0].Geometry = line12
    dragobjects31[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects31[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects31)
    
    foundrelations46 = sketchDragGeometryBuilder12.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects32 = [None] * 1 
    dragobjects32[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects32[0].Geometry = line12
    dragobjects32[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects32[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects32)
    
    foundrelations47 = sketchDragGeometryBuilder12.FindRelations()
    
    sketchDragGeometryBuilder12.Destroy()
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences12 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences12 = dimensionPreferences12.GetNarrowDimensionPreferences()
    
    option12 = narrowDimensionPreferences12.DimensionDisplayOption
    
    sketchLinearDimensionBuilder11 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder12 = sketchLinearDimensionBuilder11.Driving
    
    drivingValueBuilder12.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder12 = sketchLinearDimensionBuilder11.Measurement
    
    dimensionMeasurementBuilder12.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject22 = sketchLinearDimensionBuilder11.FirstAssociativity
    
    selectNXObject23 = sketchLinearDimensionBuilder11.SecondAssociativity
    
    infiniteLine4 = theSession.ActiveSketch.FindObject("YAxis")
    point1_51 = NXOpen.Point3d(0.0, 12.432959501864389, 0.0)
    point2_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject22.SetValue(NXOpen.InferSnapType.SnapType.NotSet, infiniteLine4, NXOpen.View.Null, point1_51, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_51)
    
    point1_52 = NXOpen.Point3d(0.65882352941176492, 8.0, 0.0)
    point2_52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject23.SetValue(NXOpen.InferSnapType.SnapType.Start, line12, NXOpen.View.Null, point1_52, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_52)
    
    originBuilder12 = sketchLinearDimensionBuilder11.Origin
    
    origin51 = NXOpen.Point3d(0.32941176470588207, 12.251700585519382, 0.0)
    originBuilder12.OriginPoint = origin51
    
    originBuilder12.SetInferRelativeToGeometry(True)
    
    nXObject61 = sketchLinearDimensionBuilder11.Commit()
    
    perpendicularDimension6 = nXObject61
    perpendicularDimension6.IsOriginCentered = True
    
    sketchLinearDimensionBuilder11.Destroy()
    
    narrowDimensionPreferences12.Dispose()
    dimensionPreferences12.Dispose()
    sketchFindMovableObjectsBuilder31 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject62 = sketchFindMovableObjectsBuilder31.Commit()
    
    sketchFindMovableObjectsBuilder31.Destroy()
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder12 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension6)
    
    selectNXObjectList16 = sketchEditDimensionValueBuilder12.ExtraGeometries
    
    foundrelations48 = sketchEditDimensionValueBuilder12.FindRelations()
    
    sketchHelpedDimensionalConstraint11 = theSession.ActiveSketch.FindObject("PerpendicularDim [YAxis] [[Curve Line14] StartVertex]")
    sketchHelpedDimensionalConstraint11.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId152, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId152, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint11.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId153, None)
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder12.DimValue = 1.5
    
    nXObject63 = sketchEditDimensionValueBuilder12.Commit()
    
    theSession.SetUndoMarkName(markId154, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId154, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId152, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint11.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId156, None)
    
    theSession.SetUndoMarkName(markId152, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder12.Destroy()
    
    theSession.DeleteUndoMark(markId155, None)
    
    theSession.SetUndoMarkVisibility(markId152, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId154, None)
    
    theSession.DeleteUndoMark(markId152, None)
    
    sketchFindMovableObjectsBuilder32 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject64 = sketchFindMovableObjectsBuilder32.Commit()
    
    sketchFindMovableObjectsBuilder32.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder4 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder4.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject65 = sketchWorkRegionBuilder4.Commit()
    
    sketchWorkRegionBuilder4.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression18 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId158, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions4 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions4.SetSelectedFromInactive(False)
    
    curves4 = [NXOpen.ICurve.Null] * 4 
    curves4[0] = line9
    curves4[1] = line10
    curves4[2] = line11
    curves4[3] = line12
    seedPoint4 = NXOpen.Point3d(3.1060043999999976, 32.090066, 0.0)
    regionBoundaryRule4 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch4, curves4, seedPoint4, 0.01, selectionIntentRuleOptions4)
    
    selectionIntentRuleOptions4.Dispose()
    section4.AllowSelfIntersection(True)
    
    section4.AllowDegenerateCurves(False)
    
    rules4 = [None] * 1 
    rules4[0] = regionBoundaryRule4
    helpPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section4.AddToSection(rules4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId159, None)
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId161, None)
    
    direction12 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction12
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies18)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies19)
    
    theSession.DeleteUndoMark(markId160, None)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies20)
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId162, None)
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    feature8 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId163, None)
    
    theSession.SetUndoMarkName(markId158, "Extrude")
    
    expression19 = extrudeBuilder4.Limits.StartExtend.Value
    expression20 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression18)
    
    scaleAboutPoint174 = NXOpen.Point3d(2.2113587793288549, 1.7582114884934692, 0.0)
    viewCenter174 = NXOpen.Point3d(-2.2113587793294913, -1.7582114884725926, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint174, viewCenter174)
    
    scaleAboutPoint175 = NXOpen.Point3d(1.9430955831479331, 1.4645720440251715, 0.0)
    viewCenter175 = NXOpen.Point3d(-1.9430955831485786, -1.4645720440042911, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint175, viewCenter175)
    
    scaleAboutPoint176 = NXOpen.Point3d(1.6704821729748971, 1.1716576352222243, 0.0)
    viewCenter176 = NXOpen.Point3d(-1.6704821729755419, -1.1716576352013459, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint176, viewCenter176)
    
    scaleAboutPoint177 = NXOpen.Point3d(1.3735075644459649, 0.93732610817986695, 0.0)
    viewCenter177 = NXOpen.Point3d(-1.3735075644466106, -0.93732610815898765, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint177, viewCenter177)
    
    scaleAboutPoint178 = NXOpen.Point3d(1.0691085907038176, 1.1359278776335879, 0.0)
    viewCenter178 = NXOpen.Point3d(-1.0691085907044608, -1.1359278776127077, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint178, viewCenter178)
    
    scaleAboutPoint179 = NXOpen.Point3d(1.3363857383798512, 1.4199098470393736, 0.0)
    viewCenter179 = NXOpen.Point3d(-1.3363857383804967, -1.4199098470184943, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint179, viewCenter179)
    
    scaleAboutPoint180 = NXOpen.Point3d(1.6704821729748971, 1.7748873087966097, 0.0)
    viewCenter180 = NXOpen.Point3d(-1.6704821729755419, -1.7748873087757293, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint180, viewCenter180)
    
    scaleAboutPoint181 = NXOpen.Point3d(2.0881027162187005, 2.2186091359931508, 0.0)
    viewCenter181 = NXOpen.Point3d(-2.0881027162193457, -2.2186091359722706, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint181, viewCenter181)
    
    scaleAboutPoint182 = NXOpen.Point3d(2.6101283952734553, 2.7732614199888292, 0.0)
    viewCenter182 = NXOpen.Point3d(-2.6101283952741015, -2.7732614199679464, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint182, viewCenter182)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin52, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane13
    
    expression21 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder5 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId166, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder5.UseWorkPartOrigin = False
    
    scaleAboutPoint183 = NXOpen.Point3d(9.2895194623455861, 11.849801655637048, 0.0)
    viewCenter183 = NXOpen.Point3d(-9.2895194623462238, -11.849801655616167, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint183, viewCenter183)
    
    scaleAboutPoint184 = NXOpen.Point3d(11.781829561999375, 14.812252069543703, 0.0)
    viewCenter184 = NXOpen.Point3d(-11.781829562000002, -14.812252069522819, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint184, viewCenter184)
    
    scaleAboutPoint185 = NXOpen.Point3d(14.79809121669401, 18.515315086927021, 0.0)
    viewCenter185 = NXOpen.Point3d(-14.798091216694624, -18.515315086906138, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint185, viewCenter185)
    
    scaleAboutPoint186 = NXOpen.Point3d(18.851635341841128, 23.232649188899547, 0.0)
    viewCenter186 = NXOpen.Point3d(-18.85163534184176, -23.232649188878661, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint186, viewCenter186)
    
    coordinates9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point13 = workPart.Points.CreatePoint(coordinates9)
    
    origin53 = NXOpen.Point3d(0.0, 26.975160470250334, 4.9751604702503327)
    matrix9 = NXOpen.Matrix3x3()
    
    matrix9.Xx = 0.0
    matrix9.Xy = 1.0
    matrix9.Xz = 0.0
    matrix9.Yx = 0.0
    matrix9.Yy = 0.0
    matrix9.Yz = 1.0
    matrix9.Zx = 1.0
    matrix9.Zy = 0.0
    matrix9.Zz = 0.0
    plane14 = workPart.Planes.CreateFixedTypePlane(origin53, matrix9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point14 = workPart.Points.CreatePoint(coordinates10)
    
    origin54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector9 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction13 = workPart.Directions.CreateDirection(origin54, vector9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector10 = NXOpen.Vector3d(0.0, 1.0, 0.0)
    direction14 = workPart.Directions.CreateDirection(origin55, vector10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix10 = NXOpen.Matrix3x3()
    
    matrix10.Xx = 0.0
    matrix10.Xy = 1.0
    matrix10.Xz = 0.0
    matrix10.Yx = 0.0
    matrix10.Yy = 0.0
    matrix10.Yz = 1.0
    matrix10.Zx = 1.0
    matrix10.Zy = 0.0
    matrix10.Zz = 0.0
    plane15 = workPart.Planes.CreateFixedTypePlane(origin56, matrix10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane15, direction14, point14, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder5.CoordinateSystem = cartesianCoordinateSystem5
    
    simpleSketchInPlaceBuilder5.HorizontalReference.Value = datumAxis2
    
    point15 = simpleSketchInPlaceBuilder5.SketchOrigin
    
    simpleSketchInPlaceBuilder5.SketchOrigin = point15
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId167, None)
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject66 = simpleSketchInPlaceBuilder5.Commit()
    
    sketch5 = nXObject66
    feature9 = sketch5.Feature
    
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId169)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder33 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject67 = sketchFindMovableObjectsBuilder33.Commit()
    
    sketchFindMovableObjectsBuilder33.Destroy()
    
    theSession.DeleteUndoMark(markId168, None)
    
    theSession.SetUndoMarkName(markId166, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    simpleSketchInPlaceBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression22)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression21)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId165, None, True)
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_004")
    
    scaleAboutPoint187 = NXOpen.Point3d(55.094568076508139, 2.2679490874972386, 0.0)
    viewCenter187 = NXOpen.Point3d(-55.094568076508757, -2.2679490874763539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint187, viewCenter187)
    
    scaleAboutPoint188 = NXOpen.Point3d(69.006499674140514, 2.8349363593689421, 0.0)
    viewCenter188 = NXOpen.Point3d(-69.006499674141125, -2.8349363593480477, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint188, viewCenter188)
    
    scaleAboutPoint189 = NXOpen.Point3d(86.258124592675742, 3.5436704492085545, 0.0)
    viewCenter189 = NXOpen.Point3d(-86.258124592676339, -3.5436704491876694, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint189, viewCenter189)
    
    scaleAboutPoint190 = NXOpen.Point3d(69.006499674140528, 2.8349363593689425, 0.0)
    viewCenter190 = NXOpen.Point3d(-69.006499674141139, -2.8349363593480366, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint190, viewCenter190)
    
    scaleAboutPoint191 = NXOpen.Point3d(55.205199739312334, 2.2679490874972479, 0.0)
    viewCenter191 = NXOpen.Point3d(-55.205199739312938, -2.2679490874763442, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint191, viewCenter191)
    
    scaleAboutPoint192 = NXOpen.Point3d(44.164159791449805, 1.8143592699998883, 0.0)
    viewCenter192 = NXOpen.Point3d(-44.164159791450409, -1.8143592699789848, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint192, viewCenter192)
    
    scaleAboutPoint193 = NXOpen.Point3d(35.331327833159797, 1.4514874160020057, 0.0)
    viewCenter193 = NXOpen.Point3d(-35.331327833160401, -1.4514874159810931, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint193, viewCenter193)
    
    scaleAboutPoint194 = NXOpen.Point3d(28.265062266527782, 1.1611899328036959, 0.0)
    viewCenter194 = NXOpen.Point3d(-28.265062266528393, -1.1611899327827833, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint194, viewCenter194)
    
    scaleAboutPoint195 = NXOpen.Point3d(20.165054442652995, 0.88363721716043142, 0.0)
    viewCenter195 = NXOpen.Point3d(-20.165054442653606, -0.8836372171395207, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint195, viewCenter195)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId172, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(0.0, 44.0, 2.7000000000000002)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 1.7114997503957621, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder34 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject68 = sketchFindMovableObjectsBuilder34.Commit()
    
    sketchFindMovableObjectsBuilder34.Destroy()
    
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder13 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects33 = [None] * 1 
    dragobjects33[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects33[0].Geometry = arc2
    dragobjects33[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects33[0].PointIndex = 0
    sketchDragGeometryBuilder13.SetDragGeometry(dragobjects33)
    
    sketchDragGeometryBuilder13.SplineLinearScale = False
    
    foundrelations49 = sketchDragGeometryBuilder13.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects34 = [None] * 1 
    dragobjects34[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects34[0].Geometry = arc2
    dragobjects34[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects34[0].PointIndex = 0
    sketchDragGeometryBuilder13.SetDragGeometry(dragobjects34)
    
    foundrelations50 = sketchDragGeometryBuilder13.FindRelations()
    
    sketchDragGeometryBuilder13.Destroy()
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences13 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences13 = dimensionPreferences13.GetNarrowDimensionPreferences()
    
    option13 = narrowDimensionPreferences13.DimensionDisplayOption
    
    sketchRadialDimensionBuilder2 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder13 = sketchRadialDimensionBuilder2.Driving
    
    drivingValueBuilder13.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject24 = sketchRadialDimensionBuilder2.FirstAssociativity
    
    point1_54 = NXOpen.Point3d(0.0, 44.0, 2.7000000000000002)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject24.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, NXOpen.View.Null, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    dimensionMeasurementBuilder13 = sketchRadialDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder13.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder13 = sketchRadialDimensionBuilder2.Origin
    
    origin58 = NXOpen.Point3d(0.0, 47.153303145667152, 4.2587523264162224)
    originBuilder13.OriginPoint = origin58
    
    originBuilder13.SetInferRelativeToGeometry(True)
    
    nXObject69 = sketchRadialDimensionBuilder2.Commit()
    
    sketchRadialDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences13.Dispose()
    dimensionPreferences13.Dispose()
    sketchFindMovableObjectsBuilder35 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject70 = sketchFindMovableObjectsBuilder35.Commit()
    
    sketchFindMovableObjectsBuilder35.Destroy()
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension2 = nXObject69
    sketchEditDimensionValueBuilder13 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension2)
    
    selectNXObjectList17 = sketchEditDimensionValueBuilder13.ExtraGeometries
    
    foundrelations51 = sketchEditDimensionValueBuilder13.FindRelations()
    
    sketchDimensionalConstraint2 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc2]")
    sketchDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId176, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId176, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId177, None)
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder13.DimValue = 3.0
    
    theSession.ActiveSketch.Scale(0.87642431712270497)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin59 = NXOpen.Point3d(0.0, 41.326301509521222, 3.7324740994740688)
    diameterDimension2.AnnotationOrigin = origin59
    
    sketchEditDimensionValueBuilder13.RestoreOperation()
    
    sketchEditDimensionValueBuilder13.LoadExtraGeometry()
    
    selectNXObjectList18 = sketchEditDimensionValueBuilder13.ExtraGeometries
    
    foundrelations52 = sketchEditDimensionValueBuilder13.FindRelations()
    
    nXObject71 = sketchEditDimensionValueBuilder13.Commit()
    
    theSession.SetUndoMarkName(markId178, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId178, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId176, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId180, None)
    
    theSession.SetUndoMarkName(markId176, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder13.Destroy()
    
    theSession.DeleteUndoMark(markId179, None)
    
    theSession.SetUndoMarkVisibility(markId176, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId178, None)
    
    theSession.DeleteUndoMark(markId176, None)
    
    sketchFindMovableObjectsBuilder36 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject72 = sketchFindMovableObjectsBuilder36.Commit()
    
    sketchFindMovableObjectsBuilder36.Destroy()
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder14 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects35 = [None] * 1 
    dragobjects35[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects35[0].Geometry = arc2
    dragobjects35[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects35[0].PointIndex = 0
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects35)
    
    sketchDragGeometryBuilder14.SplineLinearScale = False
    
    foundrelations53 = sketchDragGeometryBuilder14.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects36 = [None] * 1 
    dragobjects36[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects36[0].Geometry = arc2
    dragobjects36[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects36[0].PointIndex = -1475379104
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects36)
    
    foundrelations54 = sketchDragGeometryBuilder14.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects37 = [None] * 1 
    dragobjects37[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects37[0].Geometry = arc2
    dragobjects37[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects37[0].PointIndex = -1475379040
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects37)
    
    foundrelations55 = sketchDragGeometryBuilder14.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects38 = [None] * 1 
    dragobjects38[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects38[0].Geometry = arc2
    dragobjects38[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects38[0].PointIndex = -1475378416
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects38)
    
    foundrelations56 = sketchDragGeometryBuilder14.FindRelations()
    
    sketchDragGeometryBuilder14.Destroy()
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences14 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences14 = dimensionPreferences14.GetNarrowDimensionPreferences()
    
    option14 = narrowDimensionPreferences14.DimensionDisplayOption
    
    sketchLinearDimensionBuilder12 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder14 = sketchLinearDimensionBuilder12.Driving
    
    drivingValueBuilder14.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder14 = sketchLinearDimensionBuilder12.Measurement
    
    dimensionMeasurementBuilder14.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject25 = sketchLinearDimensionBuilder12.FirstAssociativity
    
    selectNXObject26 = sketchLinearDimensionBuilder12.SecondAssociativity
    
    point1_57 = NXOpen.Point3d(0.0, 40.025234574216967, 0.0)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject25.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line10, NXOpen.View.Null, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    point1_58 = NXOpen.Point3d(0.0, 38.562669953399016, 2.3663456562313034)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject26.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, NXOpen.View.Null, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    originBuilder14 = sketchLinearDimensionBuilder12.Origin
    
    origin61 = NXOpen.Point3d(0.0, 38.562669953399016, 1.1831728281156517)
    originBuilder14.OriginPoint = origin61
    
    originBuilder14.SetInferRelativeToGeometry(True)
    
    nXObject73 = sketchLinearDimensionBuilder12.Commit()
    
    perpendicularDimension7 = nXObject73
    perpendicularDimension7.IsOriginCentered = True
    
    sketchLinearDimensionBuilder12.Destroy()
    
    narrowDimensionPreferences14.Dispose()
    dimensionPreferences14.Dispose()
    sketchFindMovableObjectsBuilder37 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject74 = sketchFindMovableObjectsBuilder37.Commit()
    
    sketchFindMovableObjectsBuilder37.Destroy()
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder14 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension7)
    
    selectNXObjectList19 = sketchEditDimensionValueBuilder14.ExtraGeometries
    
    foundrelations57 = sketchEditDimensionValueBuilder14.FindRelations()
    
    sketchHelpedDimensionalConstraint12 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|SKETCH(7)|SKETCH_003|Curve Line12] [[Curve Arc2] ArcCenter]")
    sketchHelpedDimensionalConstraint12.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId184, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId184, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint12.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId185, None)
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder14.DimValue = 3.0
    
    nXObject75 = sketchEditDimensionValueBuilder14.Commit()
    
    theSession.SetUndoMarkName(markId186, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId186, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId184, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint12.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId188, None)
    
    theSession.SetUndoMarkName(markId184, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder14.Destroy()
    
    theSession.DeleteUndoMark(markId187, None)
    
    theSession.SetUndoMarkVisibility(markId184, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId186, None)
    
    theSession.DeleteUndoMark(markId184, None)
    
    sketchFindMovableObjectsBuilder38 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject76 = sketchFindMovableObjectsBuilder38.Commit()
    
    sketchFindMovableObjectsBuilder38.Destroy()
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder15 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects39 = [None] * 1 
    dragobjects39[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects39[0].Geometry = arc2
    dragobjects39[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects39[0].PointIndex = 0
    sketchDragGeometryBuilder15.SetDragGeometry(dragobjects39)
    
    sketchDragGeometryBuilder15.SplineLinearScale = False
    
    foundrelations58 = sketchDragGeometryBuilder15.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects40 = [None] * 1 
    dragobjects40[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects40[0].Geometry = arc2
    dragobjects40[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects40[0].PointIndex = -1475378960
    sketchDragGeometryBuilder15.SetDragGeometry(dragobjects40)
    
    foundrelations59 = sketchDragGeometryBuilder15.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    scaleAboutPoint196 = NXOpen.Point3d(-19.829725447427457, 0.16313302471506785, 0.0)
    viewCenter196 = NXOpen.Point3d(19.829725447426849, -0.16313302469415714, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint196, viewCenter196)
    
    scaleAboutPoint197 = NXOpen.Point3d(-15.921783211170336, 0.072503566545836035, 0.0)
    viewCenter197 = NXOpen.Point3d(15.921783211169723, -0.072503566524928426, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint197, viewCenter197)
    
    scaleAboutPoint198 = NXOpen.Point3d(-12.760627710227652, 0.011600570656115611, 0.0)
    viewCenter198 = NXOpen.Point3d(12.760627710227045, -0.011600570635207504, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint198, viewCenter198)
    
    scaleAboutPoint199 = NXOpen.Point3d(-10.2456239942483, -0.046402282572189209, 0.0)
    viewCenter199 = NXOpen.Point3d(10.245623994247689, 0.046402282593098504, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint199, viewCenter199)
    
    scaleAboutPoint200 = NXOpen.Point3d(-8.2113479258251481, -0.037121826055661063, 0.0)
    viewCenter200 = NXOpen.Point3d(8.2113479258245352, 0.037121826076569088, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint200, viewCenter200)
    
    scaleAboutPoint201 = NXOpen.Point3d(-6.7947790431421655, 0.17224527295723194, 0.0)
    viewCenter201 = NXOpen.Point3d(6.7947790431415518, -0.17224527293632444, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint201, viewCenter201)
    
    scaleAboutPoint202 = NXOpen.Point3d(-8.5677174560598619, 0.21530659119392678, 0.0)
    viewCenter202 = NXOpen.Point3d(8.5677174560592491, -0.21530659117301876, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint202, viewCenter202)
    
    scaleAboutPoint203 = NXOpen.Point3d(-10.783890472206981, 0.30625506505591094, 0.0)
    viewCenter203 = NXOpen.Point3d(10.783890472206368, -0.30625506503500322, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint203, viewCenter203)
    
    scaleAboutPoint204 = NXOpen.Point3d(-13.68867336188055, 0.54522682035653125, 0.0)
    viewCenter204 = NXOpen.Point3d(13.688673361879937, -0.54522682033562508, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint204, viewCenter204)
    
    scaleAboutPoint205 = NXOpen.Point3d(-17.400855968492134, 1.0295506448128866, 0.0)
    viewCenter205 = NXOpen.Point3d(17.400855968491523, -1.0295506447919791, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint205, viewCenter205)
    
    scaleAboutPoint206 = NXOpen.Point3d(-22.113587793292009, 1.721959705225792, 0.0)
    viewCenter206 = NXOpen.Point3d(22.113587793291391, -1.7219597052048814, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint206, viewCenter206)
    
    scaleAboutPoint207 = NXOpen.Point3d(-28.321705677884147, 3.1946884004757519, 0.0)
    viewCenter207 = NXOpen.Point3d(28.321705677883529, -3.1946884004548415, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint207, viewCenter207)
    
    scaleAboutPoint208 = NXOpen.Point3d(-35.402132097355107, 3.9933605005920771, 0.0)
    viewCenter208 = NXOpen.Point3d(35.402132097354489, -3.9933605005711645, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint208, viewCenter208)
    
    scaleAboutPoint209 = NXOpen.Point3d(-44.252665121693802, 4.9917006257374812, 0.0)
    viewCenter209 = NXOpen.Point3d(44.252665121693184, -4.991700625716569, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint209, viewCenter209)
    
    scaleAboutPoint210 = NXOpen.Point3d(-55.404336732360562, 6.3281311124126312, 0.0)
    viewCenter210 = NXOpen.Point3d(55.404336732359944, -6.3281311123917128, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint210, viewCenter210)
    
    scaleAboutPoint211 = NXOpen.Point3d(-69.36605257825488, 8.0207955533174093, 0.0)
    viewCenter211 = NXOpen.Point3d(69.366052578254241, -8.0207955532964874, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint211, viewCenter211)
    
    scaleAboutPoint212 = NXOpen.Point3d(-86.845855301323795, 10.30257359865473, 0.0)
    viewCenter212 = NXOpen.Point3d(86.845855301323184, -10.302573598633812, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint212, viewCenter212)
    
    scaleAboutPoint213 = NXOpen.Point3d(-120.83051921899934, 12.878216998315802, 0.0)
    viewCenter213 = NXOpen.Point3d(120.83051921899869, -12.878216998294871, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint213, viewCenter213)
    
    scaleAboutPoint214 = NXOpen.Point3d(-96.664415375199539, 10.302573598654739, 0.0)
    viewCenter214 = NXOpen.Point3d(96.664415375198899, -10.30257359863381, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint214, viewCenter214)
    
    scaleAboutPoint215 = NXOpen.Point3d(-77.331532300159694, 8.2420588789258851, 0.0)
    viewCenter215 = NXOpen.Point3d(77.331532300159054, -8.2420588789049543, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint215, viewCenter215)
    
    dragobjects41 = [None] * 1 
    dragobjects41[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects41[0].Geometry = arc2
    dragobjects41[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects41[0].PointIndex = -1475379040
    sketchDragGeometryBuilder15.SetDragGeometry(dragobjects41)
    
    foundrelations60 = sketchDragGeometryBuilder15.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects42 = [None] * 1 
    dragobjects42[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects42[0].Geometry = arc2
    dragobjects42[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects42[0].PointIndex = -1475379168
    sketchDragGeometryBuilder15.SetDragGeometry(dragobjects42)
    
    foundrelations61 = sketchDragGeometryBuilder15.FindRelations()
    
    sketchDragGeometryBuilder15.Destroy()
    
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences15 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences15 = dimensionPreferences15.GetNarrowDimensionPreferences()
    
    option15 = narrowDimensionPreferences15.DimensionDisplayOption
    
    sketchLinearDimensionBuilder13 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder15 = sketchLinearDimensionBuilder13.Driving
    
    drivingValueBuilder15.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder15 = sketchLinearDimensionBuilder13.Measurement
    
    dimensionMeasurementBuilder15.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject27 = sketchLinearDimensionBuilder13.FirstAssociativity
    
    selectNXObject28 = sketchLinearDimensionBuilder13.SecondAssociativity
    
    infiniteLine6 = theSession.ActiveSketch.FindObject("YAxis")
    point1_61 = NXOpen.Point3d(0.0, 0.0, 6.2568583165775635)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject27.SetValue(NXOpen.InferSnapType.SnapType.NotSet, infiniteLine6, NXOpen.View.Null, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    point1_62 = NXOpen.Point3d(0.0, 38.562669953399023, 3.0)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject28.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, NXOpen.View.Null, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    originBuilder15 = sketchLinearDimensionBuilder13.Origin
    
    origin63 = NXOpen.Point3d(0.0, 19.281334976699512, 3.0)
    originBuilder15.OriginPoint = origin63
    
    originBuilder15.SetInferRelativeToGeometry(True)
    
    nXObject77 = sketchLinearDimensionBuilder13.Commit()
    
    perpendicularDimension8 = nXObject77
    perpendicularDimension8.IsOriginCentered = True
    
    sketchLinearDimensionBuilder13.Destroy()
    
    narrowDimensionPreferences15.Dispose()
    dimensionPreferences15.Dispose()
    sketchFindMovableObjectsBuilder39 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject78 = sketchFindMovableObjectsBuilder39.Commit()
    
    sketchFindMovableObjectsBuilder39.Destroy()
    
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder15 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension8)
    
    selectNXObjectList20 = sketchEditDimensionValueBuilder15.ExtraGeometries
    
    foundrelations62 = sketchEditDimensionValueBuilder15.FindRelations()
    
    sketchHelpedDimensionalConstraint13 = theSession.ActiveSketch.FindObject("PerpendicularDim [YAxis] [[Curve Arc2] ArcCenter]")
    sketchHelpedDimensionalConstraint13.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId192, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId192, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint13.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId193, None)
    
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder15.DimValue = 47.0
    
    nXObject79 = sketchEditDimensionValueBuilder15.Commit()
    
    theSession.SetUndoMarkName(markId194, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId194, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId192, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint13.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId196, None)
    
    theSession.SetUndoMarkName(markId192, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder15.Destroy()
    
    theSession.DeleteUndoMark(markId195, None)
    
    theSession.SetUndoMarkVisibility(markId192, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId194, None)
    
    theSession.DeleteUndoMark(markId192, None)
    
    sketchFindMovableObjectsBuilder40 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject80 = sketchFindMovableObjectsBuilder40.Commit()
    
    sketchFindMovableObjectsBuilder40.Destroy()
    
    sketchWorkRegionBuilder5 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder5.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject81 = sketchWorkRegionBuilder5.Commit()
    
    sketchWorkRegionBuilder5.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies22)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId198, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions5 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions5.SetSelectedFromInactive(False)
    
    curves5 = [NXOpen.ICurve.Null] * 1 
    curves5[0] = arc2
    seedPoint5 = NXOpen.Point3d(0.0, 46.802447405328024, 2.9015629678468047)
    regionBoundaryRule5 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch5, curves5, seedPoint5, 0.01, selectionIntentRuleOptions5)
    
    selectionIntentRuleOptions5.Dispose()
    section5.AllowSelfIntersection(True)
    
    section5.AllowDegenerateCurves(False)
    
    rules5 = [None] * 1 
    rules5[0] = regionBoundaryRule5
    helpPoint5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section5.AddToSection(rules5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId199, None)
    
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId201, None)
    
    direction15 = workPart.Directions.CreateDirection(sketch5, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction15
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies24)
    
    theSession.DeleteUndoMark(markId200, None)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies25)
    
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId202, None)
    
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    feature10 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId203, None)
    
    theSession.SetUndoMarkName(markId198, "Extrude")
    
    expression24 = extrudeBuilder5.Limits.StartExtend.Value
    expression25 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression23)
    
    scaleAboutPoint216 = NXOpen.Point3d(55.868989716137769, 33.908604649508106, 0.0)
    viewCenter216 = NXOpen.Point3d(-55.868989716138387, -33.908604649487224, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint216, viewCenter216)
    
    scaleAboutPoint217 = NXOpen.Point3d(43.367611819259324, 27.392399710338729, 0.0)
    viewCenter217 = NXOpen.Point3d(-43.367611819259956, -27.392399710317843, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint217, viewCenter217)
    
    scaleAboutPoint218 = NXOpen.Point3d(53.545724797248809, 34.240499637920792, 0.0)
    viewCenter218 = NXOpen.Point3d(-53.545724797249449, -34.240499637899909, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint218, viewCenter218)
    
    scaleAboutPoint219 = NXOpen.Point3d(66.517287261045226, 42.800624547398378, 0.0)
    viewCenter219 = NXOpen.Point3d(-66.517287261045837, -42.800624547377488, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint219, viewCenter219)
    
    scaleAboutPoint220 = NXOpen.Point3d(81.763713291253652, 53.846504630508583, 0.0)
    viewCenter220 = NXOpen.Point3d(-81.763713291254305, -53.846504630487708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint220, viewCenter220)
    
    scaleAboutPoint221 = NXOpen.Point3d(100.04386694992199, 68.388518120205717, 0.0)
    viewCenter221 = NXOpen.Point3d(-100.04386694992262, -68.388518120184813, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint221, viewCenter221)
    
    scaleAboutPoint222 = NXOpen.Point3d(80.035093559937494, 54.710814496166641, 0.0)
    viewCenter222 = NXOpen.Point3d(-80.035093559938147, -54.710814496145758, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint222, viewCenter222)
    
    scaleAboutPoint223 = NXOpen.Point3d(64.166364426455203, 43.906941175440707, 0.0)
    viewCenter223 = NXOpen.Point3d(-64.166364426455871, -43.90694117541981, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint223, viewCenter223)
    
    scaleAboutPoint224 = NXOpen.Point3d(51.66498652957678, 35.236184603158883, 0.0)
    viewCenter224 = NXOpen.Point3d(-51.664986529577455, -35.236184603137978, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint224, viewCenter224)
    
    scaleAboutPoint225 = NXOpen.Point3d(41.686010544634904, 28.277453012772582, 0.0)
    viewCenter225 = NXOpen.Point3d(-41.686010544635572, -28.277453012751678, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint225, viewCenter225)
    
    scaleAboutPoint226 = NXOpen.Point3d(30.6582463963089, 21.205877126325973, 0.0)
    viewCenter226 = NXOpen.Point3d(-30.658246396309579, -21.205877126305062, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint226, viewCenter226)
    
    scaleAboutPoint227 = NXOpen.Point3d(24.526597117047036, 16.908058289707089, 0.0)
    viewCenter227 = NXOpen.Point3d(-24.526597117047729, -16.908058289686188, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint227, viewCenter227)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()