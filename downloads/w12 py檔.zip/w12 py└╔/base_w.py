﻿# NX 2027
# Journal created by Admin on Fri May 17 15:44:53 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\yan1\\portable_2024\\portable_2024\\base_w.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder1 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder1.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId6, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder1.UseWorkPartOrigin = False
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 1.0
    matrix1.Xy = 0.0
    matrix1.Xz = 0.0
    matrix1.Yx = 0.0
    matrix1.Yy = 1.0
    matrix1.Yz = 0.0
    matrix1.Zx = 0.0
    matrix1.Zy = 0.0
    matrix1.Zz = 1.0
    plane2 = workPart.Planes.CreateFixedTypePlane(origin2, matrix1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction1 = workPart.Directions.CreateDirection(origin3, vector1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector2 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction2 = workPart.Directions.CreateDirection(origin4, vector2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix2 = NXOpen.Matrix3x3()
    
    matrix2.Xx = 1.0
    matrix2.Xy = 0.0
    matrix2.Xz = 0.0
    matrix2.Yx = 0.0
    matrix2.Yy = 1.0
    matrix2.Yz = 0.0
    matrix2.Zx = 0.0
    matrix2.Zy = 0.0
    matrix2.Zz = 1.0
    plane3 = workPart.Planes.CreateFixedTypePlane(origin5, matrix2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane3, direction2, point2, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder1.CoordinateSystem = cartesianCoordinateSystem1
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    simpleSketchInPlaceBuilder1.HorizontalReference.Value = datumAxis1
    
    point3 = simpleSketchInPlaceBuilder1.SketchOrigin
    
    simpleSketchInPlaceBuilder1.SketchOrigin = point3
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId7, None)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject2 = simpleSketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId9)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder1 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject3 = sketchFindMovableObjectsBuilder1.Commit()
    
    sketchFindMovableObjectsBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId8, None)
    
    theSession.SetUndoMarkName(markId6, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    simpleSketchInPlaceBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId5, None, True)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_000")
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId12, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(210.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(210.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(210.0, 200.0, 0.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(210.0, 200.0, 0.0)
    endPoint3 = NXOpen.Point3d(0.0, 200.0, 0.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 200.0, 0.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    objects1 = [NXOpen.NXObject.Null] * 4 
    objects1[0] = sketchGeometricConstraint1
    objects1[1] = sketchGeometricConstraint2
    objects1[2] = sketchGeometricConstraint3
    objects1[3] = sketchGeometricConstraint4
    errorList1 = theSession.ActiveSketch.DeleteObjects(objects1)
    
    errorList1.Dispose()
    sketchFindMovableObjectsBuilder2 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject4 = sketchFindMovableObjectsBuilder2.Commit()
    
    sketchFindMovableObjectsBuilder2.Destroy()
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder1 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects1 = [None] * 1 
    dragobjects1[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects1[0].Geometry = line3
    dragobjects1[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects1[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects1)
    
    sketchDragGeometryBuilder1.SplineLinearScale = False
    
    foundrelations1 = sketchDragGeometryBuilder1.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects2 = [None] * 1 
    dragobjects2[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects2[0].Geometry = line3
    dragobjects2[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects2[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects2)
    
    foundrelations2 = sketchDragGeometryBuilder1.FindRelations()
    
    sketchDragGeometryBuilder1.Destroy()
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences1 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences1 = dimensionPreferences1.GetNarrowDimensionPreferences()
    
    option1 = narrowDimensionPreferences1.DimensionDisplayOption
    
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder1 = sketchLinearDimensionBuilder1.Driving
    
    drivingValueBuilder1.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject1 = sketchLinearDimensionBuilder1.FirstAssociativity
    
    selectNXObject2 = sketchLinearDimensionBuilder1.SecondAssociativity
    
    point1_3 = NXOpen.Point3d(210.0, 200.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject1.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(0.0, 200.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject2.SetValue(NXOpen.InferSnapType.SnapType.End, line3, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionMeasurementBuilder1 = sketchLinearDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder1.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder1 = sketchLinearDimensionBuilder1.Origin
    
    origin7 = NXOpen.Point3d(105.0, 235.04770590229197, 0.0)
    originBuilder1.OriginPoint = origin7
    
    originBuilder1.SetInferRelativeToGeometry(True)
    
    nXObject5 = sketchLinearDimensionBuilder1.Commit()
    
    horizontalDimension1 = nXObject5
    horizontalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences1.Dispose()
    dimensionPreferences1.Dispose()
    sketchFindMovableObjectsBuilder3 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject6 = sketchFindMovableObjectsBuilder3.Commit()
    
    sketchFindMovableObjectsBuilder3.Destroy()
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder1 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension1)
    
    selectNXObjectList1 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations3 = sketchEditDimensionValueBuilder1.FindRelations()
    
    sketchHelpedDimensionalConstraint1 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line3] StartVertex] [[Curve Line3] EndVertex]")
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId16, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId17, None)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.DimValue = 120.0
    
    theSession.ActiveSketch.Scale(0.5714285714285714)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin8 = NXOpen.Point3d(60.0, 134.31297480130968, 0.0)
    horizontalDimension1.AnnotationOrigin = origin8
    
    sketchEditDimensionValueBuilder1.RestoreOperation()
    
    sketchEditDimensionValueBuilder1.LoadExtraGeometry()
    
    selectNXObjectList2 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations4 = sketchEditDimensionValueBuilder1.FindRelations()
    
    nXObject7 = sketchEditDimensionValueBuilder1.Commit()
    
    theSession.SetUndoMarkName(markId18, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId18, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId20, None)
    
    theSession.SetUndoMarkName(markId16, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId19, None)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId18, None)
    
    theSession.DeleteUndoMark(markId16, None)
    
    sketchFindMovableObjectsBuilder4 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject8 = sketchFindMovableObjectsBuilder4.Commit()
    
    sketchFindMovableObjectsBuilder4.Destroy()
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder2 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects3 = [None] * 1 
    dragobjects3[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects3[0].Geometry = line2
    dragobjects3[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects3[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects3)
    
    sketchDragGeometryBuilder2.SplineLinearScale = False
    
    foundrelations5 = sketchDragGeometryBuilder2.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects4 = [None] * 1 
    dragobjects4[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects4[0].Geometry = line2
    dragobjects4[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects4[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects4)
    
    foundrelations6 = sketchDragGeometryBuilder2.FindRelations()
    
    sketchDragGeometryBuilder2.Destroy()
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences2 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences2 = dimensionPreferences2.GetNarrowDimensionPreferences()
    
    option2 = narrowDimensionPreferences2.DimensionDisplayOption
    
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder2 = sketchLinearDimensionBuilder2.Driving
    
    drivingValueBuilder2.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject3 = sketchLinearDimensionBuilder2.FirstAssociativity
    
    selectNXObject4 = sketchLinearDimensionBuilder2.SecondAssociativity
    
    point1_7 = NXOpen.Point3d(120.0, 0.0, 0.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject3.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, NXOpen.View.Null, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(120.0, 114.28571428571428, 0.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject4.SetValue(NXOpen.InferSnapType.SnapType.End, line2, NXOpen.View.Null, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    dimensionMeasurementBuilder2 = sketchLinearDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder2.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder2 = sketchLinearDimensionBuilder2.Origin
    
    origin10 = NXOpen.Point3d(140.02726051559543, 57.142857142857139, 0.0)
    originBuilder2.OriginPoint = origin10
    
    originBuilder2.SetInferRelativeToGeometry(True)
    
    nXObject9 = sketchLinearDimensionBuilder2.Commit()
    
    verticalDimension1 = nXObject9
    verticalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences2.Dispose()
    dimensionPreferences2.Dispose()
    sketchFindMovableObjectsBuilder5 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject10 = sketchFindMovableObjectsBuilder5.Commit()
    
    sketchFindMovableObjectsBuilder5.Destroy()
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder2 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension1)
    
    selectNXObjectList3 = sketchEditDimensionValueBuilder2.ExtraGeometries
    
    foundrelations7 = sketchEditDimensionValueBuilder2.FindRelations()
    
    sketchHelpedDimensionalConstraint2 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line2] StartVertex] [[Curve Line2] EndVertex]")
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId24, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId25, None)
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.DimValue = 120.0
    
    nXObject11 = sketchEditDimensionValueBuilder2.Commit()
    
    theSession.SetUndoMarkName(markId26, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId28, None)
    
    theSession.SetUndoMarkName(markId24, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId27, None)
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId26, None)
    
    theSession.DeleteUndoMark(markId24, None)
    
    sketchFindMovableObjectsBuilder6 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject12 = sketchFindMovableObjectsBuilder6.Commit()
    
    sketchFindMovableObjectsBuilder6.Destroy()
    
    scaleAboutPoint1 = NXOpen.Point3d(188.55179001739998, 82.942180854648655, 0.0)
    viewCenter1 = NXOpen.Point3d(-188.55179001739998, -82.942180854648655, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(225.38636101806682, 102.38980400535038, 0.0)
    viewCenter2 = NXOpen.Point3d(-225.38636101806682, -102.38980400535038, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(255.97451001337629, 124.76744984928709, 0.0)
    viewCenter3 = NXOpen.Point3d(-255.97451001337572, -124.76744984928709, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(229.41111746481829, 153.94693408823321, 0.0)
    viewCenter4 = NXOpen.Point3d(-229.41111746481795, -153.94693408823321, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(183.52889397185476, 123.15754727058656, 0.0)
    viewCenter5 = NXOpen.Point3d(-183.52889397185422, -123.15754727058656, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(146.8231151774838, 98.526037816469128, 0.0)
    viewCenter6 = NXOpen.Point3d(-146.82311517748315, -98.526037816469128, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(117.45849214198722, 78.820830253175401, 0.0)
    viewCenter7 = NXOpen.Point3d(-117.45849214198651, -78.820830253175401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(94.791063833884436, 63.056664202540382, 0.0)
    viewCenter8 = NXOpen.Point3d(-94.791063833883797, -63.05666420254024, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(77.151683259579016, 50.445331362032306, 0.0)
    viewCenter9 = NXOpen.Point3d(-77.151683259578462, -50.445331362032192, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder1 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder1.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject13 = sketchWorkRegionBuilder1.Commit()
    
    sketchWorkRegionBuilder1.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("-100")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId30, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions1 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions1.SetSelectedFromInactive(False)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    curves1[0] = line1
    curves1[1] = line2
    curves1[2] = line3
    curves1[3] = line4
    seedPoint1 = NXOpen.Point3d(68.828759999999988, 68.828760000000003, 0.0)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch1, curves1, seedPoint1, 0.01, selectionIntentRuleOptions1)
    
    selectionIntentRuleOptions1.Dispose()
    section1.AllowSelfIntersection(True)
    
    section1.AllowDegenerateCurves(False)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId31, None)
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId33, None)
    
    direction3 = workPart.Directions.CreateDirection(sketch1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction3
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies2)
    
    targetBodies3 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies3)
    
    theSession.DeleteUndoMark(markId32, None)
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies4)
    
    targetBodies5 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder1.Destroy()
    
    section1.Destroy()
    
    workPart.Expressions.Delete(expression3)
    
    theSession.UndoToMark(markId30, None)
    
    theSession.DeleteUndoMark(markId30, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies6)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("-100")
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId34, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder2.Destroy()
    
    section2.Destroy()
    
    workPart.Expressions.Delete(expression4)
    
    theSession.UndoToMark(markId34, None)
    
    theSession.DeleteUndoMark(markId34, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression5 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies7)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("-100")
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId35, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions2 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions2.SetSelectedFromInactive(False)
    
    curves2 = [NXOpen.ICurve.Null] * 4 
    curves2[0] = line1
    curves2[1] = line2
    curves2[2] = line3
    curves2[3] = line4
    seedPoint2 = NXOpen.Point3d(68.828759999999988, 68.828760000000003, 0.0)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch1, curves2, seedPoint2, 0.01, selectionIntentRuleOptions2)
    
    selectionIntentRuleOptions2.Dispose()
    section3.AllowSelfIntersection(True)
    
    section3.AllowDegenerateCurves(False)
    
    rules2 = [None] * 1 
    rules2[0] = regionBoundaryRule2
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section3.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId36, None)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId38, None)
    
    direction4 = workPart.Directions.CreateDirection(sketch1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction4
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies8)
    
    targetBodies9 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies9)
    
    theSession.DeleteUndoMark(markId37, None)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies10)
    
    targetBodies11 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies12)
    
    targetBodies13 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies14)
    
    targetBodies15 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies15)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies16)
    
    targetBodies17 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies18)
    
    targetBodies19 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies19)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies20)
    
    targetBodies21 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies22)
    
    targetBodies23 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("65")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies24)
    
    targetBodies25 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies26)
    
    targetBodies27 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies27)
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId39, None)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId40, None)
    
    theSession.SetUndoMarkName(markId35, "Extrude")
    
    expression6 = extrudeBuilder3.Limits.StartExtend.Value
    expression7 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression5)
    
    scaleAboutPoint10 = NXOpen.Point3d(186.4911147166633, -10.818545328867211, 0.0)
    viewCenter10 = NXOpen.Point3d(-186.4911147166633, 10.818545328867211, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(230.53804926990827, -12.235259598123594, 0.0)
    viewCenter11 = NXOpen.Point3d(-230.53804926990827, 12.235259598123594, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(286.56265900868499, -15.294074497654496, 0.0)
    viewCenter12 = NXOpen.Point3d(-286.56265900868499, 15.294074497654496, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(352.16618909072963, -15.092836675316981, 0.0)
    viewCenter13 = NXOpen.Point3d(-352.16618909072929, 15.092836675316981, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(402.47564467511984, 3.7732091688292457, 0.0)
    viewCenter14 = NXOpen.Point3d(-402.47564467511961, -3.7732091688290312, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(323.99289396347115, 3.0185673350633961, 0.0)
    viewCenter15 = NXOpen.Point3d(-323.99289396347081, -3.0185673350632247, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(260.80421774947769, 0.80495128935046778, 0.0)
    viewCenter16 = NXOpen.Point3d(-260.80421774947717, -0.80495128935019322, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(208.64337419958204, -0.64396103148004469, 0.0)
    viewCenter17 = NXOpen.Point3d(-208.64337419958181, 0.6439610314803742, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(167.94503701003407, -1.5455064755523709, 0.0)
    viewCenter18 = NXOpen.Point3d(-167.94503701003362, 1.5455064755525467, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(129.41040888625952, -3.7092155413258303, 0.0)
    viewCenter19 = NXOpen.Point3d(-129.41040888625886, 3.7092155413260413, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(103.52832710900772, -2.9673724330606084, 0.0)
    viewCenter20 = NXOpen.Point3d(-103.52832710900694, 2.9673724330608331, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(66.996675377549039, -10.28689110127703, 0.0)
    viewCenter21 = NXOpen.Point3d(-66.996675377548229, 10.2868911012773, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(53.597340302039356, -8.2295128810216251, 0.0)
    viewCenter22 = NXOpen.Point3d(-53.597340302038567, 8.2295128810218419, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin11, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder2 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId43, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder2.UseWorkPartOrigin = False
    
    coordinates3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point4 = workPart.Points.CreatePoint(coordinates3)
    
    origin12 = NXOpen.Point3d(79.204548463912516, 79.204548463912516, 0.0)
    matrix3 = NXOpen.Matrix3x3()
    
    matrix3.Xx = 1.0
    matrix3.Xy = 0.0
    matrix3.Xz = 0.0
    matrix3.Yx = 0.0
    matrix3.Yy = 1.0
    matrix3.Yz = 0.0
    matrix3.Zx = 0.0
    matrix3.Zy = 0.0
    matrix3.Zz = 1.0
    plane5 = workPart.Planes.CreateFixedTypePlane(origin12, matrix3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point5 = workPart.Points.CreatePoint(coordinates4)
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction5 = workPart.Directions.CreateDirection(origin13, vector3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector4 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction6 = workPart.Directions.CreateDirection(origin14, vector4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix4 = NXOpen.Matrix3x3()
    
    matrix4.Xx = 1.0
    matrix4.Xy = 0.0
    matrix4.Xz = 0.0
    matrix4.Yx = 0.0
    matrix4.Yy = 1.0
    matrix4.Yz = 0.0
    matrix4.Zx = 0.0
    matrix4.Zy = 0.0
    matrix4.Zz = 1.0
    plane6 = workPart.Planes.CreateFixedTypePlane(origin15, matrix4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane6, direction6, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder2.CoordinateSystem = cartesianCoordinateSystem2
    
    simpleSketchInPlaceBuilder2.HorizontalReference.Value = datumAxis1
    
    point6 = simpleSketchInPlaceBuilder2.SketchOrigin
    
    simpleSketchInPlaceBuilder2.SketchOrigin = point6
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId44, None)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject14 = simpleSketchInPlaceBuilder2.Commit()
    
    sketch2 = nXObject14
    feature3 = sketch2.Feature
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId46)
    
    sketch2.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder7 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject15 = sketchFindMovableObjectsBuilder7.Commit()
    
    sketchFindMovableObjectsBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId45, None)
    
    theSession.SetUndoMarkName(markId43, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    simpleSketchInPlaceBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression9)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression8)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId42, None, True)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_001")
    
    scaleAboutPoint23 = NXOpen.Point3d(81.704291987990487, 36.969504019359285, 0.0)
    viewCenter23 = NXOpen.Point3d(-81.704291987989691, -36.969504019359057, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(65.90362725642882, 29.575603215487458, 0.0)
    viewCenter24 = NXOpen.Point3d(-65.903627256428024, -29.575603215487227, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(52.938979271557606, 23.660482572389981, 0.0)
    viewCenter25 = NXOpen.Point3d(-52.938979271556839, -23.660482572389778, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint25, viewCenter25)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId49, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(52.0, 8.0, 0.0)
    endPoint5 = NXOpen.Point3d(55.0, 8.0, 0.0)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(55.0, 8.0, 0.0)
    endPoint6 = NXOpen.Point3d(55.0, 17.0, 0.0)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(55.0, 17.0, 0.0)
    endPoint7 = NXOpen.Point3d(52.0, 17.0, 0.0)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(52.0, 17.0, 0.0)
    endPoint8 = NXOpen.Point3d(52.0, 8.0, 0.0)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line5
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line6
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line6
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line7
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line7
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line8
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line8
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line5
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    objects2 = [NXOpen.NXObject.Null] * 4 
    objects2[0] = sketchGeometricConstraint5
    objects2[1] = sketchGeometricConstraint6
    objects2[2] = sketchGeometricConstraint7
    objects2[3] = sketchGeometricConstraint8
    errorList2 = theSession.ActiveSketch.DeleteObjects(objects2)
    
    errorList2.Dispose()
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId50, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint9 = NXOpen.Point3d(60.0, 8.0, 0.0)
    endPoint9 = NXOpen.Point3d(64.0, 8.0, 0.0)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(64.0, 8.0, 0.0)
    endPoint10 = NXOpen.Point3d(64.0, 17.0, 0.0)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(64.0, 17.0, 0.0)
    endPoint11 = NXOpen.Point3d(60.0, 17.0, 0.0)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(60.0, 17.0, 0.0)
    endPoint12 = NXOpen.Point3d(60.0, 8.0, 0.0)
    line12 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line9
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line10
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line10
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line11
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line11
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line12
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line12
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line9
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line9
    geoms5[1] = line10
    geoms5[2] = line11
    geoms5[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line9
    geoms6[1] = line10
    geoms6[2] = line11
    geoms6[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms6)
    
    objects3 = [NXOpen.NXObject.Null] * 4 
    objects3[0] = sketchGeometricConstraint9
    objects3[1] = sketchGeometricConstraint10
    objects3[2] = sketchGeometricConstraint11
    objects3[3] = sketchGeometricConstraint12
    errorList3 = theSession.ActiveSketch.DeleteObjects(objects3)
    
    errorList3.Dispose()
    sketchFindMovableObjectsBuilder8 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject16 = sketchFindMovableObjectsBuilder8.Commit()
    
    sketchFindMovableObjectsBuilder8.Destroy()
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder3 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects5 = [None] * 1 
    dragobjects5[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects5[0].Geometry = line9
    dragobjects5[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects5[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects5)
    
    sketchDragGeometryBuilder3.SplineLinearScale = False
    
    foundrelations8 = sketchDragGeometryBuilder3.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects6 = [None] * 1 
    dragobjects6[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects6[0].Geometry = line9
    dragobjects6[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects6[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects6)
    
    foundrelations9 = sketchDragGeometryBuilder3.FindRelations()
    
    sketchDragGeometryBuilder3.Destroy()
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences3 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences3 = dimensionPreferences3.GetNarrowDimensionPreferences()
    
    option3 = narrowDimensionPreferences3.DimensionDisplayOption
    
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder3 = sketchLinearDimensionBuilder3.Driving
    
    drivingValueBuilder3.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject5 = sketchLinearDimensionBuilder3.FirstAssociativity
    
    selectNXObject6 = sketchLinearDimensionBuilder3.SecondAssociativity
    
    point1_11 = NXOpen.Point3d(60.0, 8.0, 0.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject5.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, NXOpen.View.Null, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(64.0, 8.0, 0.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject6.SetValue(NXOpen.InferSnapType.SnapType.End, line9, NXOpen.View.Null, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    dimensionMeasurementBuilder3 = sketchLinearDimensionBuilder3.Measurement
    
    dimensionMeasurementBuilder3.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder3 = sketchLinearDimensionBuilder3.Origin
    
    origin17 = NXOpen.Point3d(62.0, 2.119970677727725, 0.0)
    originBuilder3.OriginPoint = origin17
    
    originBuilder3.SetInferRelativeToGeometry(True)
    
    nXObject17 = sketchLinearDimensionBuilder3.Commit()
    
    horizontalDimension2 = nXObject17
    horizontalDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder3.Destroy()
    
    narrowDimensionPreferences3.Dispose()
    dimensionPreferences3.Dispose()
    sketchFindMovableObjectsBuilder9 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject18 = sketchFindMovableObjectsBuilder9.Commit()
    
    sketchFindMovableObjectsBuilder9.Destroy()
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder3 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension2)
    
    selectNXObjectList4 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations10 = sketchEditDimensionValueBuilder3.FindRelations()
    
    sketchHelpedDimensionalConstraint3 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line9] StartVertex] [[Curve Line9] EndVertex]")
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId54, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId55, None)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.DimValue = 1.5
    
    theSession.ActiveSketch.Scale(0.375)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin18 = NXOpen.Point3d(23.25, 0.79498900414789686, 0.0)
    horizontalDimension2.AnnotationOrigin = origin18
    
    sketchEditDimensionValueBuilder3.RestoreOperation()
    
    sketchEditDimensionValueBuilder3.LoadExtraGeometry()
    
    selectNXObjectList5 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations11 = sketchEditDimensionValueBuilder3.FindRelations()
    
    nXObject19 = sketchEditDimensionValueBuilder3.Commit()
    
    theSession.SetUndoMarkName(markId56, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId56, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId58, None)
    
    theSession.SetUndoMarkName(markId54, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId57, None)
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.DeleteUndoMark(markId54, None)
    
    sketchFindMovableObjectsBuilder10 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject20 = sketchFindMovableObjectsBuilder10.Commit()
    
    sketchFindMovableObjectsBuilder10.Destroy()
    
    scaleAboutPoint26 = NXOpen.Point3d(-19.53340296387216, -15.816870541542713, 0.0)
    viewCenter26 = NXOpen.Point3d(19.533402963872955, 15.816870541542919, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(-15.626722371097646, -12.653496433234148, 0.0)
    viewCenter27 = NXOpen.Point3d(15.626722371098449, 12.653496433234359, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(-12.501377896878042, -10.122797146587299, 0.0)
    viewCenter28 = NXOpen.Point3d(12.501377896878834, 10.122797146587505, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-10.001102317502365, -8.0982377172698161, 0.0)
    viewCenter29 = NXOpen.Point3d(10.001102317503127, 8.0982377172700275, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder4 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects7 = [None] * 1 
    dragobjects7[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects7[0].Geometry = line5
    dragobjects7[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects7[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects7)
    
    sketchDragGeometryBuilder4.SplineLinearScale = False
    
    foundrelations12 = sketchDragGeometryBuilder4.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects8 = [None] * 1 
    dragobjects8[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects8[0].Geometry = line5
    dragobjects8[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects8[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects8)
    
    foundrelations13 = sketchDragGeometryBuilder4.FindRelations()
    
    sketchDragGeometryBuilder4.Destroy()
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences4 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences4 = dimensionPreferences4.GetNarrowDimensionPreferences()
    
    option4 = narrowDimensionPreferences4.DimensionDisplayOption
    
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder4 = sketchLinearDimensionBuilder4.Driving
    
    drivingValueBuilder4.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject7 = sketchLinearDimensionBuilder4.FirstAssociativity
    
    selectNXObject8 = sketchLinearDimensionBuilder4.SecondAssociativity
    
    point1_15 = NXOpen.Point3d(19.5, 3.0, 0.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject7.SetValue(NXOpen.InferSnapType.SnapType.Start, line5, NXOpen.View.Null, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(20.625, 3.0, 0.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject8.SetValue(NXOpen.InferSnapType.SnapType.End, line5, NXOpen.View.Null, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    dimensionMeasurementBuilder4 = sketchLinearDimensionBuilder4.Measurement
    
    dimensionMeasurementBuilder4.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder4 = sketchLinearDimensionBuilder4.Origin
    
    origin20 = NXOpen.Point3d(20.0625, 0.79498900414789686, 0.0)
    originBuilder4.OriginPoint = origin20
    
    originBuilder4.SetInferRelativeToGeometry(True)
    
    nXObject21 = sketchLinearDimensionBuilder4.Commit()
    
    horizontalDimension3 = nXObject21
    horizontalDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder4.Destroy()
    
    narrowDimensionPreferences4.Dispose()
    dimensionPreferences4.Dispose()
    sketchFindMovableObjectsBuilder11 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject22 = sketchFindMovableObjectsBuilder11.Commit()
    
    sketchFindMovableObjectsBuilder11.Destroy()
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder4 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension3)
    
    selectNXObjectList6 = sketchEditDimensionValueBuilder4.ExtraGeometries
    
    foundrelations14 = sketchEditDimensionValueBuilder4.FindRelations()
    
    sketchHelpedDimensionalConstraint4 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line5] StartVertex] [[Curve Line5] EndVertex]")
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId62, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId62, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId63, None)
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.DimValue = 1.5
    
    nXObject23 = sketchEditDimensionValueBuilder4.Commit()
    
    theSession.SetUndoMarkName(markId64, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId62, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId66, None)
    
    theSession.SetUndoMarkName(markId62, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId65, None)
    
    theSession.SetUndoMarkVisibility(markId62, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId64, None)
    
    theSession.DeleteUndoMark(markId62, None)
    
    sketchFindMovableObjectsBuilder12 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject24 = sketchFindMovableObjectsBuilder12.Commit()
    
    sketchFindMovableObjectsBuilder12.Destroy()
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder5 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects9 = [None] * 1 
    dragobjects9[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects9[0].Geometry = line6
    dragobjects9[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects9[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects9)
    
    sketchDragGeometryBuilder5.SplineLinearScale = False
    
    foundrelations15 = sketchDragGeometryBuilder5.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects10 = [None] * 2 
    dragobjects10[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects10[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects10[0].Geometry = line6
    dragobjects10[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects10[0].PointIndex = 0
    dragobjects10[1].Geometry = line12
    dragobjects10[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects10[1].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects10)
    
    foundrelations16 = sketchDragGeometryBuilder5.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    sketchFoundRelation1 = theSession.ActiveSketch.FindObject("FoundRelation Collinear [Curve Line5]")
    sketchDragGeometryBuilder5.SetRelationRelaxState(sketchFoundRelation1, True)
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    sketchFoundRelation2 = theSession.ActiveSketch.FindObject("FoundRelation Collinear [Curve Line5]")
    sketchDragGeometryBuilder5.SetRelationRelaxState(sketchFoundRelation2, False)
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    scaleAboutPoint30 = NXOpen.Point3d(-6.4431880417182041, -5.4165262108951833, 0.0)
    viewCenter30 = NXOpen.Point3d(6.4431880417189591, 5.4165262108953947, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(-8.053985052147846, -7.0361737543491625, 0.0)
    viewCenter31 = NXOpen.Point3d(8.053985052148608, 7.036173754349389, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(-6.4431880417181979, -5.6289390034793003, 0.0)
    viewCenter32 = NXOpen.Point3d(6.4431880417189706, 5.6289390034795357, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-5.1545504333744772, -4.5597946141391859, 0.0)
    viewCenter33 = NXOpen.Point3d(5.1545504333752543, 4.5597946141394177, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(-4.1236403466995082, -3.6478356913113257, 0.0)
    viewCenter34 = NXOpen.Point3d(4.1236403467002809, 3.6478356913115575, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(-3.298912277359535, -2.9182685530490353, 0.0)
    viewCenter35 = NXOpen.Point3d(3.2989122773602952, 2.9182685530492702, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(-2.6391298218875492, -2.2476105625967446, 0.0)
    viewCenter36 = NXOpen.Point3d(2.6391298218883157, 2.2476105625969796, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(-2.1113038575099572, -1.7980884500773744, 0.0)
    viewCenter37 = NXOpen.Point3d(2.1113038575107343, 1.798088450077608, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(-1.6890430860078878, -1.438470760061874, 0.0)
    viewCenter38 = NXOpen.Point3d(1.6890430860086634, 1.4384707600621098, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint38, viewCenter38)
    
    dragobjects11 = [None] * 2 
    dragobjects11[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects11[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects11[0].Geometry = line6
    dragobjects11[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects11[0].PointIndex = 0
    dragobjects11[1].Geometry = line12
    dragobjects11[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects11[1].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects11)
    
    foundrelations17 = sketchDragGeometryBuilder5.FindRelations()
    
    sketchDragGeometryBuilder5.Destroy()
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences5 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences5 = dimensionPreferences5.GetNarrowDimensionPreferences()
    
    option5 = narrowDimensionPreferences5.DimensionDisplayOption
    
    sketchLinearDimensionBuilder5 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder5 = sketchLinearDimensionBuilder5.Driving
    
    drivingValueBuilder5.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder5 = sketchLinearDimensionBuilder5.Measurement
    
    dimensionMeasurementBuilder5.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject9 = sketchLinearDimensionBuilder5.FirstAssociativity
    
    selectNXObject10 = sketchLinearDimensionBuilder5.SecondAssociativity
    
    point1_25 = NXOpen.Point3d(21.0, 3.5695284396040545, 0.0)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject9.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, NXOpen.View.Null, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    point1_26 = NXOpen.Point3d(22.5, 3.0, 0.0)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject10.SetValue(NXOpen.InferSnapType.SnapType.End, line12, NXOpen.View.Null, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    originBuilder5 = sketchLinearDimensionBuilder5.Origin
    
    origin25 = NXOpen.Point3d(21.75, 3.9235497605776004, 0.0)
    originBuilder5.OriginPoint = origin25
    
    originBuilder5.SetInferRelativeToGeometry(True)
    
    nXObject25 = sketchLinearDimensionBuilder5.Commit()
    
    perpendicularDimension1 = nXObject25
    perpendicularDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder5.Destroy()
    
    narrowDimensionPreferences5.Dispose()
    dimensionPreferences5.Dispose()
    sketchFindMovableObjectsBuilder13 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject26 = sketchFindMovableObjectsBuilder13.Commit()
    
    sketchFindMovableObjectsBuilder13.Destroy()
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder5 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension1)
    
    selectNXObjectList7 = sketchEditDimensionValueBuilder5.ExtraGeometries
    
    foundrelations18 = sketchEditDimensionValueBuilder5.FindRelations()
    
    sketchHelpedDimensionalConstraint5 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line6] [[Curve Line12] EndVertex]")
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId70, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId70, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId71, None)
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.DimValue = 2.8999999999999999
    
    nXObject27 = sketchEditDimensionValueBuilder5.Commit()
    
    theSession.SetUndoMarkName(markId72, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId72, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId70, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint39 = NXOpen.Point3d(-2.0045786075698726, -0.24500405203624895, 0.0)
    viewCenter39 = NXOpen.Point3d(2.0045786075706502, 0.24500405203648318, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-1.1403824967506937, -0.39794597542864441, 0.0)
    viewCenter40 = NXOpen.Point3d(1.1403824967514697, 0.39794597542888038, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(-0.75075181036074135, -0.44189821749092534, 0.0)
    viewCenter41 = NXOpen.Point3d(0.75075181036151684, 0.44189821749116193, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(-0.56258869839681336, -0.45995427368948427, 0.0)
    viewCenter42 = NXOpen.Point3d(0.56258869839758729, 0.45995427368972153, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(-0.70323587299611323, -0.58444602958481062, 0.0)
    viewCenter43 = NXOpen.Point3d(0.70323587299688872, 0.58444602958504799, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(-0.87904484124523963, -0.73055753698104253, 0.0)
    viewCenter44 = NXOpen.Point3d(0.87904484124601356, 0.73055753698128156, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(-1.0839573211301989, -0.91319692122633223, 0.0)
    viewCenter45 = NXOpen.Point3d(1.0839573211309739, 0.91319692122657159, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(-1.3363857383797824, -1.1414961515329458, 0.0)
    viewCenter46 = NXOpen.Point3d(1.3363857383805642, 1.1414961515331847, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(-0.97444793423515241, -0.89324393971579341, 0.0)
    viewCenter47 = NXOpen.Point3d(0.97444793423593579, 0.89324393971603477, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(-1.1890584911798927, -1.1165549246447715, 0.0)
    viewCenter48 = NXOpen.Point3d(1.1890584911806692, 1.1165549246450137, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(-1.4863231139749586, -1.3594418725383057, 0.0)
    viewCenter49 = NXOpen.Point3d(1.4863231139757436, 1.3594418725385466, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(-1.8579038924688023, -1.6086728825036818, 0.0)
    viewCenter50 = NXOpen.Point3d(1.8579038924695674, 1.6086728825039214, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint50, viewCenter50)
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId74, None)
    
    theSession.SetUndoMarkName(markId70, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.Destroy()
    
    theSession.DeleteUndoMark(markId73, None)
    
    theSession.SetUndoMarkVisibility(markId70, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId72, None)
    
    theSession.DeleteUndoMark(markId70, None)
    
    sketchFindMovableObjectsBuilder14 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject28 = sketchFindMovableObjectsBuilder14.Commit()
    
    sketchFindMovableObjectsBuilder14.Destroy()
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder6 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects12 = [None] * 1 
    dragobjects12[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects12[0].Geometry = line10
    dragobjects12[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects12[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects12)
    
    sketchDragGeometryBuilder6.SplineLinearScale = False
    
    foundrelations19 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects13 = [None] * 1 
    dragobjects13[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects13[0].Geometry = line10
    dragobjects13[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects13[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects13)
    
    foundrelations20 = sketchDragGeometryBuilder6.FindRelations()
    
    sketchDragGeometryBuilder6.Destroy()
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences6 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences6 = dimensionPreferences6.GetNarrowDimensionPreferences()
    
    option6 = narrowDimensionPreferences6.DimensionDisplayOption
    
    sketchLinearDimensionBuilder6 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder6 = sketchLinearDimensionBuilder6.Driving
    
    drivingValueBuilder6.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject11 = sketchLinearDimensionBuilder6.FirstAssociativity
    
    selectNXObject12 = sketchLinearDimensionBuilder6.SecondAssociativity
    
    point1_29 = NXOpen.Point3d(25.400000000000002, 3.0, 0.0)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject11.SetValue(NXOpen.InferSnapType.SnapType.Start, line10, NXOpen.View.Null, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    point1_30 = NXOpen.Point3d(25.400000000000002, 6.3750000000000009, 0.0)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject12.SetValue(NXOpen.InferSnapType.SnapType.End, line10, NXOpen.View.Null, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    dimensionMeasurementBuilder6 = sketchLinearDimensionBuilder6.Measurement
    
    dimensionMeasurementBuilder6.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder6 = sketchLinearDimensionBuilder6.Origin
    
    origin27 = NXOpen.Point3d(27.605010995852105, 4.6875, 0.0)
    originBuilder6.OriginPoint = origin27
    
    originBuilder6.SetInferRelativeToGeometry(True)
    
    nXObject29 = sketchLinearDimensionBuilder6.Commit()
    
    verticalDimension2 = nXObject29
    verticalDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder6.Destroy()
    
    narrowDimensionPreferences6.Dispose()
    dimensionPreferences6.Dispose()
    sketchFindMovableObjectsBuilder15 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject30 = sketchFindMovableObjectsBuilder15.Commit()
    
    sketchFindMovableObjectsBuilder15.Destroy()
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder6 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension2)
    
    selectNXObjectList8 = sketchEditDimensionValueBuilder6.ExtraGeometries
    
    foundrelations21 = sketchEditDimensionValueBuilder6.FindRelations()
    
    sketchHelpedDimensionalConstraint6 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line10] StartVertex] [[Curve Line10] EndVertex]")
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId78, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId78, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId79, None)
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    nXObject31 = sketchEditDimensionValueBuilder6.Commit()
    
    theSession.SetUndoMarkName(markId80, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId80, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId78, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.DimValue = 6.0
    
    nXObject32 = sketchEditDimensionValueBuilder6.Commit()
    
    theSession.SetUndoMarkName(markId81, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId81, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId78, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId83, None)
    
    theSession.SetUndoMarkName(markId78, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.Destroy()
    
    theSession.DeleteUndoMark(markId82, None)
    
    theSession.SetUndoMarkVisibility(markId78, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId81, None)
    
    theSession.DeleteUndoMark(markId80, None)
    
    theSession.DeleteUndoMark(markId78, None)
    
    sketchFindMovableObjectsBuilder16 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject33 = sketchFindMovableObjectsBuilder16.Commit()
    
    sketchFindMovableObjectsBuilder16.Destroy()
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder7 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects14 = [None] * 1 
    dragobjects14[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects14[0].Geometry = line8
    dragobjects14[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects14[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects14)
    
    sketchDragGeometryBuilder7.SplineLinearScale = False
    
    foundrelations22 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects15 = [None] * 1 
    dragobjects15[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects15[0].Geometry = line8
    dragobjects15[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects15[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects15)
    
    foundrelations23 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects16 = [None] * 1 
    dragobjects16[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects16[0].Geometry = line8
    dragobjects16[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects16[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects16)
    
    foundrelations24 = sketchDragGeometryBuilder7.FindRelations()
    
    sketchDragGeometryBuilder7.Destroy()
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences7 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences7 = dimensionPreferences7.GetNarrowDimensionPreferences()
    
    option7 = narrowDimensionPreferences7.DimensionDisplayOption
    
    sketchLinearDimensionBuilder7 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder7 = sketchLinearDimensionBuilder7.Driving
    
    drivingValueBuilder7.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder7 = sketchLinearDimensionBuilder7.Measurement
    
    dimensionMeasurementBuilder7.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject13 = sketchLinearDimensionBuilder7.FirstAssociativity
    
    selectNXObject14 = sketchLinearDimensionBuilder7.SecondAssociativity
    
    point1_35 = NXOpen.Point3d(19.5, 6.3851062924898621, 0.0)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject13.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line8, NXOpen.View.Null, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    point1_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject14.SetValue(NXOpen.InferSnapType.SnapType.End, line4, NXOpen.View.Null, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    originBuilder7 = sketchLinearDimensionBuilder7.Origin
    
    origin30 = NXOpen.Point3d(9.75, 6.8382535833360025, 0.0)
    originBuilder7.OriginPoint = origin30
    
    originBuilder7.SetInferRelativeToGeometry(True)
    
    nXObject34 = sketchLinearDimensionBuilder7.Commit()
    
    perpendicularDimension2 = nXObject34
    perpendicularDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder7.Destroy()
    
    narrowDimensionPreferences7.Dispose()
    dimensionPreferences7.Dispose()
    sketchFindMovableObjectsBuilder17 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject35 = sketchFindMovableObjectsBuilder17.Commit()
    
    sketchFindMovableObjectsBuilder17.Destroy()
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder7 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension2)
    
    selectNXObjectList9 = sketchEditDimensionValueBuilder7.ExtraGeometries
    
    foundrelations25 = sketchEditDimensionValueBuilder7.FindRelations()
    
    sketchHelpedDimensionalConstraint7 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line8] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line4] EndVertex]")
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId87, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId87, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId88, None)
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.DimValue = 60.100000000000001
    
    nXObject36 = sketchEditDimensionValueBuilder7.Commit()
    
    theSession.SetUndoMarkName(markId89, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId89, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId87, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint51 = NXOpen.Point3d(25.716108755518935, -4.673081436850719, 0.0)
    viewCenter51 = NXOpen.Point3d(-25.716108755518182, 4.6730814368509606, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(32.286744472787994, -5.8413517960634289, 0.0)
    viewCenter52 = NXOpen.Point3d(-32.286744472787241, 5.8413517960636705, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(40.358430590984888, -7.3016897450793152, 0.0)
    viewCenter53 = NXOpen.Point3d(-40.358430590984149, 7.3016897450795568, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(50.448038238731009, -9.0164805185449346, 0.0)
    viewCenter54 = NXOpen.Point3d(-50.448038238730277, 9.0164805185451797, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(75.367820285384695, -12.100338119212958, 0.0)
    viewCenter55 = NXOpen.Point3d(-75.367820285383942, 12.100338119213207, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(60.404887891112061, -9.7909021581745748, 0.0)
    viewCenter56 = NXOpen.Point3d(-60.404887891111322, 9.7909021581748199, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(48.32391031288973, -8.0097323870264088, 0.0)
    viewCenter57 = NXOpen.Point3d(-48.323910312888955, 8.0097323870266504, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint57, viewCenter57)
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId91, None)
    
    theSession.SetUndoMarkName(markId87, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId90, None)
    
    theSession.SetUndoMarkVisibility(markId87, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId89, None)
    
    theSession.DeleteUndoMark(markId87, None)
    
    sketchFindMovableObjectsBuilder18 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject37 = sketchFindMovableObjectsBuilder18.Commit()
    
    sketchFindMovableObjectsBuilder18.Destroy()
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder8 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects17 = [None] * 1 
    dragobjects17[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects17[0].Geometry = line9
    dragobjects17[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects17[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects17)
    
    sketchDragGeometryBuilder8.SplineLinearScale = False
    
    foundrelations26 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects18 = [None] * 1 
    dragobjects18[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects18[0].Geometry = line9
    dragobjects18[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects18[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects18)
    
    foundrelations27 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects19 = [None] * 1 
    dragobjects19[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects19[0].Geometry = line9
    dragobjects19[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects19[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects19)
    
    foundrelations28 = sketchDragGeometryBuilder8.FindRelations()
    
    sketchDragGeometryBuilder8.Destroy()
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences8 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences8 = dimensionPreferences8.GetNarrowDimensionPreferences()
    
    option8 = narrowDimensionPreferences8.DimensionDisplayOption
    
    sketchLinearDimensionBuilder8 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder8 = sketchLinearDimensionBuilder8.Driving
    
    drivingValueBuilder8.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder8 = sketchLinearDimensionBuilder8.Measurement
    
    dimensionMeasurementBuilder8.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject15 = sketchLinearDimensionBuilder8.FirstAssociativity
    
    selectNXObject16 = sketchLinearDimensionBuilder8.SecondAssociativity
    
    point1_39 = NXOpen.Point3d(65.270226952030242, 3.0, 0.0)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject15.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, NXOpen.View.Null, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(120.0, 0.0, 0.0)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject16.SetValue(NXOpen.InferSnapType.SnapType.End, line1, NXOpen.View.Null, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    originBuilder8 = sketchLinearDimensionBuilder8.Origin
    
    origin32 = NXOpen.Point3d(68.102397519818624, 1.5, 0.0)
    originBuilder8.OriginPoint = origin32
    
    originBuilder8.SetInferRelativeToGeometry(True)
    
    nXObject38 = sketchLinearDimensionBuilder8.Commit()
    
    perpendicularDimension3 = nXObject38
    perpendicularDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder8.Destroy()
    
    narrowDimensionPreferences8.Dispose()
    dimensionPreferences8.Dispose()
    sketchFindMovableObjectsBuilder19 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject39 = sketchFindMovableObjectsBuilder19.Commit()
    
    sketchFindMovableObjectsBuilder19.Destroy()
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder8 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension3)
    
    selectNXObjectList10 = sketchEditDimensionValueBuilder8.ExtraGeometries
    
    foundrelations29 = sketchEditDimensionValueBuilder8.FindRelations()
    
    sketchHelpedDimensionalConstraint8 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line9] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line1] EndVertex]")
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId95, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId95, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId96, None)
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder8.DimValue = 4.0
    
    nXObject40 = sketchEditDimensionValueBuilder8.Commit()
    
    theSession.SetUndoMarkName(markId97, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId97, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId95, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId99, None)
    
    theSession.SetUndoMarkName(markId95, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder8.Destroy()
    
    theSession.DeleteUndoMark(markId98, None)
    
    theSession.SetUndoMarkVisibility(markId95, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId97, None)
    
    theSession.DeleteUndoMark(markId95, None)
    
    sketchFindMovableObjectsBuilder20 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject41 = sketchFindMovableObjectsBuilder20.Commit()
    
    sketchFindMovableObjectsBuilder20.Destroy()
    
    scaleAboutPoint58 = NXOpen.Point3d(3.3986046813464386, 17.948880973359017, 0.0)
    viewCenter58 = NXOpen.Point3d(-3.3986046813456778, -17.948880973358786, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(4.2482558516829654, 22.436101216698741, 0.0)
    viewCenter59 = NXOpen.Point3d(-4.2482558516821962, -22.436101216698511, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(5.3103198146035933, 28.045126520873406, 0.0)
    viewCenter60 = NXOpen.Point3d(-5.3103198146028578, -28.045126520873161, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(6.3613206112438174, 34.364960258565262, 0.0)
    viewCenter61 = NXOpen.Point3d(-6.3613206112430865, -34.364960258565034, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(7.9516507640546674, 42.956200323206552, 0.0)
    viewCenter62 = NXOpen.Point3d(-7.9516507640539302, -42.956200323206318, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(9.9395634550682406, 53.695250404008142, 0.0)
    viewCenter63 = NXOpen.Point3d(-9.9395634550675034, -53.695250404007922, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(13.234744817889656, 80.894001488935757, 0.0)
    viewCenter64 = NXOpen.Point3d(-13.234744817888918, -80.89400148893553, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(6.6984014588504524, 70.1171378515116, 0.0)
    viewCenter65 = NXOpen.Point3d(-6.6984014588497152, -70.117137851511359, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(4.1486873551591374, 56.958020146867383, 0.0)
    viewCenter66 = NXOpen.Point3d(-4.1486873551584154, -56.958020146867135, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(3.3189498841273926, 45.704705695999237, 0.0)
    viewCenter67 = NXOpen.Point3d(-3.3189498841266376, -45.704705695998989, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(2.5445282444977528, 36.56376455679942, 0.0)
    viewCenter68 = NXOpen.Point3d(-2.5445282444969886, -36.563764556799164, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(1.858611935111506, 29.339516975682955, 0.0)
    viewCenter69 = NXOpen.Point3d(-1.8586119351107362, -29.339516975682688, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(2.3232649188892975, 36.674396219603636, 0.0)
    viewCenter70 = NXOpen.Point3d(-2.3232649188885333, -36.674396219603388, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(2.7657915701062197, 45.842995274504531, 0.0)
    viewCenter71 = NXOpen.Point3d(-2.7657915701054532, -45.842995274504275, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(3.4572394626326552, 57.303744093130604, 0.0)
    viewCenter72 = NXOpen.Point3d(-3.4572394626319332, -57.303744093130348, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(4.3215493282907271, 71.629680116413226, 0.0)
    viewCenter73 = NXOpen.Point3d(-4.3215493282899899, -71.62968011641297, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(5.4019366603633161, 89.537100145516504, 0.0)
    viewCenter74 = NXOpen.Point3d(-5.4019366603625789, -89.537100145516249, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(6.414799784181362, 118.67379600734928, 0.0)
    viewCenter75 = NXOpen.Point3d(-6.414799784180671, -118.67379600734903, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(7.5964734286358331, 149.18629761236829, 0.0)
    viewCenter76 = NXOpen.Point3d(-7.5964734286350417, -149.18629761236804, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(9.4955917857947014, 187.53793776943749, 0.0)
    viewCenter77 = NXOpen.Point3d(-9.4955917857939358, -187.53793776943721, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(10.55065753977191, 237.06008659673969, 0.0)
    viewCenter78 = NXOpen.Point3d(-10.550657539771066, -237.06008659673947, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(23.079563368250394, 253.46306199060302, 0.0)
    viewCenter79 = NXOpen.Point3d(-23.07956336824941, -253.46306199060277, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(28.849454210312906, 311.67713923641224, 0.0)
    viewCenter80 = NXOpen.Point3d(-28.849454210312029, -311.67713923641196, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(37.34973982585133, 383.15681373071334, 0.0)
    viewCenter81 = NXOpen.Point3d(-37.349739825850449, -383.15681373071317, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(48.297077361014679, 472.50640684858979, 0.0)
    viewCenter82 = NXOpen.Point3d(-48.297077361013855, -472.50640684858951, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(82.507507158399477, 705.33856729314596, 0.0)
    viewCenter83 = NXOpen.Point3d(-82.50750715839844, -705.33856729314584, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint83, viewCenter83)
    
    scaleAboutPoint84 = NXOpen.Point3d(66.006005726719707, 572.32036672801905, 0.0)
    viewCenter84 = NXOpen.Point3d(-66.006005726718882, -572.32036672801871, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(52.804804581375876, 463.00798163425674, 0.0)
    viewCenter85 = NXOpen.Point3d(-52.804804581374995, -463.00798163425651, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint85, viewCenter85)
    
    scaleAboutPoint86 = NXOpen.Point3d(42.243843665100876, 368.34571000666881, 0.0)
    viewCenter86 = NXOpen.Point3d(-42.243843665100002, -368.34571000666864, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint86, viewCenter86)
    
    scaleAboutPoint87 = NXOpen.Point3d(34.619345052375508, 289.73094728356722, 0.0)
    viewCenter87 = NXOpen.Point3d(-34.619345052374598, -289.73094728356705, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(28.354892138136254, 227.16884515320376, 0.0)
    viewCenter88 = NXOpen.Point3d(-28.354892138135241, -227.16884515320368, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(23.211446587497583, 178.04234598364295, 0.0)
    viewCenter89 = NXOpen.Point3d(-23.211446587496596, -178.0423459836428, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(18.569157269998176, 142.4338767869144, 0.0)
    viewCenter90 = NXOpen.Point3d(-18.569157269997167, -142.43387678691425, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(14.855325815998627, 113.94710142953151, 0.0)
    viewCenter91 = NXOpen.Point3d(-14.855325815997649, -113.94710142953137, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(11.884260652799041, 91.157681143625254, 0.0)
    viewCenter92 = NXOpen.Point3d(-11.884260652798005, -91.157681143625112, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint92, viewCenter92)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId101, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint13 = NXOpen.Point3d(10.0, 67.0, 0.0)
    endPoint13 = NXOpen.Point3d(19.0, 67.0, 0.0)
    line13 = workPart.Curves.CreateLine(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(19.0, 67.0, 0.0)
    endPoint14 = NXOpen.Point3d(19.0, 65.0, 0.0)
    line14 = workPart.Curves.CreateLine(startPoint14, endPoint14)
    
    startPoint15 = NXOpen.Point3d(19.0, 65.0, 0.0)
    endPoint15 = NXOpen.Point3d(10.0, 65.0, 0.0)
    line15 = workPart.Curves.CreateLine(startPoint15, endPoint15)
    
    startPoint16 = NXOpen.Point3d(10.0, 65.0, 0.0)
    endPoint16 = NXOpen.Point3d(10.0, 67.0, 0.0)
    line16 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line13
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_13.Geometry = line14
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_13, conGeom2_13)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line14
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_14.Geometry = line15
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line15
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_15.Geometry = line16
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_15, conGeom2_15)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line16
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_16.Geometry = line13
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_16, conGeom2_16)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line13
    geoms7[1] = line14
    geoms7[2] = line15
    geoms7[3] = line16
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line13
    geoms8[1] = line14
    geoms8[2] = line15
    geoms8[3] = line16
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    objects4 = [NXOpen.NXObject.Null] * 4 
    objects4[0] = sketchGeometricConstraint13
    objects4[1] = sketchGeometricConstraint14
    objects4[2] = sketchGeometricConstraint15
    objects4[3] = sketchGeometricConstraint16
    errorList4 = theSession.ActiveSketch.DeleteObjects(objects4)
    
    errorList4.Dispose()
    sketchFindMovableObjectsBuilder21 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject42 = sketchFindMovableObjectsBuilder21.Commit()
    
    sketchFindMovableObjectsBuilder21.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint93 = NXOpen.Point3d(-38.893943954612894, 31.007116430483546, 0.0)
    viewCenter93 = NXOpen.Point3d(38.89394395461396, -31.007116430483382, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(-30.250845298032154, 23.077073413070682, 0.0)
    viewCenter94 = NXOpen.Point3d(30.250845298033216, -23.077073413070547, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(-22.956070031877974, 16.110735895866604, 0.0)
    viewCenter95 = NXOpen.Point3d(22.956070031879012, -16.110735895866476, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint95, viewCenter95)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId103, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint17 = NXOpen.Point3d(10.0, 61.5, 0.0)
    endPoint17 = NXOpen.Point3d(19.0, 61.5, 0.0)
    line17 = workPart.Curves.CreateLine(startPoint17, endPoint17)
    
    startPoint18 = NXOpen.Point3d(19.0, 61.5, 0.0)
    endPoint18 = NXOpen.Point3d(19.0, 59.0, 0.0)
    line18 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    startPoint19 = NXOpen.Point3d(19.0, 59.0, 0.0)
    endPoint19 = NXOpen.Point3d(10.0, 59.0, 0.0)
    line19 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    startPoint20 = NXOpen.Point3d(10.0, 59.0, 0.0)
    endPoint20 = NXOpen.Point3d(10.0, 61.5, 0.0)
    line20 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    theSession.ActiveSketch.AddGeometry(line17, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line18, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line19, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line20, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_17.Geometry = line17
    conGeom1_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_17.SplineDefiningPointIndex = 0
    conGeom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_17.Geometry = line18
    conGeom2_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_17, conGeom2_17)
    
    conGeom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_18.Geometry = line18
    conGeom1_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_18.SplineDefiningPointIndex = 0
    conGeom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_18.Geometry = line19
    conGeom2_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_18, conGeom2_18)
    
    conGeom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_19.Geometry = line19
    conGeom1_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_19.SplineDefiningPointIndex = 0
    conGeom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_19.Geometry = line20
    conGeom2_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_19, conGeom2_19)
    
    conGeom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_20.Geometry = line20
    conGeom1_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_20.SplineDefiningPointIndex = 0
    conGeom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_20.Geometry = line17
    conGeom2_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_20, conGeom2_20)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms9 = [NXOpen.SmartObject.Null] * 4 
    geoms9[0] = line17
    geoms9[1] = line18
    geoms9[2] = line19
    geoms9[3] = line20
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 4 
    geoms10[0] = line17
    geoms10[1] = line18
    geoms10[2] = line19
    geoms10[3] = line20
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms10)
    
    objects5 = [NXOpen.NXObject.Null] * 4 
    objects5[0] = sketchGeometricConstraint17
    objects5[1] = sketchGeometricConstraint18
    objects5[2] = sketchGeometricConstraint19
    objects5[3] = sketchGeometricConstraint20
    errorList5 = theSession.ActiveSketch.DeleteObjects(objects5)
    
    errorList5.Dispose()
    sketchFindMovableObjectsBuilder22 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject43 = sketchFindMovableObjectsBuilder22.Commit()
    
    sketchFindMovableObjectsBuilder22.Destroy()
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder9 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects20 = [None] * 1 
    dragobjects20[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects20[0].Geometry = line16
    dragobjects20[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects20[0].PointIndex = 0
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects20)
    
    sketchDragGeometryBuilder9.SplineLinearScale = False
    
    foundrelations30 = sketchDragGeometryBuilder9.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects21 = [None] * 1 
    dragobjects21[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects21[0].Geometry = line16
    dragobjects21[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects21[0].PointIndex = 0
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects21)
    
    foundrelations31 = sketchDragGeometryBuilder9.FindRelations()
    
    sketchDragGeometryBuilder9.Destroy()
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences9 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences9 = dimensionPreferences9.GetNarrowDimensionPreferences()
    
    option9 = narrowDimensionPreferences9.DimensionDisplayOption
    
    sketchLinearDimensionBuilder9 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder9 = sketchLinearDimensionBuilder9.Driving
    
    drivingValueBuilder9.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject17 = sketchLinearDimensionBuilder9.FirstAssociativity
    
    selectNXObject18 = sketchLinearDimensionBuilder9.SecondAssociativity
    
    point1_43 = NXOpen.Point3d(10.0, 65.0, 0.0)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject17.SetValue(NXOpen.InferSnapType.SnapType.Start, line16, NXOpen.View.Null, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    point1_44 = NXOpen.Point3d(10.0, 67.0, 0.0)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject18.SetValue(NXOpen.InferSnapType.SnapType.End, line16, NXOpen.View.Null, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    dimensionMeasurementBuilder9 = sketchLinearDimensionBuilder9.Measurement
    
    dimensionMeasurementBuilder9.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder9 = sketchLinearDimensionBuilder9.Origin
    
    origin34 = NXOpen.Point3d(7.7949890041478973, 66.0, 0.0)
    originBuilder9.OriginPoint = origin34
    
    originBuilder9.SetInferRelativeToGeometry(True)
    
    nXObject44 = sketchLinearDimensionBuilder9.Commit()
    
    verticalDimension3 = nXObject44
    verticalDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder9.Destroy()
    
    narrowDimensionPreferences9.Dispose()
    dimensionPreferences9.Dispose()
    sketchFindMovableObjectsBuilder23 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject45 = sketchFindMovableObjectsBuilder23.Commit()
    
    sketchFindMovableObjectsBuilder23.Destroy()
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder9 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension3)
    
    selectNXObjectList11 = sketchEditDimensionValueBuilder9.ExtraGeometries
    
    foundrelations32 = sketchEditDimensionValueBuilder9.FindRelations()
    
    sketchHelpedDimensionalConstraint9 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line18] StartVertex] [[Curve Line18] EndVertex]")
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId107, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId107, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId108, None)
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    nXObject46 = sketchEditDimensionValueBuilder9.Commit()
    
    theSession.SetUndoMarkName(markId109, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId109, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId107, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId111, None)
    
    theSession.SetUndoMarkName(markId107, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder9.Destroy()
    
    theSession.DeleteUndoMark(markId110, None)
    
    theSession.SetUndoMarkVisibility(markId107, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId109, None)
    
    theSession.DeleteUndoMark(markId107, None)
    
    sketchFindMovableObjectsBuilder24 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject47 = sketchFindMovableObjectsBuilder24.Commit()
    
    sketchFindMovableObjectsBuilder24.Destroy()
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    verticalDimension4 = nXObject46
    sketchEditDimensionValueBuilder10 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension4)
    
    selectNXObjectList12 = sketchEditDimensionValueBuilder10.ExtraGeometries
    
    foundrelations33 = sketchEditDimensionValueBuilder10.FindRelations()
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId113, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId113, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId114, None)
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder10.DimValue = 1.5
    
    nXObject48 = sketchEditDimensionValueBuilder10.Commit()
    
    theSession.SetUndoMarkName(markId115, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId115, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId113, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId117, None)
    
    theSession.SetUndoMarkName(markId113, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder10.Destroy()
    
    theSession.DeleteUndoMark(markId116, None)
    
    theSession.SetUndoMarkVisibility(markId113, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId115, None)
    
    theSession.DeleteUndoMark(markId113, None)
    
    sketchFindMovableObjectsBuilder25 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject49 = sketchFindMovableObjectsBuilder25.Commit()
    
    sketchFindMovableObjectsBuilder25.Destroy()
    
    scaleAboutPoint96 = NXOpen.Point3d(-12.280114571269422, 7.9101638905027594, 0.0)
    viewCenter96 = NXOpen.Point3d(12.280114571270451, -7.9101638905026563, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(-10.001102317502218, 6.3281311124022297, 0.0)
    viewCenter97 = NXOpen.Point3d(10.001102317503245, -6.3281311124021089, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(-8.1424903823910899, 5.0625048899217902, 0.0)
    viewCenter98 = NXOpen.Point3d(8.1424903823921095, -5.0625048899216818, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint98, viewCenter98)
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder10 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects22 = [None] * 1 
    dragobjects22[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects22[0].Geometry = line20
    dragobjects22[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects22[0].PointIndex = 0
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects22)
    
    sketchDragGeometryBuilder10.SplineLinearScale = False
    
    foundrelations34 = sketchDragGeometryBuilder10.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects23 = [None] * 1 
    dragobjects23[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects23[0].Geometry = line20
    dragobjects23[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects23[0].PointIndex = 0
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects23)
    
    foundrelations35 = sketchDragGeometryBuilder10.FindRelations()
    
    sketchDragGeometryBuilder10.Destroy()
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences10 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences10 = dimensionPreferences10.GetNarrowDimensionPreferences()
    
    option10 = narrowDimensionPreferences10.DimensionDisplayOption
    
    sketchLinearDimensionBuilder10 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder10 = sketchLinearDimensionBuilder10.Driving
    
    drivingValueBuilder10.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject19 = sketchLinearDimensionBuilder10.FirstAssociativity
    
    selectNXObject20 = sketchLinearDimensionBuilder10.SecondAssociativity
    
    point1_47 = NXOpen.Point3d(10.0, 59.0, 0.0)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject19.SetValue(NXOpen.InferSnapType.SnapType.Start, line20, NXOpen.View.Null, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    point1_48 = NXOpen.Point3d(10.0, 61.5, 0.0)
    point2_48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject20.SetValue(NXOpen.InferSnapType.SnapType.End, line20, NXOpen.View.Null, point1_48, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_48)
    
    dimensionMeasurementBuilder10 = sketchLinearDimensionBuilder10.Measurement
    
    dimensionMeasurementBuilder10.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder10 = sketchLinearDimensionBuilder10.Origin
    
    origin36 = NXOpen.Point3d(7.7949890041478973, 60.25, 0.0)
    originBuilder10.OriginPoint = origin36
    
    originBuilder10.SetInferRelativeToGeometry(True)
    
    nXObject50 = sketchLinearDimensionBuilder10.Commit()
    
    verticalDimension5 = nXObject50
    verticalDimension5.IsOriginCentered = True
    
    sketchLinearDimensionBuilder10.Destroy()
    
    narrowDimensionPreferences10.Dispose()
    dimensionPreferences10.Dispose()
    sketchFindMovableObjectsBuilder26 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject51 = sketchFindMovableObjectsBuilder26.Commit()
    
    sketchFindMovableObjectsBuilder26.Destroy()
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder11 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension5)
    
    selectNXObjectList13 = sketchEditDimensionValueBuilder11.ExtraGeometries
    
    foundrelations36 = sketchEditDimensionValueBuilder11.FindRelations()
    
    sketchHelpedDimensionalConstraint10 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line22] StartVertex] [[Curve Line22] EndVertex]")
    sketchHelpedDimensionalConstraint10.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId121, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId121, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint10.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId122, None)
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder11.DimValue = 0.5
    
    nXObject52 = sketchEditDimensionValueBuilder11.Commit()
    
    theSession.SetUndoMarkName(markId123, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId123, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId121, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder11.DimValue = 1.5
    
    nXObject53 = sketchEditDimensionValueBuilder11.Commit()
    
    theSession.SetUndoMarkName(markId124, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId124, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId121, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint10.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId126, None)
    
    theSession.SetUndoMarkName(markId121, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder11.Destroy()
    
    theSession.DeleteUndoMark(markId125, None)
    
    theSession.SetUndoMarkVisibility(markId121, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId124, None)
    
    theSession.DeleteUndoMark(markId123, None)
    
    theSession.DeleteUndoMark(markId121, None)
    
    sketchFindMovableObjectsBuilder27 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject54 = sketchFindMovableObjectsBuilder27.Commit()
    
    sketchFindMovableObjectsBuilder27.Destroy()
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder11 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects24 = [None] * 1 
    dragobjects24[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects24[0].Geometry = line15
    dragobjects24[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects24[0].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects24)
    
    sketchDragGeometryBuilder11.SplineLinearScale = False
    
    foundrelations37 = sketchDragGeometryBuilder11.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects25 = [None] * 2 
    dragobjects25[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects25[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects25[0].Geometry = line15
    dragobjects25[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects25[0].PointIndex = 0
    dragobjects25[1].Geometry = line17
    dragobjects25[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects25[1].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects25)
    
    foundrelations38 = sketchDragGeometryBuilder11.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects26 = [None] * 2 
    dragobjects26[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects26[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects26[0].Geometry = line15
    dragobjects26[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects26[0].PointIndex = 0
    dragobjects26[1].Geometry = line17
    dragobjects26[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects26[1].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects26)
    
    foundrelations39 = sketchDragGeometryBuilder11.FindRelations()
    
    sketchDragGeometryBuilder11.Destroy()
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences11 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences11 = dimensionPreferences11.GetNarrowDimensionPreferences()
    
    option11 = narrowDimensionPreferences11.DimensionDisplayOption
    
    sketchLinearDimensionBuilder11 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder11 = sketchLinearDimensionBuilder11.Driving
    
    drivingValueBuilder11.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder11 = sketchLinearDimensionBuilder11.Measurement
    
    dimensionMeasurementBuilder11.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject21 = sketchLinearDimensionBuilder11.FirstAssociativity
    
    selectNXObject22 = sketchLinearDimensionBuilder11.SecondAssociativity
    
    point1_53 = NXOpen.Point3d(14.464212347716746, 65.0, 0.0)
    point2_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject21.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line15, NXOpen.View.Null, point1_53, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_53)
    
    point1_54 = NXOpen.Point3d(19.0, 60.500000000000007, 0.0)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject22.SetValue(NXOpen.InferSnapType.SnapType.End, line17, NXOpen.View.Null, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    originBuilder11 = sketchLinearDimensionBuilder11.Origin
    
    origin39 = NXOpen.Point3d(15.030646461274424, 62.75, 0.0)
    originBuilder11.OriginPoint = origin39
    
    originBuilder11.SetInferRelativeToGeometry(True)
    
    nXObject55 = sketchLinearDimensionBuilder11.Commit()
    
    perpendicularDimension4 = nXObject55
    perpendicularDimension4.IsOriginCentered = True
    
    sketchLinearDimensionBuilder11.Destroy()
    
    narrowDimensionPreferences11.Dispose()
    dimensionPreferences11.Dispose()
    sketchFindMovableObjectsBuilder28 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject56 = sketchFindMovableObjectsBuilder28.Commit()
    
    sketchFindMovableObjectsBuilder28.Destroy()
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder12 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension4)
    
    selectNXObjectList14 = sketchEditDimensionValueBuilder12.ExtraGeometries
    
    foundrelations40 = sketchEditDimensionValueBuilder12.FindRelations()
    
    sketchHelpedDimensionalConstraint11 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line17] [[Curve Line19] EndVertex]")
    sketchHelpedDimensionalConstraint11.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId130, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId130, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint11.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId131, None)
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder12.DimValue = 2.8999999999999999
    
    nXObject57 = sketchEditDimensionValueBuilder12.Commit()
    
    theSession.SetUndoMarkName(markId132, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId132, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId130, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint11.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId134, None)
    
    theSession.SetUndoMarkName(markId130, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder12.Destroy()
    
    theSession.DeleteUndoMark(markId133, None)
    
    theSession.SetUndoMarkVisibility(markId130, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId132, None)
    
    theSession.DeleteUndoMark(markId130, None)
    
    sketchFindMovableObjectsBuilder29 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject58 = sketchFindMovableObjectsBuilder29.Commit()
    
    sketchFindMovableObjectsBuilder29.Destroy()
    
    scaleAboutPoint99 = NXOpen.Point3d(-12.065046618777998, -0.53811240787973313, 0.0)
    viewCenter99 = NXOpen.Point3d(12.065046618779022, 0.53811240787984904, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint99, viewCenter99)
    
    scaleAboutPoint100 = NXOpen.Point3d(-15.01050400927792, -0.6726405098496846, 0.0)
    viewCenter100 = NXOpen.Point3d(15.010504009278939, 0.67264050984979318, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(-18.763130011597525, -0.84080063731212074, 0.0)
    viewCenter101 = NXOpen.Point3d(18.763130011598552, 0.84080063731223387, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(-23.453912514497031, -0.94036913383593301, 0.0)
    viewCenter102 = NXOpen.Point3d(23.453912514498061, 0.94036913383603671, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(-26.689888651520864, 6.1538862434855499, 0.0)
    viewCenter103 = NXOpen.Point3d(26.689888651521901, -6.1538862434854558, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(-21.351910921216589, 4.9231089947884499, 0.0)
    viewCenter104 = NXOpen.Point3d(21.351910921217616, -4.9231089947883557, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(-25.489535110094931, 8.009732387026574, 0.0)
    viewCenter105 = NXOpen.Point3d(25.489535110095954, -8.0097323870264603, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(-19.966802502907584, 5.6997432676741768, 0.0)
    viewCenter106 = NXOpen.Point3d(19.966802502908607, -5.6997432676740623, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(-15.746868356902898, 3.8234302665143742, 0.0)
    viewCenter107 = NXOpen.Point3d(15.746868356903923, -3.8234302665142583, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint107, viewCenter107)
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder12 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects27 = [None] * 1 
    dragobjects27[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects27[0].Geometry = line16
    dragobjects27[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects27[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects27)
    
    sketchDragGeometryBuilder12.SplineLinearScale = False
    
    foundrelations41 = sketchDragGeometryBuilder12.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects28 = [None] * 1 
    dragobjects28[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects28[0].Geometry = line16
    dragobjects28[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects28[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects28)
    
    foundrelations42 = sketchDragGeometryBuilder12.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects29 = [None] * 1 
    dragobjects29[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects29[0].Geometry = line16
    dragobjects29[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects29[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects29)
    
    foundrelations43 = sketchDragGeometryBuilder12.FindRelations()
    
    sketchDragGeometryBuilder12.Destroy()
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences12 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences12 = dimensionPreferences12.GetNarrowDimensionPreferences()
    
    option12 = narrowDimensionPreferences12.DimensionDisplayOption
    
    sketchLinearDimensionBuilder12 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder12 = sketchLinearDimensionBuilder12.Driving
    
    drivingValueBuilder12.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder12 = sketchLinearDimensionBuilder12.Measurement
    
    dimensionMeasurementBuilder12.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject23 = sketchLinearDimensionBuilder12.FirstAssociativity
    
    selectNXObject24 = sketchLinearDimensionBuilder12.SecondAssociativity
    
    point1_57 = NXOpen.Point3d(10.0, 65.963009384399783, 0.0)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject23.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line16, NXOpen.View.Null, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    line21 = theSession.ActiveSketch.FindObject("Curve Included Curve13")
    point1_58 = NXOpen.Point3d(0.0, 120.0, 0.0)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject24.SetValue(NXOpen.InferSnapType.SnapType.Start, line21, NXOpen.View.Null, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    originBuilder12 = sketchLinearDimensionBuilder12.Origin
    
    origin41 = NXOpen.Point3d(5.0, 65.736435738976724, 0.0)
    originBuilder12.OriginPoint = origin41
    
    originBuilder12.SetInferRelativeToGeometry(True)
    
    nXObject59 = sketchLinearDimensionBuilder12.Commit()
    
    perpendicularDimension5 = nXObject59
    perpendicularDimension5.IsOriginCentered = True
    
    sketchLinearDimensionBuilder12.Destroy()
    
    narrowDimensionPreferences12.Dispose()
    dimensionPreferences12.Dispose()
    sketchFindMovableObjectsBuilder30 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject60 = sketchFindMovableObjectsBuilder30.Commit()
    
    sketchFindMovableObjectsBuilder30.Destroy()
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder13 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension5)
    
    selectNXObjectList15 = sketchEditDimensionValueBuilder13.ExtraGeometries
    
    foundrelations44 = sketchEditDimensionValueBuilder13.FindRelations()
    
    sketchHelpedDimensionalConstraint12 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line18] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line4] StartVertex]")
    sketchHelpedDimensionalConstraint12.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId138, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId138, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint12.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId139, None)
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder13.DimValue = 4.0
    
    nXObject61 = sketchEditDimensionValueBuilder13.Commit()
    
    theSession.SetUndoMarkName(markId140, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId140, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId138, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint12.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId142, None)
    
    theSession.SetUndoMarkName(markId138, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder13.Destroy()
    
    theSession.DeleteUndoMark(markId141, None)
    
    theSession.SetUndoMarkVisibility(markId138, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId140, None)
    
    theSession.DeleteUndoMark(markId138, None)
    
    sketchFindMovableObjectsBuilder31 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject62 = sketchFindMovableObjectsBuilder31.Commit()
    
    sketchFindMovableObjectsBuilder31.Destroy()
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder13 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects30 = [None] * 1 
    dragobjects30[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects30[0].Geometry = line19
    dragobjects30[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects30[0].PointIndex = 0
    sketchDragGeometryBuilder13.SetDragGeometry(dragobjects30)
    
    sketchDragGeometryBuilder13.SplineLinearScale = False
    
    foundrelations45 = sketchDragGeometryBuilder13.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects31 = [None] * 1 
    dragobjects31[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects31[0].Geometry = line19
    dragobjects31[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects31[0].PointIndex = 0
    sketchDragGeometryBuilder13.SetDragGeometry(dragobjects31)
    
    foundrelations46 = sketchDragGeometryBuilder13.FindRelations()
    
    sketchDragGeometryBuilder13.Destroy()
    
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences13 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences13 = dimensionPreferences13.GetNarrowDimensionPreferences()
    
    option13 = narrowDimensionPreferences13.DimensionDisplayOption
    
    sketchLinearDimensionBuilder13 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder13 = sketchLinearDimensionBuilder13.Driving
    
    drivingValueBuilder13.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject25 = sketchLinearDimensionBuilder13.FirstAssociativity
    
    selectNXObject26 = sketchLinearDimensionBuilder13.SecondAssociativity
    
    point1_61 = NXOpen.Point3d(19.0, 60.600000000000001, 0.0)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject25.SetValue(NXOpen.InferSnapType.SnapType.Start, line19, NXOpen.View.Null, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    point1_62 = NXOpen.Point3d(4.0, 60.600000000000001, 0.0)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject26.SetValue(NXOpen.InferSnapType.SnapType.End, line19, NXOpen.View.Null, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    dimensionMeasurementBuilder13 = sketchLinearDimensionBuilder13.Measurement
    
    dimensionMeasurementBuilder13.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder13 = sketchLinearDimensionBuilder13.Origin
    
    origin43 = NXOpen.Point3d(11.5, 58.394989004147895, 0.0)
    originBuilder13.OriginPoint = origin43
    
    originBuilder13.SetInferRelativeToGeometry(True)
    
    nXObject63 = sketchLinearDimensionBuilder13.Commit()
    
    horizontalDimension4 = nXObject63
    horizontalDimension4.IsOriginCentered = True
    
    sketchLinearDimensionBuilder13.Destroy()
    
    narrowDimensionPreferences13.Dispose()
    dimensionPreferences13.Dispose()
    sketchFindMovableObjectsBuilder32 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject64 = sketchFindMovableObjectsBuilder32.Commit()
    
    sketchFindMovableObjectsBuilder32.Destroy()
    
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder14 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension4)
    
    selectNXObjectList16 = sketchEditDimensionValueBuilder14.ExtraGeometries
    
    foundrelations47 = sketchEditDimensionValueBuilder14.FindRelations()
    
    sketchHelpedDimensionalConstraint13 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line21] StartVertex] [[Curve Line21] EndVertex]")
    sketchHelpedDimensionalConstraint13.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId146, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId146, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint13.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId147, None)
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder14.DimValue = 6.0
    
    nXObject65 = sketchEditDimensionValueBuilder14.Commit()
    
    theSession.SetUndoMarkName(markId148, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId148, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId146, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint13.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId150, None)
    
    theSession.SetUndoMarkName(markId146, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder14.Destroy()
    
    theSession.DeleteUndoMark(markId149, None)
    
    theSession.SetUndoMarkVisibility(markId146, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId148, None)
    
    theSession.DeleteUndoMark(markId146, None)
    
    sketchFindMovableObjectsBuilder33 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject66 = sketchFindMovableObjectsBuilder33.Commit()
    
    sketchFindMovableObjectsBuilder33.Destroy()
    
    scaleAboutPoint108 = NXOpen.Point3d(-6.6612651754377632, -3.1493736713806304, 0.0)
    viewCenter108 = NXOpen.Point3d(6.6612651754387873, 3.1493736713807308, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(-5.2202567905470332, -2.5194989371044882, 0.0)
    viewCenter109 = NXOpen.Point3d(5.2202567905480599, 2.5194989371045966, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(-4.1762054324375262, -2.0155991496835735, 0.0)
    viewCenter110 = NXOpen.Point3d(4.1762054324385476, 2.0155991496836947, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(-3.2945620633672745, -1.728485026203463, 0.0)
    viewCenter111 = NXOpen.Point3d(3.2945620633682933, 1.7284850262035776, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(-4.1182025792092221, -2.2186091359826539, 0.0)
    viewCenter112 = NXOpen.Point3d(4.1182025792102435, 2.21860913598276, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(-5.1477532240116597, -2.8095132032460155, 0.0)
    viewCenter113 = NXOpen.Point3d(5.1477532240126731, 2.8095132032461296, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(-6.4346915300146934, -3.6025209622267651, 0.0)
    viewCenter114 = NXOpen.Point3d(6.4346915300157175, 3.602520962226881, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint114, viewCenter114)
    
    scaleAboutPoint115 = NXOpen.Point3d(-8.0433644125184962, -4.5031512027834699, 0.0)
    viewCenter115 = NXOpen.Point3d(8.0433644125195194, 4.5031512027835863, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(-9.983401251453536, -4.9917006257269705, 0.0)
    viewCenter116 = NXOpen.Point3d(9.9834012514545556, 4.9917006257270788, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(-12.479251564317048, -6.2396257821587193, 0.0)
    viewCenter117 = NXOpen.Point3d(12.479251564318073, 6.2396257821588401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(-15.599064455396432, -7.7995322276984194, 0.0)
    viewCenter118 = NXOpen.Point3d(15.59906445539746, 7.7995322276985419, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(-19.498830569245669, -9.7494152846230353, 0.0)
    viewCenter119 = NXOpen.Point3d(19.498830569246707, 9.749415284623165, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(-24.200676238425608, -12.186769105778806, 0.0)
    viewCenter120 = NXOpen.Point3d(24.200676238426627, 12.186769105778923, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint120, viewCenter120)
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder14 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects32 = [None] * 1 
    dragobjects32[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects32[0].Geometry = line19
    dragobjects32[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects32[0].PointIndex = 0
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects32)
    
    sketchDragGeometryBuilder14.SplineLinearScale = False
    
    foundrelations48 = sketchDragGeometryBuilder14.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects33 = [None] * 1 
    dragobjects33[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects33[0].Geometry = line19
    dragobjects33[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects33[0].PointIndex = 0
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects33)
    
    foundrelations49 = sketchDragGeometryBuilder14.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects34 = [None] * 1 
    dragobjects34[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects34[0].Geometry = line19
    dragobjects34[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects34[0].PointIndex = 0
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects34)
    
    foundrelations50 = sketchDragGeometryBuilder14.FindRelations()
    
    sketchDragGeometryBuilder14.Destroy()
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences14 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences14 = dimensionPreferences14.GetNarrowDimensionPreferences()
    
    option14 = narrowDimensionPreferences14.DimensionDisplayOption
    
    sketchLinearDimensionBuilder14 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder14 = sketchLinearDimensionBuilder14.Driving
    
    drivingValueBuilder14.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder14 = sketchLinearDimensionBuilder14.Measurement
    
    dimensionMeasurementBuilder14.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject27 = sketchLinearDimensionBuilder14.FirstAssociativity
    
    selectNXObject28 = sketchLinearDimensionBuilder14.SecondAssociativity
    
    point1_65 = NXOpen.Point3d(8.3355164249461708, 60.600000000000001, 0.0)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject27.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line19, NXOpen.View.Null, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    line22 = theSession.ActiveSketch.FindObject("Curve Included Curve14")
    point1_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject28.SetValue(NXOpen.InferSnapType.SnapType.Start, line22, NXOpen.View.Null, point1_66, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_66)
    
    originBuilder14 = sketchLinearDimensionBuilder14.Origin
    
    origin45 = NXOpen.Point3d(14.601762950967213, 30.300000000000001, 0.0)
    originBuilder14.OriginPoint = origin45
    
    originBuilder14.SetInferRelativeToGeometry(True)
    
    nXObject67 = sketchLinearDimensionBuilder14.Commit()
    
    perpendicularDimension6 = nXObject67
    perpendicularDimension6.IsOriginCentered = True
    
    sketchLinearDimensionBuilder14.Destroy()
    
    narrowDimensionPreferences14.Dispose()
    dimensionPreferences14.Dispose()
    sketchFindMovableObjectsBuilder34 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject68 = sketchFindMovableObjectsBuilder34.Commit()
    
    sketchFindMovableObjectsBuilder34.Destroy()
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder15 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension6)
    
    selectNXObjectList17 = sketchEditDimensionValueBuilder15.ExtraGeometries
    
    foundrelations51 = sketchEditDimensionValueBuilder15.FindRelations()
    
    sketchHelpedDimensionalConstraint14 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line21] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line1] StartVertex]")
    sketchHelpedDimensionalConstraint14.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId154, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId154, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint14.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId155, None)
    
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder15.DimValue = 60.100000000000001
    
    nXObject69 = sketchEditDimensionValueBuilder15.Commit()
    
    theSession.SetUndoMarkName(markId156, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId156, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId154, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint14.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId158, None)
    
    theSession.SetUndoMarkName(markId154, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder15.Destroy()
    
    theSession.DeleteUndoMark(markId157, None)
    
    theSession.SetUndoMarkVisibility(markId154, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId156, None)
    
    theSession.DeleteUndoMark(markId154, None)
    
    sketchFindMovableObjectsBuilder35 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject70 = sketchFindMovableObjectsBuilder35.Commit()
    
    sketchFindMovableObjectsBuilder35.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder2 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder2.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject71 = sketchWorkRegionBuilder2.Commit()
    
    sketchWorkRegionBuilder2.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies28)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies29)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId160, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions3 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions3.SetSelectedFromInactive(False)
    
    curves3 = [NXOpen.ICurve.Null] * 16 
    curves3[0] = line5
    curves3[1] = line6
    curves3[2] = line7
    curves3[3] = line8
    curves3[4] = line9
    curves3[5] = line10
    curves3[6] = line11
    curves3[7] = line12
    curves3[8] = line13
    curves3[9] = line14
    curves3[10] = line15
    curves3[11] = line16
    curves3[12] = line17
    curves3[13] = line18
    curves3[14] = line19
    curves3[15] = line20
    seedPoint3 = NXOpen.Point3d(7.4414380000000016, 60.960359500000003, 0.0)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch2, curves3, seedPoint3, 0.01, selectionIntentRuleOptions3)
    
    selectionIntentRuleOptions3.Dispose()
    selectionIntentRuleOptions4 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions4.SetSelectedFromInactive(False)
    
    curves4 = [NXOpen.ICurve.Null] * 16 
    curves4[0] = line5
    curves4[1] = line6
    curves4[2] = line7
    curves4[3] = line8
    curves4[4] = line9
    curves4[5] = line10
    curves4[6] = line11
    curves4[7] = line12
    curves4[8] = line13
    curves4[9] = line14
    curves4[10] = line15
    curves4[11] = line16
    curves4[12] = line17
    curves4[13] = line18
    curves4[14] = line19
    curves4[15] = line20
    seedPoint4 = NXOpen.Point3d(65.360359500000001, 7.4414380000000016, 0.0)
    regionBoundaryRule4 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch2, curves4, seedPoint4, 0.01, selectionIntentRuleOptions4)
    
    selectionIntentRuleOptions4.Dispose()
    selectionIntentRuleOptions5 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions5.SetSelectedFromInactive(False)
    
    curves5 = [NXOpen.ICurve.Null] * 16 
    curves5[0] = line5
    curves5[1] = line6
    curves5[2] = line7
    curves5[3] = line8
    curves5[4] = line9
    curves5[5] = line10
    curves5[6] = line11
    curves5[7] = line12
    curves5[8] = line13
    curves5[9] = line14
    curves5[10] = line15
    curves5[11] = line16
    curves5[12] = line17
    curves5[13] = line18
    curves5[14] = line19
    curves5[15] = line20
    seedPoint5 = NXOpen.Point3d(60.960359500000003, 7.4414380000000016, 0.0)
    regionBoundaryRule5 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch2, curves5, seedPoint5, 0.01, selectionIntentRuleOptions5)
    
    selectionIntentRuleOptions5.Dispose()
    selectionIntentRuleOptions6 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions6.SetSelectedFromInactive(False)
    
    curves6 = [NXOpen.ICurve.Null] * 16 
    curves6[0] = line5
    curves6[1] = line6
    curves6[2] = line7
    curves6[3] = line8
    curves6[4] = line9
    curves6[5] = line10
    curves6[6] = line11
    curves6[7] = line12
    curves6[8] = line13
    curves6[9] = line14
    curves6[10] = line15
    curves6[11] = line16
    curves6[12] = line17
    curves6[13] = line18
    curves6[14] = line19
    curves6[15] = line20
    seedPoint6 = NXOpen.Point3d(7.4414380000000016, 65.360359500000001, 0.0)
    regionBoundaryRule6 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch2, curves6, seedPoint6, 0.01, selectionIntentRuleOptions6)
    
    selectionIntentRuleOptions6.Dispose()
    section4.AllowSelfIntersection(True)
    
    section4.AllowDegenerateCurves(False)
    
    rules3 = [None] * 4 
    rules3[0] = regionBoundaryRule3
    rules3[1] = regionBoundaryRule4
    rules3[2] = regionBoundaryRule5
    rules3[3] = regionBoundaryRule6
    helpPoint3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section4.AddToSection(rules3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId161, None)
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId163, None)
    
    direction7 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction7
    
    targetBodies30 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies30[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies30)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies31 = [NXOpen.Body.Null] * 1 
    targetBodies31[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies31)
    
    theSession.DeleteUndoMark(markId162, None)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies32 = [NXOpen.Body.Null] * 1 
    targetBodies32[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies32)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies33 = [NXOpen.Body.Null] * 1 
    targetBodies33[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies33)
    
    targetBodies34 = []
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies34)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies35 = [NXOpen.Body.Null] * 1 
    targetBodies35[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies35)
    
    targetBodies36 = []
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies36)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("20")
    
    targetBodies37 = [NXOpen.Body.Null] * 1 
    targetBodies37[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies37)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies38 = [NXOpen.Body.Null] * 1 
    targetBodies38[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies38)
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId164, None)
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId165, None)
    
    theSession.SetUndoMarkName(markId160, "Extrude")
    
    expression11 = extrudeBuilder4.Limits.StartExtend.Value
    expression12 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression10)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.87772029393058826
    rotMatrix1.Xy = 0.47660474345502407
    rotMatrix1.Xz = 0.049547998330621117
    rotMatrix1.Yx = -0.21729649829368397
    rotMatrix1.Yy = 0.30373716630138581
    rotMatrix1.Yz = 0.92764538787001283
    rotMatrix1.Zx = 0.42707062349417574
    rotMatrix1.Zy = -0.82497978903932767
    rotMatrix1.Zz = 0.37016081670663287
    translation1 = NXOpen.Point3d(-76.884843368130191, -17.849682087620575, 31.956602857975344)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.78366956139927668)
    
    scaleAboutPoint121 = NXOpen.Point3d(-18.231536228724668, -3.2073998920903968, 0.0)
    viewCenter121 = NXOpen.Point3d(18.231536228725474, 3.2073998920906273, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(-23.633472889087685, -5.6973550714764771, 0.0)
    viewCenter122 = NXOpen.Point3d(23.633472889088477, 5.697355071476693, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(-29.541841111359691, -8.176759593322771, 0.0)
    viewCenter123 = NXOpen.Point3d(29.541841111360501, 8.1767595933229948, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(-33.630220908021116, -18.793358742717789, 0.0)
    viewCenter124 = NXOpen.Point3d(33.630220908021847, 18.793358742718013, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(-26.904176726416889, -15.034686994174185, 0.0)
    viewCenter125 = NXOpen.Point3d(26.904176726417518, 15.034686994174454, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(-21.101315079542573, -11.605723293748444, 0.0)
    viewCenter126 = NXOpen.Point3d(21.101315079543291, 11.605723293748731, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(-16.5434310223613, -9.2845786349987254, 0.0)
    viewCenter127 = NXOpen.Point3d(16.543431022361993, 9.2845786349990131, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(-12.964647984870837, -7.4276629079989558, 0.0)
    viewCenter128 = NXOpen.Point3d(12.964647984871528, 7.4276629079992329, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(-6.0501690596062163, -4.429588061497487, 0.0)
    viewCenter129 = NXOpen.Point3d(6.0501690596068789, 4.4295880614977632, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(-4.8401352476848993, -3.5436704491979603, 0.0)
    viewCenter130 = NXOpen.Point3d(4.840135247685577, 3.5436704491982547, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(-3.7338186196425527, -2.6966467808530483, 0.0)
    viewCenter131 = NXOpen.Point3d(3.7338186196432366, 2.6966467808533432, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.72396383679684728
    rotMatrix2.Xy = 0.68969324306621049
    rotMatrix2.Xz = -0.014127755632067196
    rotMatrix2.Yx = -0.073493468970993681
    rotMatrix2.Yy = 0.097476236871189892
    rotMatrix2.Yz = 0.9925205757383776
    rotMatrix2.Zx = 0.6859118551453941
    rotMatrix2.Zy = -0.71751070634119696
    rotMatrix2.Zz = 0.12125721940057559
    translation2 = NXOpen.Point3d(-72.506138004813508, -4.4581554260388199, 12.467019970074965)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 2.3915697064186907)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin46, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane7
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder3 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId168, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder3.UseWorkPartOrigin = False
    
    coordinates5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point7 = workPart.Points.CreatePoint(coordinates5)
    
    origin47 = NXOpen.Point3d(58.123546702014551, 0.0, 8.1235467020145524)
    matrix5 = NXOpen.Matrix3x3()
    
    matrix5.Xx = 1.0
    matrix5.Xy = 0.0
    matrix5.Xz = 0.0
    matrix5.Yx = -0.0
    matrix5.Yy = 0.0
    matrix5.Yz = 1.0
    matrix5.Zx = 0.0
    matrix5.Zy = -1.0
    matrix5.Zz = 0.0
    plane8 = workPart.Planes.CreateFixedTypePlane(origin47, matrix5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point8 = workPart.Points.CreatePoint(coordinates6)
    
    origin48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector5 = NXOpen.Vector3d(0.0, -1.0, 0.0)
    direction8 = workPart.Directions.CreateDirection(origin48, vector5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector6 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction9 = workPart.Directions.CreateDirection(origin49, vector6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix6 = NXOpen.Matrix3x3()
    
    matrix6.Xx = 1.0
    matrix6.Xy = 0.0
    matrix6.Xz = 0.0
    matrix6.Yx = -0.0
    matrix6.Yy = 0.0
    matrix6.Yz = 1.0
    matrix6.Zx = 0.0
    matrix6.Zy = -1.0
    matrix6.Zz = 0.0
    plane9 = workPart.Planes.CreateFixedTypePlane(origin50, matrix6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane9, direction9, point8, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder3.CoordinateSystem = cartesianCoordinateSystem3
    
    simpleSketchInPlaceBuilder3.HorizontalReference.Value = datumAxis1
    
    point9 = simpleSketchInPlaceBuilder3.SketchOrigin
    
    simpleSketchInPlaceBuilder3.SketchOrigin = point9
    
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId169, None)
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject72 = simpleSketchInPlaceBuilder3.Commit()
    
    sketch3 = nXObject72
    feature5 = sketch3.Feature
    
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId171)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder36 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject73 = sketchFindMovableObjectsBuilder36.Commit()
    
    sketchFindMovableObjectsBuilder36.Destroy()
    
    theSession.DeleteUndoMark(markId170, None)
    
    theSession.SetUndoMarkName(markId168, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    simpleSketchInPlaceBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId167, None, True)
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_002")
    
    scaleAboutPoint132 = NXOpen.Point3d(14.935274478571916, 19.415856822143201, 0.0)
    viewCenter132 = NXOpen.Point3d(-14.935274478571218, -19.415856822142899, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(18.669093098214823, 24.269821027678951, 0.0)
    viewCenter133 = NXOpen.Point3d(-18.669093098214116, -24.26982102767867, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(23.336366372768424, 30.337276284598673, 0.0)
    viewCenter134 = NXOpen.Point3d(-23.336366372767685, -30.337276284598349, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(29.170457965960438, 37.921595355748288, 0.0)
    viewCenter135 = NXOpen.Point3d(-29.170457965959773, -37.921595355747975, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint135, viewCenter135)
    
    scaleAboutPoint136 = NXOpen.Point3d(38.62384712159561, 47.942187860721603, 0.0)
    viewCenter136 = NXOpen.Point3d(-38.62384712159492, -47.942187860721305, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(31.115155163691124, 38.569827754991834, 0.0)
    viewCenter137 = NXOpen.Point3d(-31.115155163690442, -38.569827754991543, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(25.237848077216167, 31.028724177125103, 0.0)
    viewCenter138 = NXOpen.Point3d(-25.237848077215492, -31.028724177124822, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint138, viewCenter138)
    
    scaleAboutPoint139 = NXOpen.Point3d(20.328568040278324, 24.822979341700115, 0.0)
    viewCenter139 = NXOpen.Point3d(-20.328568040277617, -24.822979341699831, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(16.484117757831193, 19.858383473360124, 0.0)
    viewCenter140 = NXOpen.Point3d(-16.484117757830475, -19.85838347335984, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(11.771208922370832, 15.090158806497643, 0.0)
    viewCenter141 = NXOpen.Point3d(-11.771208922370121, -15.090158806497357, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint141, viewCenter141)
    
    scaleAboutPoint142 = NXOpen.Point3d(9.3461628737020312, 12.072127045198139, 0.0)
    viewCenter142 = NXOpen.Point3d(-9.346162873701326, -12.072127045197854, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint142, viewCenter142)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint143 = NXOpen.Point3d(3.3986046813464208, 5.4660891958317315, 0.0)
    viewCenter143 = NXOpen.Point3d(-3.3986046813457063, -5.466089195831441, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(2.9907721195848915, 4.0556682530731178, 0.0)
    viewCenter144 = NXOpen.Point3d(-2.9907721195841805, -4.0556682530728239, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint144, viewCenter144)
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId174, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(6.8000000000000007, 0.0, 17.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 1.5943348319142732, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder37 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject74 = sketchFindMovableObjectsBuilder37.Commit()
    
    sketchFindMovableObjectsBuilder37.Destroy()
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder15 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects35 = [None] * 1 
    dragobjects35[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects35[0].Geometry = arc1
    dragobjects35[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects35[0].PointIndex = 0
    sketchDragGeometryBuilder15.SetDragGeometry(dragobjects35)
    
    sketchDragGeometryBuilder15.SplineLinearScale = False
    
    foundrelations52 = sketchDragGeometryBuilder15.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects36 = [None] * 1 
    dragobjects36[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects36[0].Geometry = arc1
    dragobjects36[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects36[0].PointIndex = 0
    sketchDragGeometryBuilder15.SetDragGeometry(dragobjects36)
    
    foundrelations53 = sketchDragGeometryBuilder15.FindRelations()
    
    sketchDragGeometryBuilder15.Destroy()
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences15 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences15 = dimensionPreferences15.GetNarrowDimensionPreferences()
    
    option15 = narrowDimensionPreferences15.DimensionDisplayOption
    
    sketchRadialDimensionBuilder1 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder15 = sketchRadialDimensionBuilder1.Driving
    
    drivingValueBuilder15.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject29 = sketchRadialDimensionBuilder1.FirstAssociativity
    
    point1_68 = NXOpen.Point3d(6.8000000000000007, 0.0, 17.0)
    point2_68 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject29.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, NXOpen.View.Null, point1_68, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_68)
    
    dimensionMeasurementBuilder15 = sketchRadialDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder15.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder15 = sketchRadialDimensionBuilder1.Origin
    
    origin52 = NXOpen.Point3d(9.8432041363551122, 0.0, 18.518679564204444)
    originBuilder15.OriginPoint = origin52
    
    originBuilder15.SetInferRelativeToGeometry(True)
    
    nXObject75 = sketchRadialDimensionBuilder1.Commit()
    
    sketchRadialDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences15.Dispose()
    dimensionPreferences15.Dispose()
    sketchFindMovableObjectsBuilder38 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject76 = sketchFindMovableObjectsBuilder38.Commit()
    
    sketchFindMovableObjectsBuilder38.Destroy()
    
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension1 = nXObject75
    sketchEditDimensionValueBuilder16 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension1)
    
    selectNXObjectList18 = sketchEditDimensionValueBuilder16.ExtraGeometries
    
    foundrelations54 = sketchEditDimensionValueBuilder16.FindRelations()
    
    sketchDimensionalConstraint1 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc1]")
    sketchDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId178, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId178, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId179, None)
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder16.DimValue = 3.0
    
    theSession.ActiveSketch.Scale(0.94083122941773822)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin53 = NXOpen.Point3d(9.2607938490167463, 0.0, 17.422952061583612)
    diameterDimension1.AnnotationOrigin = origin53
    
    sketchEditDimensionValueBuilder16.RestoreOperation()
    
    sketchEditDimensionValueBuilder16.LoadExtraGeometry()
    
    selectNXObjectList19 = sketchEditDimensionValueBuilder16.ExtraGeometries
    
    foundrelations55 = sketchEditDimensionValueBuilder16.FindRelations()
    
    nXObject77 = sketchEditDimensionValueBuilder16.Commit()
    
    theSession.SetUndoMarkName(markId180, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId180, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId178, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId182, None)
    
    theSession.SetUndoMarkName(markId178, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder16.Destroy()
    
    theSession.DeleteUndoMark(markId181, None)
    
    theSession.SetUndoMarkVisibility(markId178, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId180, None)
    
    theSession.DeleteUndoMark(markId178, None)
    
    sketchFindMovableObjectsBuilder39 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject78 = sketchFindMovableObjectsBuilder39.Commit()
    
    sketchFindMovableObjectsBuilder39.Destroy()
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder16 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects37 = [None] * 1 
    dragobjects37[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects37[0].Geometry = arc1
    dragobjects37[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects37[0].PointIndex = 0
    sketchDragGeometryBuilder16.SetDragGeometry(dragobjects37)
    
    sketchDragGeometryBuilder16.SplineLinearScale = False
    
    foundrelations56 = sketchDragGeometryBuilder16.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects38 = [None] * 1 
    dragobjects38[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects38[0].Geometry = arc1
    dragobjects38[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects38[0].PointIndex = -1475379168
    sketchDragGeometryBuilder16.SetDragGeometry(dragobjects38)
    
    foundrelations57 = sketchDragGeometryBuilder16.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects39 = [None] * 1 
    dragobjects39[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects39[0].Geometry = arc1
    dragobjects39[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects39[0].PointIndex = -1475379088
    sketchDragGeometryBuilder16.SetDragGeometry(dragobjects39)
    
    foundrelations58 = sketchDragGeometryBuilder16.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects40 = [None] * 1 
    dragobjects40[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects40[0].Geometry = arc1
    dragobjects40[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects40[0].PointIndex = -1475378416
    sketchDragGeometryBuilder16.SetDragGeometry(dragobjects40)
    
    foundrelations59 = sketchDragGeometryBuilder16.FindRelations()
    
    sketchDragGeometryBuilder16.Destroy()
    
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences16 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences16 = dimensionPreferences16.GetNarrowDimensionPreferences()
    
    option16 = narrowDimensionPreferences16.DimensionDisplayOption
    
    sketchLinearDimensionBuilder15 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder16 = sketchLinearDimensionBuilder15.Driving
    
    drivingValueBuilder16.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder16 = sketchLinearDimensionBuilder15.Measurement
    
    dimensionMeasurementBuilder16.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject30 = sketchLinearDimensionBuilder15.FirstAssociativity
    
    selectNXObject31 = sketchLinearDimensionBuilder15.SecondAssociativity
    
    extrude2 = feature4
    edge2 = extrude2.FindObject("EDGE * 190 * 330 {(4,60.1,20)(7,60.1,20)(10,60.1,20) EXTRUDE(2)}")
    point1_71 = NXOpen.Point3d(6.5612735128046218, 0.0, 20.0)
    point2_71 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject30.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge2, NXOpen.View.Null, point1_71, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_71)
    
    point1_72 = NXOpen.Point3d(6.3976523600406203, 0.0, 15.994130900101549)
    point2_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject31.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_72, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_72)
    
    originBuilder16 = sketchLinearDimensionBuilder15.Origin
    
    origin55 = NXOpen.Point3d(6.3976523600406203, 0.0, 17.997065450050776)
    originBuilder16.OriginPoint = origin55
    
    originBuilder16.SetInferRelativeToGeometry(True)
    
    nXObject79 = sketchLinearDimensionBuilder15.Commit()
    
    perpendicularDimension7 = nXObject79
    perpendicularDimension7.IsOriginCentered = True
    
    sketchLinearDimensionBuilder15.Destroy()
    
    narrowDimensionPreferences16.Dispose()
    dimensionPreferences16.Dispose()
    sketchFindMovableObjectsBuilder40 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject80 = sketchFindMovableObjectsBuilder40.Commit()
    
    sketchFindMovableObjectsBuilder40.Destroy()
    
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder17 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension7)
    
    selectNXObjectList20 = sketchEditDimensionValueBuilder17.ExtraGeometries
    
    foundrelations60 = sketchEditDimensionValueBuilder17.FindRelations()
    
    sketchHelpedDimensionalConstraint15 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(4)|EDGE * 190 * 330 {(4,60.1,20)(7,60.1,20)(10,60.1,20) EXTRUDE(2)}] [[Curve Arc1] ArcCenter]")
    sketchHelpedDimensionalConstraint15.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId186, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId186, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint15.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId187, None)
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder17.DimValue = 4.0
    
    nXObject81 = sketchEditDimensionValueBuilder17.Commit()
    
    theSession.SetUndoMarkName(markId188, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId188, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId186, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint15.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId190, None)
    
    theSession.SetUndoMarkName(markId186, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder17.Destroy()
    
    theSession.DeleteUndoMark(markId189, None)
    
    theSession.SetUndoMarkVisibility(markId186, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId188, None)
    
    theSession.DeleteUndoMark(markId186, None)
    
    sketchFindMovableObjectsBuilder41 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject82 = sketchFindMovableObjectsBuilder41.Commit()
    
    sketchFindMovableObjectsBuilder41.Destroy()
    
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder17 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects41 = [None] * 1 
    dragobjects41[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects41[0].Geometry = arc1
    dragobjects41[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects41[0].PointIndex = -1475378464
    sketchDragGeometryBuilder17.SetDragGeometry(dragobjects41)
    
    sketchDragGeometryBuilder17.SplineLinearScale = False
    
    foundrelations61 = sketchDragGeometryBuilder17.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects42 = [None] * 1 
    dragobjects42[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects42[0].Geometry = arc1
    dragobjects42[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects42[0].PointIndex = -1475378752
    sketchDragGeometryBuilder17.SetDragGeometry(dragobjects42)
    
    foundrelations62 = sketchDragGeometryBuilder17.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects43 = [None] * 1 
    dragobjects43[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects43[0].Geometry = arc1
    dragobjects43[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects43[0].PointIndex = -1475379168
    sketchDragGeometryBuilder17.SetDragGeometry(dragobjects43)
    
    foundrelations63 = sketchDragGeometryBuilder17.FindRelations()
    
    sketchDragGeometryBuilder17.Destroy()
    
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences17 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences17 = dimensionPreferences17.GetNarrowDimensionPreferences()
    
    option17 = narrowDimensionPreferences17.DimensionDisplayOption
    
    sketchLinearDimensionBuilder16 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder17 = sketchLinearDimensionBuilder16.Driving
    
    drivingValueBuilder17.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder17 = sketchLinearDimensionBuilder16.Measurement
    
    dimensionMeasurementBuilder17.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject32 = sketchLinearDimensionBuilder16.FirstAssociativity
    
    selectNXObject33 = sketchLinearDimensionBuilder16.SecondAssociativity
    
    edge4 = extrude2.FindObject("EDGE * 330 * 340 {(10,60.1,20)(10,60.1,12.5)(10,60.1,5) EXTRUDE(2)}")
    point1_75 = NXOpen.Point3d(10.0, 0.0, 15.692158510434492)
    point2_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject32.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge4, NXOpen.View.Null, point1_75, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_75)
    
    point1_76 = NXOpen.Point3d(6.3976523600406212, 0.0, 16.0)
    point2_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject33.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_76, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_76)
    
    originBuilder17 = sketchLinearDimensionBuilder16.Origin
    
    origin57 = NXOpen.Point3d(8.1988261800203102, 0.0, 16.0)
    originBuilder17.OriginPoint = origin57
    
    originBuilder17.SetInferRelativeToGeometry(True)
    
    nXObject83 = sketchLinearDimensionBuilder16.Commit()
    
    perpendicularDimension8 = nXObject83
    perpendicularDimension8.IsOriginCentered = True
    
    sketchLinearDimensionBuilder16.Destroy()
    
    narrowDimensionPreferences17.Dispose()
    dimensionPreferences17.Dispose()
    sketchFindMovableObjectsBuilder42 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject84 = sketchFindMovableObjectsBuilder42.Commit()
    
    sketchFindMovableObjectsBuilder42.Destroy()
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder18 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension8)
    
    selectNXObjectList21 = sketchEditDimensionValueBuilder18.ExtraGeometries
    
    foundrelations64 = sketchEditDimensionValueBuilder18.FindRelations()
    
    sketchHelpedDimensionalConstraint16 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(4)|EDGE * 330 * 340 {(10,60.1,20)(10,60.1,12.5)(10,60.1,5) EXTRUDE(2)}] [[Curve Arc1] ArcCenter]")
    sketchHelpedDimensionalConstraint16.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId194, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId194, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint16.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId195, None)
    
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder18.DimValue = 3.0
    
    nXObject85 = sketchEditDimensionValueBuilder18.Commit()
    
    theSession.SetUndoMarkName(markId196, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId196, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId194, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint16.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId198, None)
    
    theSession.SetUndoMarkName(markId194, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder18.Destroy()
    
    theSession.DeleteUndoMark(markId197, None)
    
    theSession.SetUndoMarkVisibility(markId194, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId196, None)
    
    theSession.DeleteUndoMark(markId194, None)
    
    sketchFindMovableObjectsBuilder43 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject86 = sketchFindMovableObjectsBuilder43.Commit()
    
    sketchFindMovableObjectsBuilder43.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder3 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder3.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject87 = sketchWorkRegionBuilder3.Commit()
    
    sketchWorkRegionBuilder3.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies39 = [NXOpen.Body.Null] * 1 
    targetBodies39[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies39)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies40 = [NXOpen.Body.Null] * 1 
    targetBodies40[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies40)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId200, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions7 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions7.SetSelectedFromInactive(False)
    
    curves7 = [NXOpen.ICurve.Null] * 1 
    curves7[0] = arc1
    seedPoint7 = NXOpen.Point3d(6.8024474053257693, 0.0, 15.901562967845676)
    regionBoundaryRule7 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch3, curves7, seedPoint7, 0.01, selectionIntentRuleOptions7)
    
    selectionIntentRuleOptions7.Dispose()
    section5.AllowSelfIntersection(True)
    
    section5.AllowDegenerateCurves(False)
    
    rules4 = [None] * 1 
    rules4[0] = regionBoundaryRule7
    helpPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section5.AddToSection(rules4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId201, None)
    
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId203, None)
    
    direction10 = workPart.Directions.CreateDirection(sketch3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction10
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies41 = [NXOpen.Body.Null] * 1 
    targetBodies41[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies41)
    
    targetBodies42 = []
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies42)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies43 = [NXOpen.Body.Null] * 1 
    targetBodies43[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies43)
    
    targetBodies44 = []
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies44)
    
    theSession.DeleteUndoMark(markId202, None)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies45 = [NXOpen.Body.Null] * 1 
    targetBodies45[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies45)
    
    targetBodies46 = []
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies46)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies47 = [NXOpen.Body.Null] * 1 
    targetBodies47[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies47)
    
    targetBodies48 = []
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies48)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies49 = [NXOpen.Body.Null] * 1 
    targetBodies49[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies49)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("100")
    
    scaleAboutPoint145 = NXOpen.Point3d(-36.287185399788385, 11.118482111825658, 0.0)
    viewCenter145 = NXOpen.Point3d(36.287185399789081, -11.118482111825356, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(-25.224019119364975, 7.4787004055663635, 0.0)
    viewCenter146 = NXOpen.Point3d(25.224019119365682, -7.4787004055660615, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint146, viewCenter146)
    
    scaleAboutPoint147 = NXOpen.Point3d(-18.125891633845328, 5.0625048899218967, 0.0)
    viewCenter147 = NXOpen.Point3d(18.125891633846042, -5.062504889921601, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(-14.16085283894159, 3.8800736778702429, 0.0)
    viewCenter148 = NXOpen.Point3d(14.160852838942295, -3.8800736778699436, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(-11.283367542068589, 3.1493736713808382, 0.0)
    viewCenter149 = NXOpen.Point3d(11.283367542069293, -3.1493736713805371, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(-14.104209427585825, 3.9367170892260099, 0.0)
    viewCenter150 = NXOpen.Point3d(14.104209427586531, -3.9367170892257106, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint150, viewCenter150)
    
    scaleAboutPoint151 = NXOpen.Point3d(-17.630261784482364, 4.9208963615324759, 0.0)
    viewCenter151 = NXOpen.Point3d(17.630261784483064, -4.9208963615321801, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint151, viewCenter151)
    
    scaleAboutPoint152 = NXOpen.Point3d(-22.037827230603039, 6.1511204519155642, 0.0)
    viewCenter152 = NXOpen.Point3d(22.037827230603746, -6.1511204519152471, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(-27.989810689470833, 7.4676372392859491, 0.0)
    viewCenter153 = NXOpen.Point3d(27.989810689471529, -7.4676372392856374, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(-35.263842518849202, 9.472836127612684, 0.0)
    viewCenter154 = NXOpen.Point3d(35.263842518849884, -9.472836127612366, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint154, viewCenter154)
    
    scaleAboutPoint155 = NXOpen.Point3d(-44.252665121693219, 11.84104515951581, 0.0)
    viewCenter155 = NXOpen.Point3d(44.252665121693894, -11.841045159515501, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint155, viewCenter155)
    
    scaleAboutPoint156 = NXOpen.Point3d(-56.180141267774673, 15.233461382223755, 0.0)
    viewCenter156 = NXOpen.Point3d(56.180141267775355, -15.23346138222346, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint156, viewCenter156)
    
    scaleAboutPoint157 = NXOpen.Point3d(-70.49527341773657, 19.582020393815974, 0.0)
    viewCenter157 = NXOpen.Point3d(70.495273417737238, -19.58202039381565, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint157, viewCenter157)
    
    scaleAboutPoint158 = NXOpen.Point3d(-119.8554696518033, 70.393987105355237, 0.0)
    viewCenter158 = NXOpen.Point3d(119.855469651804, -70.393987105354952, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint158, viewCenter158)
    
    scaleAboutPoint159 = NXOpen.Point3d(-150.24136336634507, 87.570457580103152, 0.0)
    viewCenter159 = NXOpen.Point3d(150.24136336634578, -87.570457580102868, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint159, viewCenter159)
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("-100")
    
    scaleAboutPoint160 = NXOpen.Point3d(-160.36999460452563, 57.764850030248802, 0.0)
    viewCenter160 = NXOpen.Point3d(160.36999460452637, -57.764850030248581, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint160, viewCenter160)
    
    scaleAboutPoint161 = NXOpen.Point3d(-127.45194308043874, 47.055932627380798, 0.0)
    viewCenter161 = NXOpen.Point3d(127.45194308043946, -47.055932627380514, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint161, viewCenter161)
    
    scaleAboutPoint162 = NXOpen.Point3d(-101.62393342307826, 37.644746101904673, 0.0)
    viewCenter162 = NXOpen.Point3d(101.62393342307894, -37.644746101904389, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(-127.45194308043874, 47.055932627380798, 0.0)
    viewCenter163 = NXOpen.Point3d(127.45194308043946, -47.055932627380514, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint163, viewCenter163)
    
    scaleAboutPoint164 = NXOpen.Point3d(-160.89752748151423, 58.819915784225955, 0.0)
    viewCenter164 = NXOpen.Point3d(160.89752748151494, -58.819915784225685, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint164, viewCenter164)
    
    scaleAboutPoint165 = NXOpen.Point3d(-202.44074154436424, 74.843726922753888, 0.0)
    viewCenter165 = NXOpen.Point3d(202.44074154436498, -74.843726922753547, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint165, viewCenter165)
    
    scaleAboutPoint166 = NXOpen.Point3d(-234.91698428397322, 139.71378538994233, 0.0)
    viewCenter166 = NXOpen.Point3d(234.91698428397387, -139.71378538994196, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint166, viewCenter166)
    
    scaleAboutPoint167 = NXOpen.Point3d(-293.64623035496658, 174.64223173742786, 0.0)
    viewCenter167 = NXOpen.Point3d(293.64623035496726, -174.64223173742752, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint167, viewCenter167)
    
    scaleAboutPoint168 = NXOpen.Point3d(-367.05778794370821, 218.30278967178484, 0.0)
    viewCenter168 = NXOpen.Point3d(367.05778794370889, -218.3027896717843, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint168, viewCenter168)
    
    scaleAboutPoint169 = NXOpen.Point3d(-458.82223492963544, 243.90024067312243, 0.0)
    viewCenter169 = NXOpen.Point3d(458.82223492963601, -243.90024067312189, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint169, viewCenter169)
    
    scaleAboutPoint170 = NXOpen.Point3d(-367.05778794370821, 188.68058222369606, 0.0)
    viewCenter170 = NXOpen.Point3d(367.05778794370889, -188.68058222369552, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint170, viewCenter170)
    
    scaleAboutPoint171 = NXOpen.Point3d(-292.61589270459825, 138.58041397453729, 0.0)
    viewCenter171 = NXOpen.Point3d(292.61589270459899, -138.58041397453675, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint171, viewCenter171)
    
    scaleAboutPoint172 = NXOpen.Point3d(-233.26844404338382, 106.74298057815668, 0.0)
    viewCenter172 = NXOpen.Point3d(233.26844404338465, -106.74298057815611, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint172, viewCenter172)
    
    scaleAboutPoint173 = NXOpen.Point3d(-185.29592304223547, 82.756720077582543, 0.0)
    viewCenter173 = NXOpen.Point3d(185.29592304223644, -82.756720077581988, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint173, viewCenter173)
    
    scaleAboutPoint174 = NXOpen.Point3d(-147.70920555679973, 64.62277743110036, 0.0)
    viewCenter174 = NXOpen.Point3d(147.70920555680064, -64.62277743109982, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint174, viewCenter174)
    
    scaleAboutPoint175 = NXOpen.Point3d(-117.32331184225801, 50.432143040107754, 0.0)
    viewCenter175 = NXOpen.Point3d(117.32331184225887, -50.432143040107249, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint175, viewCenter175)
    
    scaleAboutPoint176 = NXOpen.Point3d(-110.4020804961679, 55.201040248084439, 0.0)
    viewCenter176 = NXOpen.Point3d(110.40208049616882, -55.20104024808392, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint176, viewCenter176)
    
    scaleAboutPoint177 = NXOpen.Point3d(-88.321664396934224, 44.430929031485753, 0.0)
    viewCenter177 = NXOpen.Point3d(88.321664396935148, -44.430929031485242, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint177, viewCenter177)
    
    scaleAboutPoint178 = NXOpen.Point3d(-70.657331517547334, 35.544743225188675, 0.0)
    viewCenter178 = NXOpen.Point3d(70.657331517548172, -35.544743225188142, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint178, viewCenter178)
    
    scaleAboutPoint179 = NXOpen.Point3d(-56.5258652140378, 28.435794580150986, 0.0)
    viewCenter179 = NXOpen.Point3d(56.525865214038582, -28.435794580150439, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint179, viewCenter179)
    
    scaleAboutPoint180 = NXOpen.Point3d(-44.944113014219589, 23.301793978142001, 0.0)
    viewCenter180 = NXOpen.Point3d(44.944113014220363, -23.301793978141468, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint180, viewCenter180)
    
    scaleAboutPoint181 = NXOpen.Point3d(-33.63202549248669, 30.147128114153972, 0.0)
    viewCenter181 = NXOpen.Point3d(33.632025492487465, -30.147128114153432, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint181, viewCenter181)
    
    scaleAboutPoint182 = NXOpen.Point3d(-26.905620393989274, 24.206207821566625, 0.0)
    viewCenter182 = NXOpen.Point3d(26.905620393990034, -24.206207821566075, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint182, viewCenter182)
    
    scaleAboutPoint183 = NXOpen.Point3d(-21.382887786801923, 19.435770521448063, 0.0)
    viewCenter183 = NXOpen.Point3d(21.382887786802709, -19.43577052144752, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint183, viewCenter183)
    
    scaleAboutPoint184 = NXOpen.Point3d(-17.106310229441473, 15.548616417158506, 0.0)
    viewCenter184 = NXOpen.Point3d(17.106310229442236, -15.548616417157955, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint184, viewCenter184)
    
    markId204 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId204, None)
    
    markId205 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    feature6 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId205, None)
    
    theSession.SetUndoMarkName(markId200, "Extrude")
    
    expression16 = extrudeBuilder5.Limits.StartExtend.Value
    expression17 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression15)
    
    scaleAboutPoint185 = NXOpen.Point3d(-11.645885374745454, 2.8321705677886682, 0.0)
    viewCenter185 = NXOpen.Point3d(11.64588537474622, -2.8321705677881042, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint185, viewCenter185)
    
    scaleAboutPoint186 = NXOpen.Point3d(-14.330783073008842, 3.5402132097357675, 0.0)
    viewCenter186 = NXOpen.Point3d(14.330783073009606, -3.5402132097351977, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint186, viewCenter186)
    
    scaleAboutPoint187 = NXOpen.Point3d(-17.913478841261153, 4.4252665121696362, 0.0)
    viewCenter187 = NXOpen.Point3d(17.913478841261913, -4.4252665121690686, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint187, viewCenter187)
    
    scaleAboutPoint188 = NXOpen.Point3d(-22.391848551576537, 5.5315831402119713, 0.0)
    viewCenter188 = NXOpen.Point3d(22.391848551577297, -5.5315831402114126, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint188, viewCenter188)
    
    scaleAboutPoint189 = NXOpen.Point3d(-27.989810689470783, 6.9144789252648886, 0.0)
    viewCenter189 = NXOpen.Point3d(27.989810689471522, -6.9144789252643317, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint189, viewCenter189)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId206 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId207 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId208 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin58, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane10
    
    expression18 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression19 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder4 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId208, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder4.UseWorkPartOrigin = False
    
    coordinates7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point10 = workPart.Points.CreatePoint(coordinates7)
    
    origin59 = NXOpen.Point3d(0.0, 59.008600004448425, 9.0086000044484198)
    matrix7 = NXOpen.Matrix3x3()
    
    matrix7.Xx = 0.0
    matrix7.Xy = 1.0
    matrix7.Xz = 0.0
    matrix7.Yx = 0.0
    matrix7.Yy = 0.0
    matrix7.Yz = 1.0
    matrix7.Zx = 1.0
    matrix7.Zy = 0.0
    matrix7.Zz = 0.0
    plane11 = workPart.Planes.CreateFixedTypePlane(origin59, matrix7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point11 = workPart.Points.CreatePoint(coordinates8)
    
    origin60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector7 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction11 = workPart.Directions.CreateDirection(origin60, vector7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector8 = NXOpen.Vector3d(0.0, 1.0, 0.0)
    direction12 = workPart.Directions.CreateDirection(origin61, vector8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix8 = NXOpen.Matrix3x3()
    
    matrix8.Xx = 0.0
    matrix8.Xy = 1.0
    matrix8.Xz = 0.0
    matrix8.Yx = 0.0
    matrix8.Yy = 0.0
    matrix8.Yz = 1.0
    matrix8.Zx = 1.0
    matrix8.Zy = 0.0
    matrix8.Zz = 0.0
    plane12 = workPart.Planes.CreateFixedTypePlane(origin62, matrix8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane12, direction12, point11, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder4.CoordinateSystem = cartesianCoordinateSystem4
    
    datumAxis2 = workPart.Datums.FindObject("DATUM_CSYS(0) Y axis")
    simpleSketchInPlaceBuilder4.HorizontalReference.Value = datumAxis2
    
    point12 = simpleSketchInPlaceBuilder4.SketchOrigin
    
    simpleSketchInPlaceBuilder4.SketchOrigin = point12
    
    markId209 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId209, None)
    
    markId210 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject88 = simpleSketchInPlaceBuilder4.Commit()
    
    sketch4 = nXObject88
    feature7 = sketch4.Feature
    
    markId211 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId211)
    
    sketch4.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder44 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject89 = sketchFindMovableObjectsBuilder44.Commit()
    
    sketchFindMovableObjectsBuilder44.Destroy()
    
    theSession.DeleteUndoMark(markId210, None)
    
    theSession.SetUndoMarkName(markId208, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    simpleSketchInPlaceBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression19)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression18)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId207, None, True)
    
    markId212 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_003")
    
    scaleAboutPoint190 = NXOpen.Point3d(11.47803501593962, 17.355342102414465, 0.0)
    viewCenter190 = NXOpen.Point3d(-11.478035015938888, -17.355342102413911, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint190, viewCenter190)
    
    scaleAboutPoint191 = NXOpen.Point3d(9.2930596755560178, 13.994905344735852, 0.0)
    viewCenter191 = NXOpen.Point3d(-9.2930596755552823, -13.994905344735296, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint191, viewCenter191)
    
    scaleAboutPoint192 = NXOpen.Point3d(7.6114584009316459, 11.195924275788741, 0.0)
    viewCenter192 = NXOpen.Point3d(-7.6114584009309132, -11.195924275788183, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint192, viewCenter192)
    
    scaleAboutPoint193 = NXOpen.Point3d(6.8680136268872065, 9.3815650057993132, 0.0)
    viewCenter193 = NXOpen.Point3d(-6.8680136268864702, -9.3815650057987519, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint193, viewCenter193)
    
    scaleAboutPoint194 = NXOpen.Point3d(5.5510543128656007, 7.5052520046395017, 0.0)
    viewCenter194 = NXOpen.Point3d(-5.5510543128648715, -7.5052520046389422, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint194, viewCenter194)
    
    scaleAboutPoint195 = NXOpen.Point3d(4.4861581793771697, 6.0042016037116595, 0.0)
    viewCenter195 = NXOpen.Point3d(-4.4861581793764396, -6.0042016037110955, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint195, viewCenter195)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId213 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId214 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId214, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(0.0, 6.8000000000000007, 16.699999999999999)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 1.8813679821999465, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder45 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject90 = sketchFindMovableObjectsBuilder45.Commit()
    
    sketchFindMovableObjectsBuilder45.Destroy()
    
    markId215 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder18 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects44 = [None] * 1 
    dragobjects44[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects44[0].Geometry = arc2
    dragobjects44[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects44[0].PointIndex = 0
    sketchDragGeometryBuilder18.SetDragGeometry(dragobjects44)
    
    sketchDragGeometryBuilder18.SplineLinearScale = False
    
    foundrelations65 = sketchDragGeometryBuilder18.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects45 = [None] * 1 
    dragobjects45[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects45[0].Geometry = arc2
    dragobjects45[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects45[0].PointIndex = 0
    sketchDragGeometryBuilder18.SetDragGeometry(dragobjects45)
    
    foundrelations66 = sketchDragGeometryBuilder18.FindRelations()
    
    sketchDragGeometryBuilder18.Destroy()
    
    markId216 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences18 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences18 = dimensionPreferences18.GetNarrowDimensionPreferences()
    
    option18 = narrowDimensionPreferences18.DimensionDisplayOption
    
    sketchRadialDimensionBuilder2 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder18 = sketchRadialDimensionBuilder2.Driving
    
    drivingValueBuilder18.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject34 = sketchRadialDimensionBuilder2.FirstAssociativity
    
    point1_78 = NXOpen.Point3d(0.0, 6.8000000000000007, 16.699999999999999)
    point2_78 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject34.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, NXOpen.View.Null, point1_78, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_78)
    
    dimensionMeasurementBuilder18 = sketchRadialDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder18.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder18 = sketchRadialDimensionBuilder2.Origin
    
    origin64 = NXOpen.Point3d(0.0, 10.112927069599492, 18.316850683404368)
    originBuilder18.OriginPoint = origin64
    
    originBuilder18.SetInferRelativeToGeometry(True)
    
    nXObject91 = sketchRadialDimensionBuilder2.Commit()
    
    sketchRadialDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences18.Dispose()
    dimensionPreferences18.Dispose()
    sketchFindMovableObjectsBuilder46 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject92 = sketchFindMovableObjectsBuilder46.Commit()
    
    sketchFindMovableObjectsBuilder46.Destroy()
    
    markId217 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId218 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension2 = nXObject91
    sketchEditDimensionValueBuilder19 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension2)
    
    selectNXObjectList22 = sketchEditDimensionValueBuilder19.ExtraGeometries
    
    foundrelations67 = sketchEditDimensionValueBuilder19.FindRelations()
    
    sketchDimensionalConstraint2 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc2]")
    sketchDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId218, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId218, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId219 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId219, None)
    
    markId220 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder19.DimValue = 3.0
    
    theSession.ActiveSketch.Scale(0.79729219067816659)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin65 = NXOpen.Point3d(0.0, 8.06295777748951, 14.60388200769634)
    diameterDimension2.AnnotationOrigin = origin65
    
    sketchEditDimensionValueBuilder19.RestoreOperation()
    
    sketchEditDimensionValueBuilder19.LoadExtraGeometry()
    
    selectNXObjectList23 = sketchEditDimensionValueBuilder19.ExtraGeometries
    
    foundrelations68 = sketchEditDimensionValueBuilder19.FindRelations()
    
    nXObject93 = sketchEditDimensionValueBuilder19.Commit()
    
    theSession.SetUndoMarkName(markId220, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId220, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId218, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId221 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId222 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId222, None)
    
    theSession.SetUndoMarkName(markId218, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder19.Destroy()
    
    theSession.DeleteUndoMark(markId221, None)
    
    theSession.SetUndoMarkVisibility(markId218, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId220, None)
    
    theSession.DeleteUndoMark(markId218, None)
    
    sketchFindMovableObjectsBuilder47 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject94 = sketchFindMovableObjectsBuilder47.Commit()
    
    sketchFindMovableObjectsBuilder47.Destroy()
    
    markId223 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder19 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects46 = [None] * 1 
    dragobjects46[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects46[0].Geometry = arc2
    dragobjects46[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects46[0].PointIndex = 0
    sketchDragGeometryBuilder19.SetDragGeometry(dragobjects46)
    
    sketchDragGeometryBuilder19.SplineLinearScale = False
    
    foundrelations69 = sketchDragGeometryBuilder19.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects47 = [None] * 1 
    dragobjects47[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects47[0].Geometry = arc2
    dragobjects47[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects47[0].PointIndex = -1475379104
    sketchDragGeometryBuilder19.SetDragGeometry(dragobjects47)
    
    foundrelations70 = sketchDragGeometryBuilder19.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects48 = [None] * 1 
    dragobjects48[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects48[0].Geometry = arc2
    dragobjects48[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects48[0].PointIndex = -1475379040
    sketchDragGeometryBuilder19.SetDragGeometry(dragobjects48)
    
    foundrelations71 = sketchDragGeometryBuilder19.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects49 = [None] * 1 
    dragobjects49[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects49[0].Geometry = arc2
    dragobjects49[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects49[0].PointIndex = -1475378416
    sketchDragGeometryBuilder19.SetDragGeometry(dragobjects49)
    
    foundrelations72 = sketchDragGeometryBuilder19.FindRelations()
    
    sketchDragGeometryBuilder19.Destroy()
    
    markId224 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences19 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences19 = dimensionPreferences19.GetNarrowDimensionPreferences()
    
    option19 = narrowDimensionPreferences19.DimensionDisplayOption
    
    sketchLinearDimensionBuilder17 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder19 = sketchLinearDimensionBuilder17.Driving
    
    drivingValueBuilder19.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder19 = sketchLinearDimensionBuilder17.Measurement
    
    dimensionMeasurementBuilder19.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject35 = sketchLinearDimensionBuilder17.FirstAssociativity
    
    selectNXObject36 = sketchLinearDimensionBuilder17.SecondAssociativity
    
    edge6 = extrude2.FindObject("EDGE * 130 * 220 {(66,4,20)(66,7,20)(66,10,20) EXTRUDE(2)}")
    point1_81 = NXOpen.Point3d(0.0, 6.5561827968406581, 20.0)
    point2_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject35.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge6, NXOpen.View.Null, point1_81, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_81)
    
    point1_82 = NXOpen.Point3d(0.0, 5.421586896611533, 13.314779584325381)
    point2_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject36.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, NXOpen.View.Null, point1_82, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_82)
    
    originBuilder19 = sketchLinearDimensionBuilder17.Origin
    
    origin67 = NXOpen.Point3d(0.0, 5.421586896611533, 16.657389792162689)
    originBuilder19.OriginPoint = origin67
    
    originBuilder19.SetInferRelativeToGeometry(True)
    
    nXObject95 = sketchLinearDimensionBuilder17.Commit()
    
    perpendicularDimension9 = nXObject95
    perpendicularDimension9.IsOriginCentered = True
    
    sketchLinearDimensionBuilder17.Destroy()
    
    narrowDimensionPreferences19.Dispose()
    dimensionPreferences19.Dispose()
    sketchFindMovableObjectsBuilder48 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject96 = sketchFindMovableObjectsBuilder48.Commit()
    
    sketchFindMovableObjectsBuilder48.Destroy()
    
    markId225 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId226 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder20 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension9)
    
    selectNXObjectList24 = sketchEditDimensionValueBuilder20.ExtraGeometries
    
    foundrelations73 = sketchEditDimensionValueBuilder20.FindRelations()
    
    sketchHelpedDimensionalConstraint17 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(4)|EDGE * 130 * 220 {(66,4,20)(66,7,20)(66,10,20) EXTRUDE(2)}] [[Curve Arc2] ArcCenter]")
    sketchHelpedDimensionalConstraint17.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId226, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId226, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint17.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId227 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId227, None)
    
    markId228 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder20.DimValue = 4.0
    
    nXObject97 = sketchEditDimensionValueBuilder20.Commit()
    
    theSession.SetUndoMarkName(markId228, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId228, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId226, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId229 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId230 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint17.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId230, None)
    
    theSession.SetUndoMarkName(markId226, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder20.Destroy()
    
    theSession.DeleteUndoMark(markId229, None)
    
    theSession.SetUndoMarkVisibility(markId226, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId228, None)
    
    theSession.DeleteUndoMark(markId226, None)
    
    sketchFindMovableObjectsBuilder49 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject98 = sketchFindMovableObjectsBuilder49.Commit()
    
    sketchFindMovableObjectsBuilder49.Destroy()
    
    markId231 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder20 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects50 = [None] * 1 
    dragobjects50[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects50[0].Geometry = arc2
    dragobjects50[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects50[0].PointIndex = 0
    sketchDragGeometryBuilder20.SetDragGeometry(dragobjects50)
    
    sketchDragGeometryBuilder20.SplineLinearScale = False
    
    foundrelations74 = sketchDragGeometryBuilder20.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects51 = [None] * 1 
    dragobjects51[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects51[0].Geometry = arc2
    dragobjects51[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects51[0].PointIndex = -1475378960
    sketchDragGeometryBuilder20.SetDragGeometry(dragobjects51)
    
    foundrelations75 = sketchDragGeometryBuilder20.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects52 = [None] * 1 
    dragobjects52[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects52[0].Geometry = arc2
    dragobjects52[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects52[0].PointIndex = -1475379040
    sketchDragGeometryBuilder20.SetDragGeometry(dragobjects52)
    
    foundrelations76 = sketchDragGeometryBuilder20.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects53 = [None] * 1 
    dragobjects53[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects53[0].Geometry = arc2
    dragobjects53[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects53[0].PointIndex = -1475379168
    sketchDragGeometryBuilder20.SetDragGeometry(dragobjects53)
    
    foundrelations77 = sketchDragGeometryBuilder20.FindRelations()
    
    sketchDragGeometryBuilder20.Destroy()
    
    markId232 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences20 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences20 = dimensionPreferences20.GetNarrowDimensionPreferences()
    
    option20 = narrowDimensionPreferences20.DimensionDisplayOption
    
    sketchLinearDimensionBuilder18 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder20 = sketchLinearDimensionBuilder18.Driving
    
    drivingValueBuilder20.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder20 = sketchLinearDimensionBuilder18.Measurement
    
    dimensionMeasurementBuilder20.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject37 = sketchLinearDimensionBuilder18.FirstAssociativity
    
    selectNXObject38 = sketchLinearDimensionBuilder18.SecondAssociativity
    
    edge8 = extrude2.FindObject("EDGE * 220 * 230 {(66,10,20)(66,10,12.5)(66,10,5) EXTRUDE(2)}")
    point1_85 = NXOpen.Point3d(0.0, 10.000000000000002, 14.954404905703949)
    point2_85 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject37.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge8, NXOpen.View.Null, point1_85, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_85)
    
    point1_86 = NXOpen.Point3d(0.0, 5.421586896611533, 16.0)
    point2_86 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject38.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, NXOpen.View.Null, point1_86, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_86)
    
    originBuilder20 = sketchLinearDimensionBuilder18.Origin
    
    origin69 = NXOpen.Point3d(0.0, 7.7107934483057674, 16.0)
    originBuilder20.OriginPoint = origin69
    
    originBuilder20.SetInferRelativeToGeometry(True)
    
    nXObject99 = sketchLinearDimensionBuilder18.Commit()
    
    perpendicularDimension10 = nXObject99
    perpendicularDimension10.IsOriginCentered = True
    
    sketchLinearDimensionBuilder18.Destroy()
    
    narrowDimensionPreferences20.Dispose()
    dimensionPreferences20.Dispose()
    sketchFindMovableObjectsBuilder50 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject100 = sketchFindMovableObjectsBuilder50.Commit()
    
    sketchFindMovableObjectsBuilder50.Destroy()
    
    markId233 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId234 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder21 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension10)
    
    selectNXObjectList25 = sketchEditDimensionValueBuilder21.ExtraGeometries
    
    foundrelations78 = sketchEditDimensionValueBuilder21.FindRelations()
    
    sketchHelpedDimensionalConstraint18 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(4)|EDGE * 220 * 230 {(66,10,20)(66,10,12.5)(66,10,5) EXTRUDE(2)}] [[Curve Arc2] ArcCenter]")
    sketchHelpedDimensionalConstraint18.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId234, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId234, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint18.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId235 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId235, None)
    
    markId236 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder21.DimValue = 3.0
    
    nXObject101 = sketchEditDimensionValueBuilder21.Commit()
    
    theSession.SetUndoMarkName(markId236, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId236, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId234, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId237 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId238 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint18.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId238, None)
    
    theSession.SetUndoMarkName(markId234, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder21.Destroy()
    
    theSession.DeleteUndoMark(markId237, None)
    
    theSession.SetUndoMarkVisibility(markId234, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId236, None)
    
    theSession.DeleteUndoMark(markId234, None)
    
    sketchFindMovableObjectsBuilder51 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject102 = sketchFindMovableObjectsBuilder51.Commit()
    
    sketchFindMovableObjectsBuilder51.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder4 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder4.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject103 = sketchWorkRegionBuilder4.Commit()
    
    sketchWorkRegionBuilder4.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId239 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId240 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression20 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies50 = [NXOpen.Body.Null] * 1 
    targetBodies50[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies50)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("-100")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies51 = [NXOpen.Body.Null] * 1 
    targetBodies51[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies51)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId240, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId241 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions8 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions8.SetSelectedFromInactive(False)
    
    curves8 = [NXOpen.ICurve.Null] * 1 
    curves8[0] = arc2
    seedPoint8 = NXOpen.Point3d(0.0, 6.802447405327543, 15.901562967846557)
    regionBoundaryRule8 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch4, curves8, seedPoint8, 0.01, selectionIntentRuleOptions8)
    
    selectionIntentRuleOptions8.Dispose()
    section6.AllowSelfIntersection(True)
    
    section6.AllowDegenerateCurves(False)
    
    rules5 = [None] * 1 
    rules5[0] = regionBoundaryRule8
    helpPoint5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section6.AddToSection(rules5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId241, None)
    
    markId242 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId243 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId243, None)
    
    direction13 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder6.Direction = direction13
    
    theSession.DeleteUndoMark(markId242, None)
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("100")
    
    markId244 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId244, None)
    
    markId245 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder6.ParentFeatureInternal = False
    
    feature8 = extrudeBuilder6.CommitFeature()
    
    theSession.DeleteUndoMark(markId245, None)
    
    theSession.SetUndoMarkName(markId240, "Extrude")
    
    expression21 = extrudeBuilder6.Limits.StartExtend.Value
    expression22 = extrudeBuilder6.Limits.EndExtend.Value
    extrudeBuilder6.Destroy()
    
    workPart.Expressions.Delete(expression20)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId246 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId247 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId248 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin70, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane13
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder5 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId248, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder5.UseWorkPartOrigin = False
    
    coordinates9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point13 = workPart.Points.CreatePoint(coordinates9)
    
    origin71 = NXOpen.Point3d(59.008600004448425, 59.008600004448425, 0.0)
    matrix9 = NXOpen.Matrix3x3()
    
    matrix9.Xx = 1.0
    matrix9.Xy = 0.0
    matrix9.Xz = 0.0
    matrix9.Yx = 0.0
    matrix9.Yy = 1.0
    matrix9.Yz = 0.0
    matrix9.Zx = 0.0
    matrix9.Zy = 0.0
    matrix9.Zz = 1.0
    plane14 = workPart.Planes.CreateFixedTypePlane(origin71, matrix9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point14 = workPart.Points.CreatePoint(coordinates10)
    
    origin72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction14 = workPart.Directions.CreateDirection(origin72, vector9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin73 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector10 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction15 = workPart.Directions.CreateDirection(origin73, vector10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin74 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix10 = NXOpen.Matrix3x3()
    
    matrix10.Xx = 1.0
    matrix10.Xy = 0.0
    matrix10.Xz = 0.0
    matrix10.Yx = 0.0
    matrix10.Yy = 1.0
    matrix10.Yz = 0.0
    matrix10.Zx = 0.0
    matrix10.Zy = 0.0
    matrix10.Zz = 1.0
    plane15 = workPart.Planes.CreateFixedTypePlane(origin74, matrix10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane15, direction15, point14, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder5.CoordinateSystem = cartesianCoordinateSystem5
    
    simpleSketchInPlaceBuilder5.HorizontalReference.Value = datumAxis1
    
    point15 = simpleSketchInPlaceBuilder5.SketchOrigin
    
    simpleSketchInPlaceBuilder5.SketchOrigin = point15
    
    markId249 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId249, None)
    
    markId250 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject104 = simpleSketchInPlaceBuilder5.Commit()
    
    sketch5 = nXObject104
    feature9 = sketch5.Feature
    
    markId251 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId251)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder52 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject105 = sketchFindMovableObjectsBuilder52.Commit()
    
    sketchFindMovableObjectsBuilder52.Destroy()
    
    theSession.DeleteUndoMark(markId250, None)
    
    theSession.SetUndoMarkName(markId248, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    simpleSketchInPlaceBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression24)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression23)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId247, None, True)
    
    markId252 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_004")
    
    scaleAboutPoint196 = NXOpen.Point3d(40.933715237566872, 33.396933209028361, 0.0)
    viewCenter196 = NXOpen.Point3d(-40.93371523756614, -33.396933209027807, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint196, viewCenter196)
    
    scaleAboutPoint197 = NXOpen.Point3d(51.167144046958484, 41.573304538153771, 0.0)
    viewCenter197 = NXOpen.Point3d(-51.167144046957766, -41.573304538153209, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint197, viewCenter197)
    
    scaleAboutPoint198 = NXOpen.Point3d(63.958930058698002, 51.966630672692148, 0.0)
    viewCenter198 = NXOpen.Point3d(-63.958930058697263, -51.966630672691572, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint198, viewCenter198)
    
    scaleAboutPoint199 = NXOpen.Point3d(79.948662573372417, 64.95828834086511, 0.0)
    viewCenter199 = NXOpen.Point3d(-79.948662573371678, -64.958288340864542, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint199, viewCenter199)
    
    scaleAboutPoint200 = NXOpen.Point3d(99.935828216715393, 81.197860426081306, 0.0)
    viewCenter200 = NXOpen.Point3d(-99.93582821671464, -81.197860426080723, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint200, viewCenter200)
    
    scaleAboutPoint201 = NXOpen.Point3d(164.59025762043487, 159.7369551521399, 0.0)
    viewCenter201 = NXOpen.Point3d(-164.59025762043407, -159.73695515213933, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint201, viewCenter201)
    
    scaleAboutPoint202 = NXOpen.Point3d(133.36031130271144, 129.47766932807539, 0.0)
    viewCenter202 = NXOpen.Point3d(-133.3603113027105, -129.47766932807482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint202, viewCenter202)
    
    scaleAboutPoint203 = NXOpen.Point3d(110.46960470442333, 105.20271646056926, 0.0)
    viewCenter203 = NXOpen.Point3d(-110.46960470442241, -105.20271646056872, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint203, viewCenter203)
    
    scaleAboutPoint204 = NXOpen.Point3d(90.968613360512961, 81.137088638652202, 0.0)
    viewCenter204 = NXOpen.Point3d(-90.968613360512109, -81.137088638651676, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint204, viewCenter204)
    
    scaleAboutPoint205 = NXOpen.Point3d(113.71076670064107, 100.8811671322789, 0.0)
    viewCenter205 = NXOpen.Point3d(-113.71076670064025, -100.88116713227832, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint205, viewCenter205)
    
    scaleAboutPoint206 = NXOpen.Point3d(142.13845837580124, 125.42621683280315, 0.0)
    viewCenter206 = NXOpen.Point3d(-142.13845837580038, -125.42621683280257, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint206, viewCenter206)
    
    scaleAboutPoint207 = NXOpen.Point3d(176.4069940649789, 155.51669213623128, 0.0)
    viewCenter207 = NXOpen.Point3d(-176.40699406497797, -155.51669213623069, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint207, viewCenter207)
    
    scaleAboutPoint208 = NXOpen.Point3d(217.87107819628056, 193.34079941631194, 0.0)
    viewCenter208 = NXOpen.Point3d(-217.87107819627974, -193.34079941631131, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint208, viewCenter208)
    
    scaleAboutPoint209 = NXOpen.Point3d(267.72293507170065, 212.00227493978264, 0.0)
    viewCenter209 = NXOpen.Point3d(-267.72293507169985, -212.0022749397821, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint209, viewCenter209)
    
    scaleAboutPoint210 = NXOpen.Point3d(341.24782980198285, 272.42127475738005, 0.0)
    viewCenter210 = NXOpen.Point3d(-341.24782980198216, -272.42127475737948, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint210, viewCenter210)
    
    scaleAboutPoint211 = NXOpen.Point3d(436.8631637561615, 348.76929464967145, 0.0)
    viewCenter211 = NXOpen.Point3d(-436.86316375616076, -348.76929464967088, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint211, viewCenter211)
    
    scaleAboutPoint212 = NXOpen.Point3d(565.39778563960738, 448.84083894169288, 0.0)
    viewCenter212 = NXOpen.Point3d(-565.3977856396067, -448.84083894169225, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint212, viewCenter212)
    
    scaleAboutPoint213 = NXOpen.Point3d(779.19284809103056, 639.93627503343919, 0.0)
    viewCenter213 = NXOpen.Point3d(-779.19284809102965, -639.93627503343896, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint213, viewCenter213)
    
    scaleAboutPoint214 = NXOpen.Point3d(620.77843434690374, 511.9490200267515, 0.0)
    viewCenter214 = NXOpen.Point3d(-620.77843434690283, -511.9490200267511, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint214, viewCenter214)
    
    scaleAboutPoint215 = NXOpen.Point3d(493.53173452641829, 409.55921602140131, 0.0)
    viewCenter215 = NXOpen.Point3d(-493.53173452641738, -409.55921602140074, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint215, viewCenter215)
    
    scaleAboutPoint216 = NXOpen.Point3d(392.35257726025065, 327.64737281712104, 0.0)
    viewCenter216 = NXOpen.Point3d(-392.35257726024969, -327.64737281712058, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint216, viewCenter216)
    
    scaleAboutPoint217 = NXOpen.Point3d(289.48366624747933, 244.97307975156832, 0.0)
    viewCenter217 = NXOpen.Point3d(-289.48366624747831, -244.97307975156781, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint217, viewCenter217)
    
    scaleAboutPoint218 = NXOpen.Point3d(231.58693299798347, 195.45093092426615, 0.0)
    viewCenter218 = NXOpen.Point3d(-231.58693299798259, -195.45093092426561, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint218, viewCenter218)
    
    scaleAboutPoint219 = NXOpen.Point3d(185.26954639838692, 156.36074473941295, 0.0)
    viewCenter219 = NXOpen.Point3d(-185.26954639838598, -156.36074473941247, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint219, viewCenter219)
    
    scaleAboutPoint220 = NXOpen.Point3d(148.21563711870959, 124.75097475025775, 0.0)
    viewCenter220 = NXOpen.Point3d(-148.21563711870871, -124.75097475025723, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint220, viewCenter220)
    
    scaleAboutPoint221 = NXOpen.Point3d(76.707500577154676, 25.794247553233429, 0.0)
    viewCenter221 = NXOpen.Point3d(-76.707500577153823, -25.794247553232992, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint221, viewCenter221)
    
    scaleAboutPoint222 = NXOpen.Point3d(61.582077928138354, 20.419320576172272, 0.0)
    viewCenter222 = NXOpen.Point3d(-61.582077928137522, -20.419320576171849, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint222, viewCenter222)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId253 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId254 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId254, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint21 = NXOpen.Point3d(54.0, 67.0, 0.0)
    endPoint21 = NXOpen.Point3d(62.0, 67.0, 0.0)
    line23 = workPart.Curves.CreateLine(startPoint21, endPoint21)
    
    startPoint22 = NXOpen.Point3d(62.0, 67.0, 0.0)
    endPoint22 = NXOpen.Point3d(62.0, 59.0, 0.0)
    line24 = workPart.Curves.CreateLine(startPoint22, endPoint22)
    
    startPoint23 = NXOpen.Point3d(62.0, 59.0, 0.0)
    endPoint23 = NXOpen.Point3d(54.0, 59.0, 0.0)
    line25 = workPart.Curves.CreateLine(startPoint23, endPoint23)
    
    startPoint24 = NXOpen.Point3d(54.0, 59.0, 0.0)
    endPoint24 = NXOpen.Point3d(54.0, 67.0, 0.0)
    line26 = workPart.Curves.CreateLine(startPoint24, endPoint24)
    
    theSession.ActiveSketch.AddGeometry(line23, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line24, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line25, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line26, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_21.Geometry = line23
    conGeom1_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_21.SplineDefiningPointIndex = 0
    conGeom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_21.Geometry = line24
    conGeom2_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_21, conGeom2_21)
    
    conGeom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_22.Geometry = line24
    conGeom1_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_22.SplineDefiningPointIndex = 0
    conGeom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_22.Geometry = line25
    conGeom2_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_22, conGeom2_22)
    
    conGeom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_23.Geometry = line25
    conGeom1_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_23.SplineDefiningPointIndex = 0
    conGeom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_23.Geometry = line26
    conGeom2_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_23, conGeom2_23)
    
    conGeom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_24.Geometry = line26
    conGeom1_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_24.SplineDefiningPointIndex = 0
    conGeom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_24.Geometry = line23
    conGeom2_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_24, conGeom2_24)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms11 = [NXOpen.SmartObject.Null] * 4 
    geoms11[0] = line23
    geoms11[1] = line24
    geoms11[2] = line25
    geoms11[3] = line26
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms11)
    
    geoms12 = [NXOpen.SmartObject.Null] * 4 
    geoms12[0] = line23
    geoms12[1] = line24
    geoms12[2] = line25
    geoms12[3] = line26
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms12)
    
    objects6 = [NXOpen.NXObject.Null] * 4 
    objects6[0] = sketchGeometricConstraint21
    objects6[1] = sketchGeometricConstraint22
    objects6[2] = sketchGeometricConstraint23
    objects6[3] = sketchGeometricConstraint24
    errorList6 = theSession.ActiveSketch.DeleteObjects(objects6)
    
    errorList6.Dispose()
    sketchFindMovableObjectsBuilder53 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject106 = sketchFindMovableObjectsBuilder53.Commit()
    
    sketchFindMovableObjectsBuilder53.Destroy()
    
    markId255 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder21 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects54 = [None] * 1 
    dragobjects54[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects54[0].Geometry = line25
    dragobjects54[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects54[0].PointIndex = 0
    sketchDragGeometryBuilder21.SetDragGeometry(dragobjects54)
    
    sketchDragGeometryBuilder21.SplineLinearScale = False
    
    foundrelations79 = sketchDragGeometryBuilder21.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects55 = [None] * 1 
    dragobjects55[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects55[0].Geometry = line25
    dragobjects55[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects55[0].PointIndex = 0
    sketchDragGeometryBuilder21.SetDragGeometry(dragobjects55)
    
    foundrelations80 = sketchDragGeometryBuilder21.FindRelations()
    
    sketchDragGeometryBuilder21.Destroy()
    
    markId256 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences21 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences21 = dimensionPreferences21.GetNarrowDimensionPreferences()
    
    option21 = narrowDimensionPreferences21.DimensionDisplayOption
    
    sketchLinearDimensionBuilder19 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder21 = sketchLinearDimensionBuilder19.Driving
    
    drivingValueBuilder21.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject39 = sketchLinearDimensionBuilder19.FirstAssociativity
    
    selectNXObject40 = sketchLinearDimensionBuilder19.SecondAssociativity
    
    point1_89 = NXOpen.Point3d(62.0, 59.0, 0.0)
    point2_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject39.SetValue(NXOpen.InferSnapType.SnapType.Start, line25, NXOpen.View.Null, point1_89, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_89)
    
    point1_90 = NXOpen.Point3d(54.0, 59.0, 0.0)
    point2_90 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject40.SetValue(NXOpen.InferSnapType.SnapType.End, line25, NXOpen.View.Null, point1_90, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_90)
    
    dimensionMeasurementBuilder21 = sketchLinearDimensionBuilder19.Measurement
    
    dimensionMeasurementBuilder21.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder21 = sketchLinearDimensionBuilder19.Origin
    
    origin76 = NXOpen.Point3d(58.0, 53.119970677727736, 0.0)
    originBuilder21.OriginPoint = origin76
    
    originBuilder21.SetInferRelativeToGeometry(True)
    
    nXObject107 = sketchLinearDimensionBuilder19.Commit()
    
    horizontalDimension5 = nXObject107
    horizontalDimension5.IsOriginCentered = True
    
    sketchLinearDimensionBuilder19.Destroy()
    
    narrowDimensionPreferences21.Dispose()
    dimensionPreferences21.Dispose()
    sketchFindMovableObjectsBuilder54 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject108 = sketchFindMovableObjectsBuilder54.Commit()
    
    sketchFindMovableObjectsBuilder54.Destroy()
    
    markId257 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId258 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder22 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension5)
    
    selectNXObjectList26 = sketchEditDimensionValueBuilder22.ExtraGeometries
    
    foundrelations81 = sketchEditDimensionValueBuilder22.FindRelations()
    
    sketchHelpedDimensionalConstraint19 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line25] StartVertex] [[Curve Line25] EndVertex]")
    sketchHelpedDimensionalConstraint19.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId258, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId258, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint19.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId259 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId259, None)
    
    markId260 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder22.DimValue = 6.0
    
    theSession.ActiveSketch.Scale(0.75)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin77 = NXOpen.Point3d(43.5, 39.839978008295802, 0.0)
    horizontalDimension5.AnnotationOrigin = origin77
    
    sketchEditDimensionValueBuilder22.RestoreOperation()
    
    sketchEditDimensionValueBuilder22.LoadExtraGeometry()
    
    selectNXObjectList27 = sketchEditDimensionValueBuilder22.ExtraGeometries
    
    foundrelations82 = sketchEditDimensionValueBuilder22.FindRelations()
    
    nXObject109 = sketchEditDimensionValueBuilder22.Commit()
    
    theSession.SetUndoMarkName(markId260, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId260, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId258, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId261 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint223 = NXOpen.Point3d(-21.434884668319885, -9.4209775356728134, 0.0)
    viewCenter223 = NXOpen.Point3d(21.434884668320741, 9.4209775356732273, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint223, viewCenter223)
    
    scaleAboutPoint224 = NXOpen.Point3d(-26.793605835399966, -11.992299386005598, 0.0)
    viewCenter224 = NXOpen.Point3d(26.79360583540074, 11.992299386006023, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint224, viewCenter224)
    
    scaleAboutPoint225 = NXOpen.Point3d(-33.49200729425003, -14.990374232507044, 0.0)
    viewCenter225 = NXOpen.Point3d(33.492007294250811, 14.99037423250746, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint225, viewCenter225)
    
    scaleAboutPoint226 = NXOpen.Point3d(-41.865009117812676, -18.737967790633832, 0.0)
    viewCenter226 = NXOpen.Point3d(41.865009117813422, 18.737967790634293, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint226, viewCenter226)
    
    scaleAboutPoint227 = NXOpen.Point3d(-33.49200729425003, -14.990374232507023, 0.0)
    viewCenter227 = NXOpen.Point3d(33.492007294250811, 14.99037423250746, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint227, viewCenter227)
    
    scaleAboutPoint228 = NXOpen.Point3d(-26.793605835399966, -11.99229938600558, 0.0)
    viewCenter228 = NXOpen.Point3d(26.79360583540074, 11.992299386006041, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint228, viewCenter228)
    
    scaleAboutPoint229 = NXOpen.Point3d(-21.434884668319885, -9.5938395088044199, 0.0)
    viewCenter229 = NXOpen.Point3d(21.434884668320681, 9.5938395088048622, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint229, viewCenter229)
    
    scaleAboutPoint230 = NXOpen.Point3d(-17.147907734655824, -7.8133611855487608, 0.0)
    viewCenter230 = NXOpen.Point3d(17.147907734656602, 7.81336118554922, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint230, viewCenter230)
    
    scaleAboutPoint231 = NXOpen.Point3d(-13.718326187724594, -6.2506889484389623, 0.0)
    viewCenter231 = NXOpen.Point3d(13.71832618772536, 6.2506889484394339, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint231, viewCenter231)
    
    scaleAboutPoint232 = NXOpen.Point3d(-11.594198261883314, -5.00055115875114, 0.0)
    viewCenter232 = NXOpen.Point3d(11.594198261884076, 5.000551158751585, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint232, viewCenter232)
    
    scaleAboutPoint233 = NXOpen.Point3d(-9.6293799304801286, -4.0004409270008514, 0.0)
    viewCenter233 = NXOpen.Point3d(9.6293799304808889, 4.0004409270013097, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint233, viewCenter233)
    
    markId262 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint19.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId262, None)
    
    theSession.SetUndoMarkName(markId258, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder22.Destroy()
    
    theSession.DeleteUndoMark(markId261, None)
    
    theSession.SetUndoMarkVisibility(markId258, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId260, None)
    
    theSession.DeleteUndoMark(markId258, None)
    
    sketchFindMovableObjectsBuilder55 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject110 = sketchFindMovableObjectsBuilder55.Commit()
    
    sketchFindMovableObjectsBuilder55.Destroy()
    
    markId263 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder22 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects56 = [None] * 1 
    dragobjects56[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects56[0].Geometry = line26
    dragobjects56[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects56[0].PointIndex = 0
    sketchDragGeometryBuilder22.SetDragGeometry(dragobjects56)
    
    sketchDragGeometryBuilder22.SplineLinearScale = False
    
    foundrelations83 = sketchDragGeometryBuilder22.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects57 = [None] * 1 
    dragobjects57[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects57[0].Geometry = line26
    dragobjects57[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects57[0].PointIndex = 0
    sketchDragGeometryBuilder22.SetDragGeometry(dragobjects57)
    
    foundrelations84 = sketchDragGeometryBuilder22.FindRelations()
    
    sketchDragGeometryBuilder22.Destroy()
    
    markId264 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences22 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences22 = dimensionPreferences22.GetNarrowDimensionPreferences()
    
    option22 = narrowDimensionPreferences22.DimensionDisplayOption
    
    sketchLinearDimensionBuilder20 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder22 = sketchLinearDimensionBuilder20.Driving
    
    drivingValueBuilder22.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject41 = sketchLinearDimensionBuilder20.FirstAssociativity
    
    selectNXObject42 = sketchLinearDimensionBuilder20.SecondAssociativity
    
    point1_93 = NXOpen.Point3d(40.5, 44.25, 0.0)
    point2_93 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject41.SetValue(NXOpen.InferSnapType.SnapType.Start, line26, NXOpen.View.Null, point1_93, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_93)
    
    point1_94 = NXOpen.Point3d(40.5, 50.25, 0.0)
    point2_94 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject42.SetValue(NXOpen.InferSnapType.SnapType.End, line26, NXOpen.View.Null, point1_94, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_94)
    
    dimensionMeasurementBuilder22 = sketchLinearDimensionBuilder20.Measurement
    
    dimensionMeasurementBuilder22.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder22 = sketchLinearDimensionBuilder20.Origin
    
    origin79 = NXOpen.Point3d(36.089978008295802, 47.25, 0.0)
    originBuilder22.OriginPoint = origin79
    
    originBuilder22.SetInferRelativeToGeometry(True)
    
    nXObject111 = sketchLinearDimensionBuilder20.Commit()
    
    verticalDimension6 = nXObject111
    verticalDimension6.IsOriginCentered = True
    
    sketchLinearDimensionBuilder20.Destroy()
    
    narrowDimensionPreferences22.Dispose()
    dimensionPreferences22.Dispose()
    sketchFindMovableObjectsBuilder56 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject112 = sketchFindMovableObjectsBuilder56.Commit()
    
    sketchFindMovableObjectsBuilder56.Destroy()
    
    markId265 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId266 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder23 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension6)
    
    selectNXObjectList28 = sketchEditDimensionValueBuilder23.ExtraGeometries
    
    foundrelations85 = sketchEditDimensionValueBuilder23.FindRelations()
    
    sketchHelpedDimensionalConstraint20 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line26] StartVertex] [[Curve Line26] EndVertex]")
    sketchHelpedDimensionalConstraint20.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId266, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId266, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint20.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId267 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId267, None)
    
    markId268 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder23.DimValue = 5.9000000000000004
    
    nXObject113 = sketchEditDimensionValueBuilder23.Commit()
    
    theSession.SetUndoMarkName(markId268, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId268, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId266, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId269 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId270 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint20.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId270, None)
    
    theSession.SetUndoMarkName(markId266, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder23.Destroy()
    
    theSession.DeleteUndoMark(markId269, None)
    
    theSession.SetUndoMarkVisibility(markId266, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId268, None)
    
    theSession.DeleteUndoMark(markId266, None)
    
    sketchFindMovableObjectsBuilder57 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject114 = sketchFindMovableObjectsBuilder57.Commit()
    
    sketchFindMovableObjectsBuilder57.Destroy()
    
    scaleAboutPoint234 = NXOpen.Point3d(-12.008403207422369, -1.9541976917737474, 0.0)
    viewCenter234 = NXOpen.Point3d(12.008403207423122, 1.9541976917742205, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint234, viewCenter234)
    
    scaleAboutPoint235 = NXOpen.Point3d(-14.939699745083344, -2.7259641714960723, 0.0)
    viewCenter235 = NXOpen.Point3d(14.939699745084079, 2.725964171496555, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint235, viewCenter235)
    
    scaleAboutPoint236 = NXOpen.Point3d(-18.674624681354274, -3.5844658748569294, 0.0)
    viewCenter236 = NXOpen.Point3d(18.674624681355017, 3.5844658748574121, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint236, viewCenter236)
    
    scaleAboutPoint237 = NXOpen.Point3d(-23.343280851692928, -4.5912140063754361, 0.0)
    viewCenter237 = NXOpen.Point3d(23.343280851693663, 4.5912140063759264, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint237, viewCenter237)
    
    scaleAboutPoint238 = NXOpen.Point3d(-29.179101064616262, -5.8773070864746604, 0.0)
    viewCenter238 = NXOpen.Point3d(29.17910106461704, 5.8773070864751444, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint238, viewCenter238)
    
    scaleAboutPoint239 = NXOpen.Point3d(-36.301014357638799, -7.6923578043566252, 0.0)
    viewCenter239 = NXOpen.Point3d(36.301014357639517, 7.6923578043570968, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint239, viewCenter239)
    
    scaleAboutPoint240 = NXOpen.Point3d(-38.677866488198497, -14.585228982979782, 0.0)
    viewCenter240 = NXOpen.Point3d(38.67786648819925, 14.58522898298026, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint240, viewCenter240)
    
    scaleAboutPoint241 = NXOpen.Point3d(-30.942293190558733, -11.668183186383779, 0.0)
    viewCenter241 = NXOpen.Point3d(30.942293190559454, 11.668183186384251, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint241, viewCenter241)
    
    markId271 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder23 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects58 = [None] * 1 
    dragobjects58[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects58[0].Geometry = line25
    dragobjects58[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects58[0].PointIndex = 0
    sketchDragGeometryBuilder23.SetDragGeometry(dragobjects58)
    
    sketchDragGeometryBuilder23.SplineLinearScale = False
    
    foundrelations86 = sketchDragGeometryBuilder23.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects59 = [None] * 1 
    dragobjects59[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects59[0].Geometry = line25
    dragobjects59[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects59[0].PointIndex = 0
    sketchDragGeometryBuilder23.SetDragGeometry(dragobjects59)
    
    foundrelations87 = sketchDragGeometryBuilder23.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects60 = [None] * 1 
    dragobjects60[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects60[0].Geometry = line25
    dragobjects60[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects60[0].PointIndex = 0
    sketchDragGeometryBuilder23.SetDragGeometry(dragobjects60)
    
    foundrelations88 = sketchDragGeometryBuilder23.FindRelations()
    
    sketchDragGeometryBuilder23.Destroy()
    
    markId272 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences23 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences23 = dimensionPreferences23.GetNarrowDimensionPreferences()
    
    option23 = narrowDimensionPreferences23.DimensionDisplayOption
    
    sketchLinearDimensionBuilder21 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder23 = sketchLinearDimensionBuilder21.Driving
    
    drivingValueBuilder23.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder23 = sketchLinearDimensionBuilder21.Measurement
    
    dimensionMeasurementBuilder23.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject43 = sketchLinearDimensionBuilder21.FirstAssociativity
    
    selectNXObject44 = sketchLinearDimensionBuilder21.SecondAssociativity
    
    point1_97 = NXOpen.Point3d(44.893526788375027, 44.25, 0.0)
    point2_97 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject43.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line25, NXOpen.View.Null, point1_97, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_97)
    
    point1_98 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_98 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject44.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, NXOpen.View.Null, point1_98, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_98)
    
    originBuilder23 = sketchLinearDimensionBuilder21.Origin
    
    origin81 = NXOpen.Point3d(49.180503722039077, 22.125, 0.0)
    originBuilder23.OriginPoint = origin81
    
    originBuilder23.SetInferRelativeToGeometry(True)
    
    nXObject115 = sketchLinearDimensionBuilder21.Commit()
    
    perpendicularDimension11 = nXObject115
    perpendicularDimension11.IsOriginCentered = True
    
    sketchLinearDimensionBuilder21.Destroy()
    
    narrowDimensionPreferences23.Dispose()
    dimensionPreferences23.Dispose()
    sketchFindMovableObjectsBuilder58 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject116 = sketchFindMovableObjectsBuilder58.Commit()
    
    sketchFindMovableObjectsBuilder58.Destroy()
    
    markId273 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId274 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder24 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension11)
    
    selectNXObjectList29 = sketchEditDimensionValueBuilder24.ExtraGeometries
    
    foundrelations89 = sketchEditDimensionValueBuilder24.FindRelations()
    
    sketchHelpedDimensionalConstraint21 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line25] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line1] StartVertex]")
    sketchHelpedDimensionalConstraint21.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId274, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId274, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint21.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId275 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId275, None)
    
    markId276 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder24.DimValue = 60.0
    
    nXObject117 = sketchEditDimensionValueBuilder24.Commit()
    
    theSession.SetUndoMarkName(markId276, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId276, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId274, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId277 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId278 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint21.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId278, None)
    
    theSession.SetUndoMarkName(markId274, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder24.Destroy()
    
    theSession.DeleteUndoMark(markId277, None)
    
    theSession.SetUndoMarkVisibility(markId274, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId276, None)
    
    theSession.DeleteUndoMark(markId274, None)
    
    sketchFindMovableObjectsBuilder59 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject118 = sketchFindMovableObjectsBuilder59.Commit()
    
    sketchFindMovableObjectsBuilder59.Destroy()
    
    markId279 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder24 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects61 = [None] * 1 
    dragobjects61[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects61[0].Geometry = line26
    dragobjects61[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects61[0].PointIndex = 0
    sketchDragGeometryBuilder24.SetDragGeometry(dragobjects61)
    
    sketchDragGeometryBuilder24.SplineLinearScale = False
    
    foundrelations90 = sketchDragGeometryBuilder24.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects62 = [None] * 1 
    dragobjects62[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects62[0].Geometry = line26
    dragobjects62[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects62[0].PointIndex = 0
    sketchDragGeometryBuilder24.SetDragGeometry(dragobjects62)
    
    foundrelations91 = sketchDragGeometryBuilder24.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects63 = [None] * 1 
    dragobjects63[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects63[0].Geometry = line26
    dragobjects63[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects63[0].PointIndex = 0
    sketchDragGeometryBuilder24.SetDragGeometry(dragobjects63)
    
    foundrelations92 = sketchDragGeometryBuilder24.FindRelations()
    
    sketchDragGeometryBuilder24.Destroy()
    
    markId280 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences24 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences24 = dimensionPreferences24.GetNarrowDimensionPreferences()
    
    option24 = narrowDimensionPreferences24.DimensionDisplayOption
    
    sketchLinearDimensionBuilder22 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder24 = sketchLinearDimensionBuilder22.Driving
    
    drivingValueBuilder24.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder24 = sketchLinearDimensionBuilder22.Measurement
    
    dimensionMeasurementBuilder24.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject45 = sketchLinearDimensionBuilder22.FirstAssociativity
    
    selectNXObject46 = sketchLinearDimensionBuilder22.SecondAssociativity
    
    point1_101 = NXOpen.Point3d(40.5, 62.616104032094256, 0.0)
    point2_101 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject45.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line26, NXOpen.View.Null, point1_101, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_101)
    
    point1_102 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_102 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject46.SetValue(NXOpen.InferSnapType.SnapType.End, line4, NXOpen.View.Null, point1_102, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_102)
    
    originBuilder24 = sketchLinearDimensionBuilder22.Origin
    
    origin83 = NXOpen.Point3d(20.25, 52.520964801207931, 0.0)
    originBuilder24.OriginPoint = origin83
    
    originBuilder24.SetInferRelativeToGeometry(True)
    
    nXObject119 = sketchLinearDimensionBuilder22.Commit()
    
    perpendicularDimension12 = nXObject119
    perpendicularDimension12.IsOriginCentered = True
    
    sketchLinearDimensionBuilder22.Destroy()
    
    narrowDimensionPreferences24.Dispose()
    dimensionPreferences24.Dispose()
    sketchFindMovableObjectsBuilder60 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject120 = sketchFindMovableObjectsBuilder60.Commit()
    
    sketchFindMovableObjectsBuilder60.Destroy()
    
    markId281 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId282 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder25 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension12)
    
    selectNXObjectList30 = sketchEditDimensionValueBuilder25.ExtraGeometries
    
    foundrelations93 = sketchEditDimensionValueBuilder25.FindRelations()
    
    sketchHelpedDimensionalConstraint22 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line26] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line4] EndVertex]")
    sketchHelpedDimensionalConstraint22.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId282, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId282, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint22.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId283 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId283, None)
    
    markId284 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder25.DimValue = 60.0
    
    nXObject121 = sketchEditDimensionValueBuilder25.Commit()
    
    theSession.SetUndoMarkName(markId284, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId284, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId282, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId285 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId286 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint22.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId286, None)
    
    theSession.SetUndoMarkName(markId282, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder25.Destroy()
    
    theSession.DeleteUndoMark(markId285, None)
    
    theSession.SetUndoMarkVisibility(markId282, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId284, None)
    
    theSession.DeleteUndoMark(markId282, None)
    
    sketchFindMovableObjectsBuilder61 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject122 = sketchFindMovableObjectsBuilder61.Commit()
    
    sketchFindMovableObjectsBuilder61.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder5 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder5.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject123 = sketchWorkRegionBuilder5.Commit()
    
    sketchWorkRegionBuilder5.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId287 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId288 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section7 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section7
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies52 = [NXOpen.Body.Null] * 1 
    targetBodies52[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies52)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("100")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies53 = [NXOpen.Body.Null] * 1 
    targetBodies53[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies53)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder7 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder7.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder7.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId288, "Extrude Dialog")
    
    section7.DistanceTolerance = 0.01
    
    section7.ChainingTolerance = 0.0094999999999999998
    
    section7.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId289 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions9 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions9.SetSelectedFromInactive(False)
    
    curves9 = [NXOpen.ICurve.Null] * 4 
    curves9[0] = line23
    curves9[1] = line24
    curves9[2] = line25
    curves9[3] = line26
    seedPoint9 = NXOpen.Point3d(63.441437999999998, 63.384080699999998, 0.0)
    regionBoundaryRule9 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch5, curves9, seedPoint9, 0.01, selectionIntentRuleOptions9)
    
    selectionIntentRuleOptions9.Dispose()
    section7.AllowSelfIntersection(True)
    
    section7.AllowDegenerateCurves(False)
    
    rules6 = [None] * 1 
    rules6[0] = regionBoundaryRule9
    helpPoint6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section7.AddToSection(rules6, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId289, None)
    
    markId290 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId291 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId291, None)
    
    direction16 = workPart.Directions.CreateDirection(sketch5, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder7.Direction = direction16
    
    theSession.DeleteUndoMark(markId290, None)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("60")
    
    scaleAboutPoint242 = NXOpen.Point3d(-17.701066048677038, 28.418508382837842, 0.0)
    viewCenter242 = NXOpen.Point3d(17.70106604867777, -28.418508382837288, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint242, viewCenter242)
    
    scaleAboutPoint243 = NXOpen.Point3d(-19.70626493700378, 35.868859424810466, 0.0)
    viewCenter243 = NXOpen.Point3d(19.706264937004502, -35.868859424809905, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint243, viewCenter243)
    
    scaleAboutPoint244 = NXOpen.Point3d(3.025084529803594, 53.263095471179277, 0.0)
    viewCenter244 = NXOpen.Point3d(-3.0250845298028941, -53.263095471178708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint244, viewCenter244)
    
    scaleAboutPoint245 = NXOpen.Point3d(1.5557577581849065, 40.190408753100847, 0.0)
    viewCenter245 = NXOpen.Point3d(-1.5557577581841842, -40.190408753100286, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint245, viewCenter245)
    
    scaleAboutPoint246 = NXOpen.Point3d(1.1063166280426997, 31.460879109954277, 0.0)
    viewCenter246 = NXOpen.Point3d(-1.1063166280419685, -31.460879109953709, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint246, viewCenter246)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies54 = [NXOpen.Body.Null] * 1 
    targetBodies54[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies54)
    
    markId292 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId292, None)
    
    markId293 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder7.ParentFeatureInternal = False
    
    feature10 = extrudeBuilder7.CommitFeature()
    
    theSession.DeleteUndoMark(markId293, None)
    
    theSession.SetUndoMarkName(markId288, "Extrude")
    
    expression26 = extrudeBuilder7.Limits.StartExtend.Value
    expression27 = extrudeBuilder7.Limits.EndExtend.Value
    extrudeBuilder7.Destroy()
    
    workPart.Expressions.Delete(expression25)
    
    scaleAboutPoint247 = NXOpen.Point3d(-13.165167873703478, 20.079646798968717, 0.0)
    viewCenter247 = NXOpen.Point3d(13.165167873704176, -20.079646798968149, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint247, viewCenter247)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId294 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId295 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId296 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin84 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin84, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane16
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression29 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder6 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId296, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder6.UseWorkPartOrigin = False
    
    scalar1 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude3 = feature10
    edge9 = extrude3.FindObject("EDGE * 160 * 170 {(66,65.9,60)(66,65.9,32.5)(66,65.9,5) EXTRUDE(2)}")
    point16 = workPart.Points.CreatePoint(edge9, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge10 = extrude3.FindObject("EDGE * 160 EXTRUDE(2) 130 {(66,60,5)(66,62.95,5)(66,65.9,5) EXTRUDE(2)}")
    direction17 = workPart.Directions.CreateDirection(edge10, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude3.FindObject("FACE 160 {(66,62.95,32.5) EXTRUDE(2)}")
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction17, point16, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder6.CoordinateSystem = cartesianCoordinateSystem6
    
    simpleSketchInPlaceBuilder6.HorizontalReference.Value = edge10
    
    point17 = simpleSketchInPlaceBuilder6.SketchOrigin
    
    simpleSketchInPlaceBuilder6.SketchOrigin = point17
    
    scalar2 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point18 = workPart.Points.CreatePoint(edge9, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    simpleSketchInPlaceBuilder6.Destroy()
    
    workPart.Points.DeletePoint(point18)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression29)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression28)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane16.DestroyPlane()
    
    theSession.UndoToMark(markId296, None)
    
    theSession.DeleteUndoMark(markId296, None)
    
    theSession.Preferences.Sketch.SectionView = False
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    theSession.UndoToMark(markId294, None)
    
    theSession.DeleteUndoMark(markId294, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId297 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId298 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId299 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder7 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin85 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane17 = workPart.Planes.CreatePlane(origin85, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.PlaneReference = plane17
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder7 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder7 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder7.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId299, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder7.UseWorkPartOrigin = False
    
    coordinates11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point19 = workPart.Points.CreatePoint(coordinates11)
    
    origin86 = NXOpen.Point3d(58.175266512169358, 0.0, 28.175266512169365)
    matrix11 = NXOpen.Matrix3x3()
    
    matrix11.Xx = 1.0
    matrix11.Xy = 0.0
    matrix11.Xz = 0.0
    matrix11.Yx = -0.0
    matrix11.Yy = 0.0
    matrix11.Yz = 1.0
    matrix11.Zx = 0.0
    matrix11.Zy = -1.0
    matrix11.Zz = 0.0
    plane18 = workPart.Planes.CreateFixedTypePlane(origin86, matrix11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point20 = workPart.Points.CreatePoint(coordinates12)
    
    origin87 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector11 = NXOpen.Vector3d(0.0, -1.0, 0.0)
    direction18 = workPart.Directions.CreateDirection(origin87, vector11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin88 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector12 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction19 = workPart.Directions.CreateDirection(origin88, vector12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix12 = NXOpen.Matrix3x3()
    
    matrix12.Xx = 1.0
    matrix12.Xy = 0.0
    matrix12.Xz = 0.0
    matrix12.Yx = -0.0
    matrix12.Yy = 0.0
    matrix12.Yz = 1.0
    matrix12.Zx = 0.0
    matrix12.Zy = -1.0
    matrix12.Zz = 0.0
    plane19 = workPart.Planes.CreateFixedTypePlane(origin89, matrix12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform7 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane19, direction19, point20, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder7.CoordinateSystem = cartesianCoordinateSystem7
    
    simpleSketchInPlaceBuilder7.HorizontalReference.Value = datumAxis1
    
    point21 = simpleSketchInPlaceBuilder7.SketchOrigin
    
    simpleSketchInPlaceBuilder7.SketchOrigin = point21
    
    markId300 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId300, None)
    
    markId301 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject124 = simpleSketchInPlaceBuilder7.Commit()
    
    sketch6 = nXObject124
    feature11 = sketch6.Feature
    
    markId302 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs6 = theSession.UpdateManager.DoUpdate(markId302)
    
    sketch6.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder62 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject125 = sketchFindMovableObjectsBuilder62.Commit()
    
    sketchFindMovableObjectsBuilder62.Destroy()
    
    theSession.DeleteUndoMark(markId301, None)
    
    theSession.SetUndoMarkName(markId299, "Create Sketch")
    
    sketchInPlaceBuilder7.Destroy()
    
    sketchAlongPathBuilder7.Destroy()
    
    simpleSketchInPlaceBuilder7.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression31)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression30)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane17.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId298, None, True)
    
    markId303 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_005")
    
    scaleAboutPoint248 = NXOpen.Point3d(51.996881517990218, 34.918118572586586, 0.0)
    viewCenter248 = NXOpen.Point3d(-51.996881517989515, -34.918118572586003, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint248, viewCenter248)
    
    scaleAboutPoint249 = NXOpen.Point3d(65.168963870619265, 43.647648215733135, 0.0)
    viewCenter249 = NXOpen.Point3d(-65.168963870618597, -43.647648215732573, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint249, viewCenter249)
    
    scaleAboutPoint250 = NXOpen.Point3d(81.677282304688546, 54.991715202495399, 0.0)
    viewCenter250 = NXOpen.Point3d(-81.677282304687864, -54.991715202494824, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint250, viewCenter250)
    
    scaleAboutPoint251 = NXOpen.Point3d(102.9068933799151, 69.820031335191771, 0.0)
    viewCenter251 = NXOpen.Point3d(-102.90689337991438, -69.820031335191203, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint251, viewCenter251)
    
    scaleAboutPoint252 = NXOpen.Point3d(144.50180566470988, 115.29758559462255, 0.0)
    viewCenter252 = NXOpen.Point3d(-144.50180566470922, -115.29758559462198, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint252, viewCenter252)
    
    scaleAboutPoint253 = NXOpen.Point3d(116.95192869685874, 92.238068475698114, 0.0)
    viewCenter253 = NXOpen.Point3d(-116.95192869685805, -92.238068475697531, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint253, viewCenter253)
    
    scaleAboutPoint254 = NXOpen.Point3d(95.506240155217739, 73.142222381315008, 0.0)
    viewCenter254 = NXOpen.Point3d(-95.506240155217043, -73.142222381314397, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint254, viewCenter254)
    
    scaleAboutPoint255 = NXOpen.Point3d(78.1336118554904, 57.476606066262377, 0.0)
    viewCenter255 = NXOpen.Point3d(-78.133611855489718, -57.476606066261773, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint255, viewCenter255)
    
    scaleAboutPoint256 = NXOpen.Point3d(63.198337376918836, 45.428126538988778, 0.0)
    viewCenter256 = NXOpen.Point3d(-63.198337376918147, -45.428126538988167, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint256, viewCenter256)
    
    scaleAboutPoint257 = NXOpen.Point3d(51.001196552752063, 36.121237905582603, 0.0)
    viewCenter257 = NXOpen.Point3d(-51.001196552751402, -36.121237905581999, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint257, viewCenter257)
    
    scaleAboutPoint258 = NXOpen.Point3d(40.092914600254652, 28.011937022032292, 0.0)
    viewCenter258 = NXOpen.Point3d(-40.092914600253977, -28.011937022031681, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint258, viewCenter258)
    
    scaleAboutPoint259 = NXOpen.Point3d(32.003527416009035, 21.843115504068212, 0.0)
    viewCenter259 = NXOpen.Point3d(-32.003527416008396, -21.84311550406759, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint259, viewCenter259)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId304 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId305 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId305, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(63.0, 0.0, 56.0)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 3.0086019330035549, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder63 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject126 = sketchFindMovableObjectsBuilder63.Commit()
    
    sketchFindMovableObjectsBuilder63.Destroy()
    
    markId306 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder25 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects64 = [None] * 1 
    dragobjects64[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects64[0].Geometry = arc3
    dragobjects64[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects64[0].PointIndex = 0
    sketchDragGeometryBuilder25.SetDragGeometry(dragobjects64)
    
    sketchDragGeometryBuilder25.SplineLinearScale = False
    
    foundrelations94 = sketchDragGeometryBuilder25.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects65 = [None] * 1 
    dragobjects65[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects65[0].Geometry = arc3
    dragobjects65[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects65[0].PointIndex = 0
    sketchDragGeometryBuilder25.SetDragGeometry(dragobjects65)
    
    foundrelations95 = sketchDragGeometryBuilder25.FindRelations()
    
    sketchDragGeometryBuilder25.Destroy()
    
    markId307 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences25 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences25 = dimensionPreferences25.GetNarrowDimensionPreferences()
    
    option25 = narrowDimensionPreferences25.DimensionDisplayOption
    
    sketchRadialDimensionBuilder3 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder25 = sketchRadialDimensionBuilder3.Driving
    
    drivingValueBuilder25.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject47 = sketchRadialDimensionBuilder3.FirstAssociativity
    
    point1_104 = NXOpen.Point3d(63.0, 0.0, 56.0)
    point2_104 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject47.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, NXOpen.View.Null, point1_104, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_104)
    
    dimensionMeasurementBuilder25 = sketchRadialDimensionBuilder3.Measurement
    
    dimensionMeasurementBuilder25.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder25 = sketchRadialDimensionBuilder3.Origin
    
    origin91 = NXOpen.Point3d(68.241253941174605, 0.0, 58.549916427592038)
    originBuilder25.OriginPoint = origin91
    
    originBuilder25.SetInferRelativeToGeometry(True)
    
    nXObject127 = sketchRadialDimensionBuilder3.Commit()
    
    sketchRadialDimensionBuilder3.Destroy()
    
    narrowDimensionPreferences25.Dispose()
    dimensionPreferences25.Dispose()
    sketchFindMovableObjectsBuilder64 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject128 = sketchFindMovableObjectsBuilder64.Commit()
    
    sketchFindMovableObjectsBuilder64.Destroy()
    
    markId308 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId309 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension3 = nXObject127
    sketchEditDimensionValueBuilder26 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension3)
    
    selectNXObjectList31 = sketchEditDimensionValueBuilder26.ExtraGeometries
    
    foundrelations96 = sketchEditDimensionValueBuilder26.FindRelations()
    
    sketchDimensionalConstraint3 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc3]")
    sketchDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId309, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId309, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId310 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId310, None)
    
    markId311 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder26.DimValue = 3.0
    
    theSession.ActiveSketch.Scale(0.49857044348312596)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin92 = NXOpen.Point3d(34.023072241296042, 0.0, 29.191257799204529)
    diameterDimension3.AnnotationOrigin = origin92
    
    sketchEditDimensionValueBuilder26.RestoreOperation()
    
    sketchEditDimensionValueBuilder26.LoadExtraGeometry()
    
    selectNXObjectList32 = sketchEditDimensionValueBuilder26.ExtraGeometries
    
    foundrelations97 = sketchEditDimensionValueBuilder26.FindRelations()
    
    nXObject129 = sketchEditDimensionValueBuilder26.Commit()
    
    theSession.SetUndoMarkName(markId311, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId311, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId309, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId312 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId313 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId313, None)
    
    theSession.SetUndoMarkName(markId309, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder26.Destroy()
    
    theSession.DeleteUndoMark(markId312, None)
    
    theSession.SetUndoMarkVisibility(markId309, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId311, None)
    
    theSession.DeleteUndoMark(markId309, None)
    
    sketchFindMovableObjectsBuilder65 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject130 = sketchFindMovableObjectsBuilder65.Commit()
    
    sketchFindMovableObjectsBuilder65.Destroy()
    
    markId314 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder26 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects66 = [None] * 1 
    dragobjects66[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects66[0].Geometry = arc3
    dragobjects66[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects66[0].PointIndex = 0
    sketchDragGeometryBuilder26.SetDragGeometry(dragobjects66)
    
    sketchDragGeometryBuilder26.SplineLinearScale = False
    
    foundrelations98 = sketchDragGeometryBuilder26.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects67 = [None] * 1 
    dragobjects67[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects67[0].Geometry = arc3
    dragobjects67[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects67[0].PointIndex = -1475379104
    sketchDragGeometryBuilder26.SetDragGeometry(dragobjects67)
    
    foundrelations99 = sketchDragGeometryBuilder26.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects68 = [None] * 1 
    dragobjects68[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects68[0].Geometry = arc3
    dragobjects68[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects68[0].PointIndex = -1475379088
    sketchDragGeometryBuilder26.SetDragGeometry(dragobjects68)
    
    foundrelations100 = sketchDragGeometryBuilder26.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects69 = [None] * 1 
    dragobjects69[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects69[0].Geometry = arc3
    dragobjects69[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects69[0].PointIndex = -1475378416
    sketchDragGeometryBuilder26.SetDragGeometry(dragobjects69)
    
    foundrelations101 = sketchDragGeometryBuilder26.FindRelations()
    
    sketchDragGeometryBuilder26.Destroy()
    
    markId315 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences26 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences26 = dimensionPreferences26.GetNarrowDimensionPreferences()
    
    option26 = narrowDimensionPreferences26.DimensionDisplayOption
    
    sketchLinearDimensionBuilder23 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder26 = sketchLinearDimensionBuilder23.Driving
    
    drivingValueBuilder26.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder26 = sketchLinearDimensionBuilder23.Measurement
    
    dimensionMeasurementBuilder26.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject48 = sketchLinearDimensionBuilder23.FirstAssociativity
    
    selectNXObject49 = sketchLinearDimensionBuilder23.SecondAssociativity
    
    edge12 = extrude3.FindObject("EDGE * 130 * 150 {(60,60,60)(63,60,60)(66,60,60) EXTRUDE(2)}")
    point1_107 = NXOpen.Point3d(64.13412826139637, 0.0, 60.0)
    point2_107 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject48.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge12, NXOpen.View.Null, point1_107, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_107)
    
    point1_108 = NXOpen.Point3d(31.409937939436936, 0.0, 27.919944835055055)
    point2_108 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject49.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, NXOpen.View.Null, point1_108, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_108)
    
    originBuilder26 = sketchLinearDimensionBuilder23.Origin
    
    origin94 = NXOpen.Point3d(31.409937939436936, 0.0, 43.959972417527524)
    originBuilder26.OriginPoint = origin94
    
    originBuilder26.SetInferRelativeToGeometry(True)
    
    nXObject131 = sketchLinearDimensionBuilder23.Commit()
    
    perpendicularDimension13 = nXObject131
    perpendicularDimension13.IsOriginCentered = True
    
    sketchLinearDimensionBuilder23.Destroy()
    
    narrowDimensionPreferences26.Dispose()
    dimensionPreferences26.Dispose()
    sketchFindMovableObjectsBuilder66 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject132 = sketchFindMovableObjectsBuilder66.Commit()
    
    sketchFindMovableObjectsBuilder66.Destroy()
    
    markId316 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId317 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder27 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension13)
    
    selectNXObjectList33 = sketchEditDimensionValueBuilder27.ExtraGeometries
    
    foundrelations102 = sketchEditDimensionValueBuilder27.FindRelations()
    
    sketchHelpedDimensionalConstraint23 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(10)|EDGE * 130 * 150 {(60,60,60)(63,60,60)(66,60,60) EXTRUDE(2)}] [[Curve Arc3] ArcCenter]")
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId317, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId317, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId318 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId318, None)
    
    markId319 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder27.DimValue = 4.0
    
    nXObject133 = sketchEditDimensionValueBuilder27.Commit()
    
    theSession.SetUndoMarkName(markId319, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId319, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId317, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId320 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId321 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId321, None)
    
    theSession.SetUndoMarkName(markId317, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder27.Destroy()
    
    theSession.DeleteUndoMark(markId320, None)
    
    theSession.SetUndoMarkVisibility(markId317, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId319, None)
    
    theSession.DeleteUndoMark(markId317, None)
    
    sketchFindMovableObjectsBuilder67 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject134 = sketchFindMovableObjectsBuilder67.Commit()
    
    sketchFindMovableObjectsBuilder67.Destroy()
    
    markId322 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder27 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects70 = [None] * 1 
    dragobjects70[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects70[0].Geometry = arc3
    dragobjects70[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects70[0].PointIndex = 0
    sketchDragGeometryBuilder27.SetDragGeometry(dragobjects70)
    
    sketchDragGeometryBuilder27.SplineLinearScale = False
    
    foundrelations103 = sketchDragGeometryBuilder27.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects71 = [None] * 1 
    dragobjects71[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects71[0].Geometry = arc3
    dragobjects71[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects71[0].PointIndex = -1475378960
    sketchDragGeometryBuilder27.SetDragGeometry(dragobjects71)
    
    foundrelations104 = sketchDragGeometryBuilder27.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects72 = [None] * 1 
    dragobjects72[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects72[0].Geometry = arc3
    dragobjects72[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects72[0].PointIndex = -1475379040
    sketchDragGeometryBuilder27.SetDragGeometry(dragobjects72)
    
    foundrelations105 = sketchDragGeometryBuilder27.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects73 = [None] * 1 
    dragobjects73[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects73[0].Geometry = arc3
    dragobjects73[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects73[0].PointIndex = -1475379168
    sketchDragGeometryBuilder27.SetDragGeometry(dragobjects73)
    
    foundrelations106 = sketchDragGeometryBuilder27.FindRelations()
    
    sketchDragGeometryBuilder27.Destroy()
    
    markId323 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences27 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences27 = dimensionPreferences27.GetNarrowDimensionPreferences()
    
    option27 = narrowDimensionPreferences27.DimensionDisplayOption
    
    sketchLinearDimensionBuilder24 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder27 = sketchLinearDimensionBuilder24.Driving
    
    drivingValueBuilder27.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder27 = sketchLinearDimensionBuilder24.Measurement
    
    dimensionMeasurementBuilder27.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject50 = sketchLinearDimensionBuilder24.FirstAssociativity
    
    selectNXObject51 = sketchLinearDimensionBuilder24.SecondAssociativity
    
    edge14 = extrude3.FindObject("EDGE * 150 * 160 {(66,60,60)(66,60,32.5)(66,60,5) EXTRUDE(2)}")
    point1_111 = NXOpen.Point3d(66.0, 0.0, 54.820909422534193)
    point2_111 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject50.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge14, NXOpen.View.Null, point1_111, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_111)
    
    point1_112 = NXOpen.Point3d(31.409937939436936, 0.0, 55.999999999999993)
    point2_112 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject51.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, NXOpen.View.Null, point1_112, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_112)
    
    originBuilder27 = sketchLinearDimensionBuilder24.Origin
    
    origin96 = NXOpen.Point3d(48.704968969718465, 0.0, 55.999999999999993)
    originBuilder27.OriginPoint = origin96
    
    originBuilder27.SetInferRelativeToGeometry(True)
    
    nXObject135 = sketchLinearDimensionBuilder24.Commit()
    
    perpendicularDimension14 = nXObject135
    perpendicularDimension14.IsOriginCentered = True
    
    sketchLinearDimensionBuilder24.Destroy()
    
    narrowDimensionPreferences27.Dispose()
    dimensionPreferences27.Dispose()
    sketchFindMovableObjectsBuilder68 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject136 = sketchFindMovableObjectsBuilder68.Commit()
    
    sketchFindMovableObjectsBuilder68.Destroy()
    
    markId324 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId325 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder28 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension14)
    
    selectNXObjectList34 = sketchEditDimensionValueBuilder28.ExtraGeometries
    
    foundrelations107 = sketchEditDimensionValueBuilder28.FindRelations()
    
    sketchHelpedDimensionalConstraint24 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(10)|EDGE * 150 * 160 {(66,60,60)(66,60,32.5)(66,60,5) EXTRUDE(2)}] [[Curve Arc3] ArcCenter]")
    sketchHelpedDimensionalConstraint24.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId325, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId325, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint24.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId326 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId326, None)
    
    markId327 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder28.DimValue = 3.0
    
    nXObject137 = sketchEditDimensionValueBuilder28.Commit()
    
    theSession.SetUndoMarkName(markId327, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId327, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId325, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId328 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId329 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint24.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId329, None)
    
    theSession.SetUndoMarkName(markId325, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder28.Destroy()
    
    theSession.DeleteUndoMark(markId328, None)
    
    theSession.SetUndoMarkVisibility(markId325, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId327, None)
    
    theSession.DeleteUndoMark(markId325, None)
    
    sketchFindMovableObjectsBuilder69 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject138 = sketchFindMovableObjectsBuilder69.Commit()
    
    sketchFindMovableObjectsBuilder69.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder6 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder6.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject139 = sketchWorkRegionBuilder6.Commit()
    
    sketchWorkRegionBuilder6.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId330 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId331 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section8 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section8
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies55 = [NXOpen.Body.Null] * 1 
    targetBodies55[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies55)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies56 = [NXOpen.Body.Null] * 1 
    targetBodies56[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies56)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder8 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder8.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder8.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId331, "Extrude Dialog")
    
    section8.DistanceTolerance = 0.01
    
    section8.ChainingTolerance = 0.0094999999999999998
    
    section8.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId332 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions10 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions10.SetSelectedFromInactive(False)
    
    curves10 = [NXOpen.ICurve.Null] * 1 
    curves10[0] = arc3
    seedPoint10 = NXOpen.Point3d(62.802447405327307, 0.0, 55.901562967846431)
    regionBoundaryRule10 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch6, curves10, seedPoint10, 0.01, selectionIntentRuleOptions10)
    
    selectionIntentRuleOptions10.Dispose()
    section8.AllowSelfIntersection(True)
    
    section8.AllowDegenerateCurves(False)
    
    rules7 = [None] * 1 
    rules7[0] = regionBoundaryRule10
    helpPoint7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section8.AddToSection(rules7, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint7, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId332, None)
    
    markId333 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId334 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId334, None)
    
    direction20 = workPart.Directions.CreateDirection(sketch6, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder8.Direction = direction20
    
    theSession.DeleteUndoMark(markId333, None)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies57 = [NXOpen.Body.Null] * 1 
    targetBodies57[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies57)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("-100")
    
    markId335 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId335, None)
    
    markId336 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder8.ParentFeatureInternal = False
    
    feature12 = extrudeBuilder8.CommitFeature()
    
    theSession.DeleteUndoMark(markId336, None)
    
    theSession.SetUndoMarkName(markId331, "Extrude")
    
    expression33 = extrudeBuilder8.Limits.StartExtend.Value
    expression34 = extrudeBuilder8.Limits.EndExtend.Value
    extrudeBuilder8.Destroy()
    
    workPart.Expressions.Delete(expression32)
    
    scaleAboutPoint260 = NXOpen.Point3d(0.96802704953739138, 38.375358035218888, 0.0)
    viewCenter260 = NXOpen.Point3d(-0.96802704953668395, -38.375358035218305, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint260, viewCenter260)
    
    scaleAboutPoint261 = NXOpen.Point3d(-10.178112977989166, 34.461762963519114, 0.0)
    viewCenter261 = NXOpen.Point3d(10.178112977989864, -34.461762963518545, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint261, viewCenter261)
    
    scaleAboutPoint262 = NXOpen.Point3d(-12.722641222486539, 43.077203704398826, 0.0)
    viewCenter262 = NXOpen.Point3d(12.722641222487246, -43.077203704398251, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint262, viewCenter262)
    
    scaleAboutPoint263 = NXOpen.Point3d(-37.338186196428538, 56.785158173735901, 0.0)
    viewCenter263 = NXOpen.Point3d(37.338186196429255, -56.785158173735347, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint263, viewCenter263)
    
    scaleAboutPoint264 = NXOpen.Point3d(-29.870548957142766, 45.428126538988778, 0.0)
    viewCenter264 = NXOpen.Point3d(29.870548957143473, -45.428126538988202, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint264, viewCenter264)
    
    scaleAboutPoint265 = NXOpen.Point3d(-38.721081981481476, 31.364076405000556, 0.0)
    viewCenter265 = NXOpen.Point3d(38.721081981482179, -31.364076404999992, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint265, viewCenter265)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()